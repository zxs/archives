# set/export MAVEN_HOME/bin to system environment
mvn exec:java -e -Dexec.mainClass="com.foxconn.gds.sce.melp.support.invoker.SpringTaskInvoker" \
    -Dexec.args="-l classpath:melp-core.spring.xml,classpath:melp-hibernate.spring.xml, classpath:melp-ibatis.spring.xml -b defaultDataPopulator"
cd ..