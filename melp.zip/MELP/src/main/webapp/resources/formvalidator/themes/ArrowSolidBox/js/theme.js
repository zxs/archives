var onShowHtml = "";
var onFocusHtml = "<span class='$class$'><span class='$class$_top'>$data$</span><span class='$class$_bot'></span></span>";
var onErrorHtml = "<span class='$class$'><span class='$class$_top'>$data$</span><span class='$class$_bot'></span></span>";
var onCorrectHtml = "<span class='$class$'></span>";
var onShowClass = "input_public";
var onFocusClass = "input_public input_focus";
var onErrorClass = "input_public input_error";
var onCorrectClass = "input_public input_correct";