package com.foxconn.gds.sce.melp.learnRecord.dao.ibatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.foxconn.gds.sce.melp.learnRecord.dao.LearnRecordDao;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value = "ibLeranRecordDao")
public class IbLearnRecordDao extends GenericDaoIbatisImpl<MyClassInfo, String>
		implements LearnRecordDao {

	@Autowired
	public IbLearnRecordDao(SqlMapClient sqlMapClient) {
		super(MyClassInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<MyClassInfo> listLearnRecord(String empNo) {
		// TODO Auto-generated method stub
		return (List<MyClassInfo>) getSqlMapClientTemplate().queryForList(
				"listLearnRecordByEmpNo", empNo);

	}
}
