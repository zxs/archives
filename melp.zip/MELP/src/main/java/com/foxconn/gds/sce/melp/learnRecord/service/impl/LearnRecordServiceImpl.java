package com.foxconn.gds.sce.melp.learnRecord.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.learnCourse.dao.LearnCourseDao;
import com.foxconn.gds.sce.melp.learnCourse.service.LearnCourseService;
import com.foxconn.gds.sce.melp.learnRecord.dao.LearnRecordDao;
import com.foxconn.gds.sce.melp.learnRecord.service.LearnRecordService;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;


	@Service(value = "learnRecordServer")
	public class LearnRecordServiceImpl extends CrudServiceImpl<MyClassInfo, LearnRecordDao>
			implements  LearnRecordService {

		@Autowired
		public void setIbLearnRecordDao(LearnRecordDao ibLearnRecordDao) {
			this.daoSupport = ibLearnRecordDao;
		}


		public List<MyClassInfo> listLearnRecord(String empNo) {
			return daoSupport.listLearnRecord(empNo);
		}
}
	
