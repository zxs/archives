package com.foxconn.gds.sce.melp.evaluateCourse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.evaluateCourse.service.EvaluateCourseService;
import com.foxconn.gds.sce.melp.learnCourse.service.LearnCourseService;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.security.SecurityUtils;


@Controller
@RequestMapping(value = "/evaluateCourse/**")
public class EvaluateCourseController {
	private EvaluateCourseService evaluateCourseService;
	@Autowired
	public void setEvaluateCourseService(EvaluateCourseService evaluateCourseService){
		this.evaluateCourseService = evaluateCourseService;
	}
	@RequestMapping(method=RequestMethod.GET,value="courseList.spr")
	public ModelAndView courseList(){
		return new ModelAndView();
	}
	@RequestMapping(method=RequestMethod.GET,value="evaluatePaper.spr")
	public ModelAndView evaluatePaper(HttpServletRequest request){
		String classID=request.getParameter("classID");
		String courseID=request.getParameter("courseID");
		String courseName=request.getParameter("courseName");
		String className=request.getParameter("className");
		ModelAndView mav=new ModelAndView("evaluateCourse/evaluatePaper");
		mav.addObject("classID",classID);
		mav.addObject("courseName",courseName);
		mav.addObject("className",className);
		mav.addObject("courseID",courseID);
		
		return mav;
	}
	@RequestMapping(method=RequestMethod.POST,value="getPaperContent.spr")
	@ResponseBody
	public List<Questionnaires> paperContent(HttpServletRequest request){
		String courseID=request.getParameter("courseID");
		String courseCreator=evaluateCourseService.getCourseCreator(courseID);
		int evType=evaluateCourseService.getEvType(courseID);
		if(evType==0)
		{
			courseID="0";
			if(evaluateCourseService.showQuestionnaires_P(courseID,courseCreator).size()==0){
				courseCreator="Admin";
			}
		}
		List<Questionnaires> list_P=evaluateCourseService.showQuestionnaires_P(courseID,courseCreator);
			return list_P;
	}
	@RequestMapping(method=RequestMethod.POST,value="insertEvInfo.spr")
	@ResponseBody
	public Boolean evInfo(HttpServletRequest request){
		String questionId=request.getParameter("questionId");
		String option=request.getParameter("option");
		String classID=request.getParameter("classID");
		String courseID=request.getParameter("courseID");
		String empNo=SecurityUtils.getCurrentUser().getUserId();
			return evaluateCourseService.updateEvRecord(questionId, option,classID,courseID,empNo);
	}
	@RequestMapping(method=RequestMethod.POST,value="insertEvRecord.spr")
	@ResponseBody
	public Boolean insertEvRecord(HttpServletRequest request){
		String classID=request.getParameter("classID");
		String courseID=request.getParameter("courseID");
		String empNo=SecurityUtils.getCurrentUser().getUserId();
			return evaluateCourseService.insertEvRecord(classID,courseID,empNo);
	}
}
