package com.foxconn.gds.sce.melp.learnRecord;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.learnCourse.service.LearnCourseService;
import com.foxconn.gds.sce.melp.learnRecord.service.LearnRecordService;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.security.SecurityUtils;

@Controller
@RequestMapping(value = "/learnRecord/**")
public class LearnRecordController {
	private LearnRecordService learnRecordService;
	@Autowired
	public void setLearnRecordService(LearnRecordService learnRecordService){
		this.learnRecordService=learnRecordService;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="recordList.spr")
	public ModelAndView courseList(){
		return new ModelAndView("learnRecord/recordList");
	}
	@RequestMapping(method=RequestMethod.POST,value="getRecordList.spr")
	@ResponseBody
	public List<MyClassInfo> listLearnRecord(){
		String empNo="";
		empNo=SecurityUtils.getCurrentUser().getUserId();
		List<MyClassInfo> courseList=learnRecordService.listLearnRecord(empNo);
		return courseList;
	}
}
