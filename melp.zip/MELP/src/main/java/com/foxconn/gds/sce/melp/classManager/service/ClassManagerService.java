package com.foxconn.gds.sce.melp.classManager.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ClassInfo;
import com.foxconn.gds.sce.melp.model.ClassMember;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;


public interface ClassManagerService {


	public void saveClassInfo(ClassInfo classInfo);

	public DataTableReturn showAllClassInfoList(DataTable _dt, int userType);

	public boolean isClassNoExist(String classNo);

	public void updateClassInfo(ClassInfo classInfo);

	public void deleteClassInfo(ClassInfo classInfo);

	public ClassInfo checkClassInfo(String classId);

	public DataTableReturn getStudentListByClassId(DataTable dt, String classId);

	public void addPersonToClass(List<ClassMember> list);

	public void delClassMemberFromClass(List<ClassMember> classMemberList);

	public List<ClassMember> exportClassMember(String classId);

	public ClassInfo getCourseInfoById(ClassInfo courseInfo);

	public boolean isClassNoExistForUpdate(String classNo, String classId);

	public ClassInfo getAutoClassNo();
	
	
}
