package com.foxconn.gds.sce.melp.questionlib.service.impl;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.VO_QuestonOption;
import com.foxconn.gds.sce.melp.questionlib.dao.QuestionlibDao;
import com.foxconn.gds.sce.melp.questionlib.service.QuestionlibService;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;




/**
 * @author Julie
 */

@Service(value="questionlibService")
public class QuestionlibServiceImpl extends  CrudServiceImpl<QuestionLib, QuestionlibDao> implements QuestionlibService {
	
	@Autowired
public void  setQuestionlibDao(QuestionlibDao questionlibDao) {
	this.daoSupport=questionlibDao;
   }

public List<QuestionLib> findAllByCondition(QuestionLib questionLib) {
	return daoSupport.findAllByCondition(questionLib);
}
 
@SuppressWarnings("unchecked")
public DataTableReturn findAllQuestionLib(DataTable dt,String userid)
{
	DataTableReturn dtr=new DataTableReturn();
	int skipResults = dt.getDisplayStart();
	int maxResults = dt.getDisplayLength();
	Map params = new HashMap();
	params.put(DataTable.SEARCH, dt.getSearch());
	
	for( SortInfo sInfo : dt.getSortInfo() ) {
		params.put( DataTable.ORDER_COLUMN_SORT, 
				sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
	}
	
	params.put("CONDITION", userid);
	
	PaginatedResult<QuestionLib>  questions=daoSupport.findAllQuestionLib(params, skipResults, maxResults);
	dtr.setAaData(questions.getResult());
	dtr.setiTotalDisplayRecords(questions.getTotalResults());
	dtr.setiTotalRecords(questions.getTotalResults());
	dtr.setsEcho(dt.getEcho());
	return dtr;
	
	}

//查詢所有試題
	@SuppressWarnings("unchecked")
	public DataTableReturn findAllQuestion(DataTable dt,String libid)
	{
		DataTableReturn dtr=new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		params.put(DataTable.SEARCH, dt.getSearch());
		
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		params.put("dt_LibID", libid);
		PaginatedResult<Question>  questions=daoSupport.findAllQuestion(params, skipResults, maxResults);
		dtr.setAaData(questions.getResult());
		dtr.setiTotalDisplayRecords(questions.getTotalResults());
		dtr.setiTotalRecords(questions.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}


    @Transactional
	public  boolean insertLib(QuestionLib questionLib)
	{
	   return daoSupport.insertLib(questionLib);
	}

	//@Transactional
	public  boolean updateLib(QuestionLib questionLib)
	{
		return daoSupport.updateLib(questionLib);
	}
	
	public List<Question> findAllQustionByLibID(Question question)
	{
		return  daoSupport.findAllQustionByLibID(question);
	}
	
	//新增試題
	 @Transactional
	   public boolean insertQuestionAndOptions(Question question,QuestionOptions questionOptions)
	   {
		 //Hex.encodeHex(org.apache.commons.id.uuid.UUID.randomUUID().getRawBytes()
		// System.currentTimeMillis();
		 try{
			
			 if(daoSupport.insertQuestion(question))
			 {
				 String[] optionArray=questionOptions.getOptionContent().substring(0, questionOptions.getOptionContent().length()-1).split(","); 
				 String[] answerArray=questionOptions.getIsRightAnswer().substring(0,questionOptions.getIsRightAnswer().length()-1).split(",");
				 for(int i=0;i<optionArray.length;i++)
				 {
					String optionString= optionArray[i].toString();
					String rightString=answerArray[i].toString();
					questionOptions.setOptionContent(optionString);
					questionOptions.setIsRightAnswer(rightString);
					daoSupport.insertOption(questionOptions);
				 } 
				 return true;
			 }
			 else
			 {
				 return false;
			 }
		 }
			 catch (Exception e) {
				 return false;
			 }
			 
	   }
	 
	 public  List<VO_QuestonOption> findByQuestionID ( VO_QuestonOption vo_QuestonOption)
	 {
		 return daoSupport.findByQuestionID(vo_QuestonOption);
	 }
	 
	 @Transactional
	 public boolean EditQuestion(Question question,QuestionOptions questionOptions,String questionID)
	 {
		 Question question2=new Question();
		 question2.setId(questionID);
		 daoSupport.delOptionByID(question2);
		 daoSupport.delQuestionByID(question2);
		 insertQuestionAndOptions(question,questionOptions);
		 return true;
		
	 }
	 
	 //根據選項ID刪除選項
	 public  boolean  delOptionByID(QuestionOptions questionOptions)
	 {
		String[] idArray= questionOptions.getId().split(",");
		try
		{
			for(String id:idArray)
			{
				daoSupport.delOptionByID(id);
			}
			return true;
		}
		catch (Exception e) {
			return false;
		}
	 }
	 
	 public boolean delTitle(Question question)
	 {
		 String[] idArray=question.getId().split(",");
		 
		 try
		 {
			 for(String id:idArray)
			 {
				
				 Question question2=new Question();
				 question2.setId(id);
				 daoSupport.delOptionByID(question2);
				 daoSupport.delQuestionByID(question2);
			 } 
			 return true;
		 }
		 catch (Exception e) {
			return false;
		}
	 }
	 
	//刪除試題庫
	 @Transactional
		public boolean delQuestionLib(QuestionLib questionLib)
		{
			String[] libIdArray=questionLib.getId().split(",");
			try
			{
				for( String libId:libIdArray)
				{
					QuestionLib questionLib2=new QuestionLib();
					questionLib2.setId(libId);
					questionLib2.setModifier(questionLib.getModifier());
					
					Question question=new Question();
					question.setQuestionLibId(libId);
					List<Question> questionsList=daoSupport.findAllQustionByLibID(question);
					for(Question perquestion:questionsList)
					{
						perquestion.setModifier(questionLib.getModifier());
						daoSupport.delQuestionByID(perquestion);
					    daoSupport.delOptionByID(perquestion);
					}
					daoSupport.delQuestionLib(questionLib2);
				}
				return true;
			}
			catch (Exception e) {
				return false;
			}
		}
		
		//導入試題
		public void importQuestion(MultipartFile file)
		{
			POIFSFileSystem fsFileSystem;
			try {
				fsFileSystem = new POIFSFileSystem(file.getInputStream());
			
			HSSFWorkbook workBook = new HSSFWorkbook(fsFileSystem);
			HSSFSheet hssfSheet = workBook.getSheetAt(0);
			
			@SuppressWarnings("rawtypes")
			Iterator rowIterator = hssfSheet.rowIterator();
			
			List cellTempList = new ArrayList();
			while (rowIterator.hasNext()) {
				HSSFRow hssfRow = (HSSFRow) rowIterator.next();
				Iterator iterator = hssfRow.cellIterator();
				while (iterator.hasNext()) {
					HSSFCell hssfCell = (HSSFCell) iterator.next();
					cellTempList.add(hssfCell);
				}
			}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		
		//hssfSheet:傳入舊的sheet,返回新的HSSFWorkbook
		public HSSFWorkbook  createNewExcel(HSSFSheet  sourseSheet)
		{
			//創建新的sheet
			HSSFWorkbook wbCreat = new HSSFWorkbook();
			HSSFSheet newsheet=wbCreat.createSheet();
			
			//复制源表中的合并单元格  to do
			
			
			int firstRow = sourseSheet.getFirstRowNum();
		    int lastRow=sourseSheet.getLastRowNum();
		    
		    for (int i = firstRow; i <= lastRow; i++) //循環行
		    {
		    	// 创建新建excel Sheet的行
		    	HSSFRow rowNewCreate = newsheet.createRow(i);
		    	
		    	// 取得源有excel Sheet的行
		        HSSFRow rowsourCreate = sourseSheet.getRow(i);
		        
		        // 单元格式样
		        HSSFCellStyle cellStyle = null;
		        int firstCell = rowsourCreate.getFirstCellNum();
		        int lastCell = rowsourCreate.getLastCellNum();
		        for(int j = firstCell;j<=lastCell;j++) //循環列
		        {
		        	// new一个式样
		        	cellStyle = wbCreat.createCellStyle();    
		        	
		        	// 设置边框线型
		        	cellStyle.setBorderTop(rowsourCreate.getCell(j).getCellStyle().getBorderTop());
		            cellStyle.setBorderBottom(rowsourCreate.getCell(j).getCellStyle().getBorderBottom());
		            cellStyle.setBorderLeft(rowsourCreate.getCell(j).getCellStyle().getBorderLeft());
		            cellStyle.setBorderRight(rowsourCreate.getCell(j).getCellStyle().getBorderRight());
		            
		            // 设置内容位置:例水平居中,居右，居工
		            cellStyle.setAlignment(rowsourCreate.getCell(j).getCellStyle().getAlignment());
		            // 设置内容位置:例垂直居中,居上，居下
		            cellStyle.setVerticalAlignment(rowsourCreate.getCell(j).getCellStyle().getVerticalAlignment());
		            // 自动换行
		            cellStyle.setWrapText(rowsourCreate.getCell(j).getCellStyle().getWrapText());
		            rowNewCreate.createCell(j).setCellStyle(cellStyle);
		            
		            // 设置单元格高度
		            rowNewCreate.getCell(j).getRow().setHeight(rowsourCreate.getCell(j).getRow().getHeight());
		            
		            //檢查单元格类型
		            switch (rowsourCreate.getCell(j).getCellType()) {
		            case HSSFCell.CELL_TYPE_STRING:
		                String strVal = removeInternalBlank(rowsourCreate.getCell(j).getStringCellValue());
		                rowNewCreate.getCell(j).setCellValue(strVal);
		                break;
		            case HSSFCell.CELL_TYPE_NUMERIC:
		            	rowNewCreate.getCell(j).setCellValue(rowsourCreate.getCell(j).getNumericCellValue());
		            	break;
		            case HSSFCell.CELL_TYPE_FORMULA:
		            	try {
		            		rowNewCreate.getCell(j).setCellValue(String.valueOf(rowsourCreate.getCell(j).getNumericCellValue()));      
		            	      } 
		            	catch (IllegalStateException e) {
		            	       try {
		            	    	   rowNewCreate.getCell(j).setCellValue(String.valueOf(rowsourCreate.getCell(j).getRichStringCellValue()));       
		            	       } catch (Exception ex) {
		            	    	   rowNewCreate.getCell(j).setCellValue("公式出错");
		            	       }
		            	      }
		            	      break;
		            }
		        }
		    }
			
			return wbCreat;
		}	
		
		
		
		/**
		* 去除字符串内部空格
		*/
		public static String removeInternalBlank(String s) {
		   // System.out.println("bb:" + s);
		   Pattern p = Pattern.compile("\\s*|\t|\r|\n");
		   Matcher m = p.matcher(s);
		   char str[] = s.toCharArray();
		   StringBuffer sb = new StringBuffer();
		   for (int i = 0; i < str.length; i++) {
		    if (str[i] == ' ') {
		     sb.append(' ');
		     }
		    else {
		     break;
		    }
		   }
		   String after = m.replaceAll("");
		   return sb.toString() + after;
		}

	
		public HSSFSheet createNewCol(HSSFSheet  sourseSheet)
		{
			int firstRow=sourseSheet.getFirstRowNum();
			int lastRow=sourseSheet.getLastRowNum();
			for(int i=firstRow;i<=lastRow;i++)
			{
				HSSFRow row=sourseSheet.getRow(i);
				int lastCell=row.getLastCellNum();
				row.createCell(lastCell+1);
			}
			return sourseSheet;
		}
		
		
	// 驗證數據
	@SuppressWarnings("unused")
	public Map validates(HSSFRow hssfRow) {
		Map dataMap = new HashMap();
		String questionType = "";
		String questionTitle = "";
		String isRightAnswer = "";
		String priority = "";
		String err_msg = "";

		//List<String> rightChar = new ArrayList<String>();
		String rightString = "";
		// 取行中的每列 0:題目類型 1:考題內容 2:選項A 3:選項B 4:選項C 5:選項D 6:正確答案 7:是否必答

		// 第0行
		questionType = hssfRow.getCell(0).getStringCellValue().trim();
		if (!questionType.equals("")) {
			if (questionType.equals("判斷")) {
				questionType = "0";
			} else if (questionType.equals("單選")) {
				questionType = "1";
			} else if (questionType.equals("多選")) {
				questionType = "2";
			} else {
				err_msg += "題目類型必須為'判斷','單選','多選';";
			}
		} else {
			err_msg += "題目類型不能為空;";
		}

		// 第1行
		questionTitle = hssfRow.getCell(1).getStringCellValue().trim();
		if (questionTitle.equals("")) {
			err_msg += "考題內容不能為空;";
		}
		// 存放試題&答案于數組
		isRightAnswer = hssfRow.getCell(6).getStringCellValue().trim().toUpperCase();
		String[][] tempOptions = new String[4][2];
		isRightAnswer=isRightAnswer.replaceAll("[^a-dA-D]", "");
		char[] rightChar= isRightAnswer.toCharArray();
		if (!isRightAnswer.equals(""))
		{
				if (questionType.equals("2") && rightChar.length < 2) {
					err_msg += "答案信息不正确;";
				} else {
     			//isRightAnswer = isRightAnswer.replaceFirst(",", "");
					for (int i = 0; i < 4; i++) {
							switch (hssfRow.getCell(i+2).getCellType()) 
							{
							case HSSFCell.CELL_TYPE_STRING:
								tempOptions[i][0]=hssfRow.getCell(i + 2).getStringCellValue();
								break;
							 case HSSFCell.CELL_TYPE_NUMERIC:
								 tempOptions[i][0]=Double.toString(hssfRow.getCell(i + 2).getNumericCellValue());
								 break;
							 default:
								 tempOptions[i][0]="";
									break;
							}
						tempOptions[i][1] = "N";
						char ss = (char) (65 + i);
						if (isRightAnswer.indexOf(ss) >= 0) {
							tempOptions[i][1] = "Y";

						}

					}
				

			}

		} else {
			err_msg += "答案信息不正确;";
		}

		// 第7行
		priority = hssfRow.getCell(7).getStringCellValue().trim();
		if (!priority.equals("")) {
			if (priority.toUpperCase().equals("Y")) {
				priority = "1";
			} else if (priority.toUpperCase().equals("N")) {
				priority = "0";
			} else {
				err_msg += "是否必答必須為'Y','N';";
			}
		} else {
			err_msg += "是否必答不能為空";
		}
		
	    String stringA="";
	    String stringB="";
	    String stringC="";
	    String stringD="";
        switch (hssfRow.getCell(2).getCellType()) {
		case HSSFCell.CELL_TYPE_STRING :
			stringA=hssfRow.getCell(2).getStringCellValue().trim();
			break;
		case HSSFCell.CELL_TYPE_NUMERIC :
			stringA=Double.toString(hssfRow.getCell(2).getNumericCellValue())  ;
			break;
		default:
			break;
		}
        switch (hssfRow.getCell(3).getCellType()) {
		case HSSFCell.CELL_TYPE_STRING :
			stringB=hssfRow.getCell(3).getStringCellValue().trim();
			break;
		case HSSFCell.CELL_TYPE_NUMERIC :
			stringB=Double.toString(hssfRow.getCell(3).getNumericCellValue())  ;
			break;
		default:
			break;
		}
        switch (hssfRow.getCell(4).getCellType()) {
		case HSSFCell.CELL_TYPE_STRING :
			stringC=hssfRow.getCell(4).getStringCellValue().trim();
			break;
		case HSSFCell.CELL_TYPE_NUMERIC :
			stringC=Double.toString(hssfRow.getCell(4).getNumericCellValue())  ;
			break;
		default:
			break;
		}
        switch (hssfRow.getCell(5).getCellType()) {
		case HSSFCell.CELL_TYPE_STRING :
			stringD=hssfRow.getCell(5).getStringCellValue().trim();
			break;
		case HSSFCell.CELL_TYPE_NUMERIC :
			stringD=Double.toString(hssfRow.getCell(5).getNumericCellValue())  ;
			break;
		default:
			break;
		}
        
        
        
		if (stringA.isEmpty()&& stringB.isEmpty()&& stringC.isEmpty()&& stringD.isEmpty()) {
			err_msg += "選項不能為空;";
		}

		dataMap.put("questionType", questionType);
		dataMap.put("questionTitle", questionTitle);
		dataMap.put("priority", priority);
		dataMap.put("optionsList", tempOptions);
		dataMap.put("err_msg", err_msg);

		return dataMap;
	}
			

		
	// 導入試題
	public Map<String,Object> importQuestion(MultipartFile file, String user_id,
			String libID) throws Exception  {
		List<Map> successList = new ArrayList<Map>();
		Map resultMap=new HashMap();
		POIFSFileSystem fsFileSystem;
		
		String filePathString="";//定義錯誤數據的存放位置
		boolean flag;
		Map<String,Object> result=new HashMap<String, Object>();
		
//		try {
			fsFileSystem = new POIFSFileSystem(file.getInputStream());
			HSSFWorkbook workBook = new HSSFWorkbook(fsFileSystem);// 實例化WorkBook

			HSSFSheet hssfSheet = workBook.getSheetAt(0); // 取得第一個sheet
			Iterator rowIterator = hssfSheet.rowIterator(); // 取得sheet中的行

			// 用于保存錯誤數據的Excel
			HSSFWorkbook wb = new HSSFWorkbook();
			HSSFSheet sheet1 = wb.createSheet("sheet1");
			//設置表頭 to do
			int rowIndex = 1;//導出的數據從第二行開始
			
			int tempfirstcell=hssfSheet.getRow(0).getFirstCellNum();
			int templastcell=hssfSheet.getRow(0).getLastCellNum();
			HSSFRow  hr= sheet1.createRow((int)0);
			for(int i=tempfirstcell;i<templastcell;i++){
				
				String str=hssfSheet.getRow(0).getCell(i).toString();
				hr.createCell(i).setCellValue(str);
				
			}
			hr.createCell(templastcell).setCellValue("錯誤信息");
			while (rowIterator.hasNext()) {
                
				HSSFRow hssfRow = (HSSFRow) rowIterator.next(); // 略過第一行
				//System.out.print("file的個數"+hssfRow.getRowNum());
				Map udr = new HashMap();
				if (hssfRow.getRowNum() == 0)
					continue;
				
				udr = validates(hssfRow);   //驗證數據
				if (udr.get("err_msg").equals("")) {
					UUID uuid = UUID.randomUUID();
					String id = uuid.toString();
					id = id.replaceAll("-", "");
					udr.put("questionID", id);
					udr.put("questionLibID", libID);
					udr.put("creator", user_id);
					successList.add(udr);
				} else {
					int firstCell = hssfRow.getFirstCellNum();
					int lastCell = hssfRow.getLastCellNum();
					HSSFRow failrow = sheet1.createRow(rowIndex);
					for (int i = firstCell; i < lastCell; i++) {
						failrow.createCell(i).setCellValue(
								hssfRow.getCell(i).toString());
					}
					failrow.createCell(lastCell).setCellValue(udr.get("err_msg").toString());
					System.out.print("rowindex"+rowIndex);
					rowIndex++;
				}
			}

			// 向數據庫插入試題
			if (successList.size() != 0) {
				daoSupport.importTitle(successList);
				for (int i = 0; i < successList.size(); i++) {
					QuestionOptions tempQuestionOptions = new QuestionOptions();
					String[][] tempArray = (String[][]) successList.get(i).get(
							"optionsList");
					for (int j = 0; j < 4; j++) {
						if (!tempArray[j][0].isEmpty()&&tempArray[j][0]!=null) {
							tempQuestionOptions.setQuestionId(successList
									.get(i).get("questionID").toString());
							tempQuestionOptions.setCreator(successList.get(i)
									.get("creator").toString());
							tempQuestionOptions
									.setOptionContent(tempArray[j][0]);
							tempQuestionOptions
									.setIsRightAnswer(tempArray[j][1]);
							// perList.add(tempQuestionOptions);
							daoSupport.insertOption(tempQuestionOptions);
						}
					}
				}
			}

			// 錯誤數據導出
			if (rowIndex >1) {
				// wb.write(os);
				
				 File newfileFile=FileUtils.getUploadFile("error.xls");
				 String filename=newfileFile.getName();
				 String filepath=newfileFile.getPath();
				 //filepath=filepath.replaceAll("-","");
				 if(newfileFile.exists())
				 {
					 newfileFile.delete();
					 newfileFile=new File(filepath);
				 }
					FileOutputStream cout=new FileOutputStream(newfileFile);
					wb.write(cout);
					cout.close();
				filePathString=filepath;
				 flag=false;
			}
			flag=true;
			result.put("flag", flag);
			result.put("filePath", filePathString);
			return result;

	}
	
	 //查詢試題庫是否有試卷
	   public Object findPaperByLibid(String libid)
	   {
		   return daoSupport.findPaperByLibid(libid);
	   }
	
	 //導出
		@SuppressWarnings("unchecked")
		public  List<Map> exports(String libid,String searchString)
		{
			Map paraMap = new HashMap();
			paraMap.put("DT_SEARCH", searchString);
			//DT_ORDER_COLUMN_SORT
			paraMap.put("libid", libid);
			return daoSupport.exports(paraMap);
		}
	   
		
		//導出模板
		public void exportTemplet(FileOutputStream os){
			// FileOutputStream fileOut = new	FileOutputStream(FileUtils.getUploadFile(""));
//			FileOutputStream fileOut = new FileOutputStream("E:\\errorExcelDownload\\workbook.xls");
//			wb.write(fileOut);
//			fileOut.close();
			try
			{
				os=new FileOutputStream(FileUtils.getUploadFile(""));
			}
			catch (Exception e) {
				
			}
			
			
			
		}
	   
}
