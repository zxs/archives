package com.foxconn.gds.sce.melp.questionlib;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.RepaintManager;
import javax.swing.text.html.HTMLDocument.Iterator;

import org.apache.poi.hssf.model.Workbook;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.aspectj.weaver.patterns.IScope;
import org.codehaus.jackson.map.ObjectMapper;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.w3c.tidy.Out;

import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.VO_QuestonOption;
import com.foxconn.gds.sce.melp.questionlib.service.QuestionlibService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.user.UserController;

@Controller
@RequestMapping("/questionlib/**")
public class QustionlibController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
	private QuestionlibService questionlibSrv;
	
	@Autowired
	public void setQuestionlibSrv(QuestionlibService questionlibSrv) {
		this.questionlibSrv = questionlibSrv;
	}
	
	
	@RequestMapping(method=RequestMethod.GET, value="showList.spr")
	public ModelAndView showList(@RequestParam("iframe") String iframe) {
		
		return new ModelAndView("/questionlib/QuestionlibList", "iframe", "true".equals(iframe)?"true":"false");
		


		//return new ModelAndView("/questionlib/QuestionLibList");

	}
	
	@RequestMapping(method=RequestMethod.POST, value="findAllQuestionLibList.spr")
	public @ResponseBody Object findAllQuestionLibList(@RequestParam("_dt_json") String dtjson)
	{
		
		logger.info("String dtjson=" + dtjson);
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		
		String userid="";
		if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userid="";
		}
		else
		{
			userid=SecurityUtils.getCurrentUser().getUserId();
		}
		
		DataTableReturn tableReturn = this.questionlibSrv.findAllQuestionLib(dataTable, userid);
		return tableReturn;
		
	}
	
	
	@RequestMapping(method=RequestMethod.GET,value="showAdd.spr")
	public ModelAndView showAdd()
	{
		return new ModelAndView("/questionlib/AddQuestionLib");
	}
	
	
	
	@RequestMapping(method=RequestMethod.POST,value="addLib.spr")
	@ResponseBody
	public String addLib(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		
		QuestionLib lib=new QuestionLib();
		//String libName_temp= new String(request.getParameter("libName").getBytes("ISO-8859-1"),"utf-8");
		String libName= request.getParameter("libName");
		//System.out.print("libname_temp:"+libName_temp+"libname:"+libName);
		
		//String msg="";
		//String user_id="F3225919";
		String user_id=SecurityUtils.getCurrentUser().getUserId();
		//System.out.print("看看有沒有找到userid:"+temp_creator);
		
		lib.setQuestionLibName(libName);
		
		lib.setCreator(user_id);
		
		List<QuestionLib> list_questionLibs=questionlibSrv.findAllByCondition(lib);
		
		if(list_questionLibs==null||list_questionLibs.size()==0)
		{
		    lib.setCreator(user_id);
			if(questionlibSrv.insertLib(lib))
			{
			 return	"{\"success\":\"true\",\"msg\":\"1\"}";
			}
			else 
			{
				return	"{\"success\":\"flase\",\"msg\":\"2\"}";
			}
			
		}
		else 
		{
			return	"{\"success\":\"flase\",\"msg\":\"3\"}";
			
		}
		
	}
	
	@RequestMapping(method=RequestMethod.GET,value="showEdit.spr")
	public  ModelAndView  showEdit(HttpServletRequest request)
	{
		String id=request.getParameter("id").trim();//request.getParameter("name")
		String name= request.getParameter("name").trim();
		
		request.setAttribute("id", id);
		request.setAttribute("name",name);
		return new ModelAndView("/questionlib/EditQuestionLib");
	}

	@RequestMapping(method=RequestMethod.POST,value="editLib.spr")
	@ResponseBody
	public String editLib(HttpServletRequest request) throws UnsupportedEncodingException 
	{
		String id=request.getParameter("id");
		//String name=new String(request.getParameter("name").trim().getBytes("ISO-8859-1"),"utf-8");
		String user_id=SecurityUtils.getCurrentUser().getUserId();
		String name=request.getParameter("name").trim();
		QuestionLib lib=new QuestionLib();
		lib.setQuestionLibName(name);
		lib.setCreator(user_id);
		
        List<QuestionLib> list_questionLibs=questionlibSrv.findAllByCondition(lib);
		
        String msg="";
        String success="false";
		if(list_questionLibs==null||list_questionLibs.size()==0||list_questionLibs.size()==1)
		{
			if(list_questionLibs.size()!=1)
			{   
			    lib.setId(id);
				lib.setModifier(user_id);
				if(questionlibSrv.updateLib(lib))
				{
					success="true";
					msg="1";
				}
				else {
					success="false";
					 msg="2";
				}
			}
			else 
			{
				for(QuestionLib list :list_questionLibs)
				{
					if(list.getId().equals(id))
					{
						lib.setId(id);
						lib.setModifier(user_id);
						if(questionlibSrv.updateLib(lib))
						{
							success="true";
							msg="1";
						}
						else {
							 msg="2";
							 success="false";
						}
					}
					else {
						msg="3";
					}
				}
			}
		}
		else {
			msg="3";//已豐在
		}
		//"{\"status\":\"false\",\"error\":\""+ exception.getMessage() + "\"}");
		return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";
	}
	
	
	@RequestMapping(method=RequestMethod.GET,value="showQuestionList.spr")
	public ModelAndView showQuestionList(HttpServletRequest request,Model model)
	{
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		
		Question question=new Question();
		question.setQuestionLibId(id);
		List<Question> list=questionlibSrv.findAllQustionByLibID(question);
		
		model.addAttribute("questionList", list);
		request.setAttribute("id", id);
		request.setAttribute("name",name);
		
		
		
		return new ModelAndView("/questionlib/QuestionList");
	}
	
	//試題列表 findQuestionList
	@RequestMapping(method=RequestMethod.POST,value="findQuestionList.spr")
	public @ResponseBody Object findQuestionList(@RequestParam("_dt_json") String dtjson,HttpServletRequest request)
	{
		
		String libid=request.getParameter("libid");
		
		logger.info("String dtjson="+dtjson);
		DataTable dataTable=JackJson.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn=questionlibSrv.findAllQuestion(dataTable, libid);
		return tableReturn;
		
	}
	
	
	
	
	
	
	
	//新增試題頁面showAddQuestion
	@RequestMapping(method=RequestMethod.GET,value="showAddQuestion.spr")
	public ModelAndView showAddQuestion(HttpServletRequest request)
	{
	  String libid=request.getParameter("id");
	  
	  request.setAttribute("libid",libid);
	  return new ModelAndView("/questionlib/AddQuestion");
	}
	
	//新增試題功能 addQuestion
	@RequestMapping(method=RequestMethod.POST,value="addQuestion.spr")
	@ResponseBody
	public String addQuestion(HttpServletRequest request) 
	{
		
		String optionType=request.getParameter("optionType");
		String priority=request.getParameter("priority");
		
		//String title=new String(request.getParameter("title").getBytes("ISO-8859-1"),"utf-8");  
		String title=request.getParameter("title");
		//String optionContent=new String(request.getParameter("options").getBytes("ISO-8859-1"),"utf-8"); 
		String optionContent=request.getParameter("options");
		String right_answer=request.getParameter("isRight");
		String libid=request.getParameter("libid");
		//String creator="F3225919";
		String creator=SecurityUtils.getCurrentUser().getUserId();
		String msg="";
		String success="";
		
	    UUID uuid=UUID.randomUUID();
		String id = uuid.toString();
		id=id.replaceAll("-","");
		
		
		Question question=new Question();
		QuestionOptions  questionOptions=new QuestionOptions();
		question.setId(id);
		question.setQuestionLibId(libid);
		question.setQuestionTitle(title);
		question.setQuestionType(optionType);
		question.setPriority(priority);
		question.setCreator(creator);
		
		questionOptions.setQuestionId(id);
		questionOptions.setIsRightAnswer(right_answer);
		questionOptions.setOptionContent(optionContent);
		questionOptions.setCreator(creator);
		
		if(questionlibSrv.insertQuestionAndOptions(question, questionOptions))
		{
			msg="新增試題成功！";
			success="true";
		}
		else {
			msg="新增試題失敗！";
			success="false";
		}
		return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";
	}
	
	//編輯試題功能 
	@RequestMapping(method=RequestMethod.GET,value="showEditQuestion.spr")

	 public ModelAndView showEditQuestion(HttpServletRequest request)
	{
		
		String questionID=request.getParameter("questionid");
		request.setAttribute("questionID", questionID);
		return new ModelAndView("/questionlib/EditQuestion");
	}
	
	
	//findByQuestionID
	@RequestMapping(method=RequestMethod.POST,value="findByQuestionID.spr")
	@ResponseBody
	public List<VO_QuestonOption> findByQuestionID(HttpServletRequest request)
	{
		
		String questionID=request.getParameter("questionID");
		VO_QuestonOption vo_QuestonOption=new VO_QuestonOption();
		
		vo_QuestonOption.setQuestionId(questionID);
		List<VO_QuestonOption> list=questionlibSrv.findByQuestionID(vo_QuestonOption);
		
		return list;
	}
	
	
	//addQuestionForEdit
	@RequestMapping(method=RequestMethod.POST,value="addQuestionForEdit.spr")
	@ResponseBody
	public String addQuestionForEdit(HttpServletRequest request) throws UnsupportedEncodingException
	{
		String optionType=request.getParameter("optionType");
		String priority=request.getParameter("priority");
		
		//String title=new String(request.getParameter("title").getBytes("ISO-8859-1"),"utf-8");  
		//String optionContent=new String(request.getParameter("options").getBytes("ISO-8859-1"),"utf-8");  
		
		String title=request.getParameter("title");
		String optionContent=request.getParameter("options");
		String right_answer=request.getParameter("isRight");
		String libid=request.getParameter("libid");
		
		//String creator="F3225919";
		String creator=SecurityUtils.getCurrentUser().getUserId();
		
		
		String msg="";
		String success="";
		String questionID=request.getParameter("questionID");
		
		UUID uuid=UUID.randomUUID();
		String id = uuid.toString();
		id=id.replaceAll("-","");
		
		Question question=new Question();
		QuestionOptions  questionOptions=new QuestionOptions();
		question.setId(id);
		question.setQuestionLibId(libid);
		question.setQuestionTitle(title);
		question.setQuestionType(optionType);
		question.setPriority(priority);
		question.setCreator(creator);
		
		questionOptions.setQuestionId(id);
		questionOptions.setIsRightAnswer(right_answer);
		questionOptions.setOptionContent(optionContent);
		questionOptions.setCreator(creator);
		
		if(questionlibSrv.EditQuestion(question, questionOptions,questionID))
		{
			msg="新增試題成功！";
			success="true";
		}
		else {
			msg="新增試題失敗！";
			success="false";
		}
		return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";
	}
	
	
	//delOption
	@RequestMapping(method=RequestMethod.POST,value="delOption.spr")
	@ResponseBody
	public String delOption(HttpServletRequest request)
	{
	 String optionID=request.getParameter("optionID");
	 optionID=optionID.substring(0,optionID.length()-1);
	 QuestionOptions questionOptions=new QuestionOptions();
	 questionOptions.setId(optionID);
	 String msg="";
	 
	 if(questionlibSrv.delOptionByID(questionOptions))
	 {
		 msg="刪除成功！";
	 }
	 else 
	 {
		msg="刪除失敗！";
	 }
	 return msg;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value="delTitle.spr")
	@ResponseBody
	public String delTitle(HttpServletRequest request)
	{
		
		String titleID=request.getParameter("titleID");
		titleID=titleID.substring(0,titleID.length()-1);
		Question question=new Question();
		question.setId(titleID);
	    String msg="";
	    String success="";
	    
	    if(questionlibSrv.delTitle(question))
	    {
	    	 msg="刪除成功！";
	    	 success="true";
	    }
	    else
	    {
	    	msg="刪除失敗！";
	    	success="false";
	    }
	    return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";
	}
	
	
	
	
	
	@RequestMapping(method=RequestMethod.POST,value="DelQuestionLib.spr")
	@ResponseBody
	public String DelQuestionLib(HttpServletRequest request)
	{
		
		String libId=request.getParameter("libId");
		libId=libId.substring(0,libId.length()-1);
		//String userid="F3225919";
		//String userid=ClientUtil.getCurrentUser().getUserId();
		String userid=SecurityUtils.getCurrentUser().getUserId();
		QuestionLib questionLib=new QuestionLib();
		questionLib.setId(libId);
		questionLib.setModifier(userid);
		
		if(questionlibSrv.findPaperByLibid(libId).equals(0)){
			if(questionlibSrv.delQuestionLib(questionLib))
			{
				
				return	"{\"success\":\"true\",\"msg\":\"刪除成功\"}";
			}
			else {
				return	"{\"success\":\"false\",\"msg\":\"刪除失敗\"}";
			}
		}
		else{
			return	"{\"success\":\"false\",\"msg\":\"error\"}";
		}
		
	}
	
	
	//showImport
	@RequestMapping(method=RequestMethod.GET,value="showImport.spr")
	public ModelAndView showImport(HttpServletRequest request)
	{
	   String libid=request.getParameter("libid");
	   request.setAttribute("libid",libid);
	   return new ModelAndView("/questionlib/Import");
	   
	}
	
	
	//Import
	@RequestMapping(method=RequestMethod.POST,value="importQuestion.spr")
    public ModelAndView importQuestion(@RequestParam("libid") String libid,
            @RequestParam("file") MultipartFile file ,   HttpServletResponse response)
	{
		Map<String, Object> result = new HashMap<String,Object>();
    	result.put("status", false);
    	String userid=SecurityUtils.getCurrentUser().getUserId();
    	
    	Map<String,Object> temp=new HashMap<String, Object>();
    	try
    	{
    		if(!file.isEmpty())
    		{
    			temp = questionlibSrv.importQuestion(file,userid,libid);
    			if(temp.get("filePath").toString().isEmpty())
    			{
    				result.put("status", true);
    				result.put("msg", "導入試題成功！");
    				result.put("filepath", "");
    			}
    			else {
    				result.put("status", false);
    				result.put("msg", "部份試題導入成功！");
    				result.put("filepath", temp.get("filePath").toString());
				}
    		}
    		
    	}
    	catch (Exception e) {
    		result.put("status", false);
        	result.put("msg", "導入試題異常，請聯繫系統管理員！ EX:"+e.getMessage());
		}
    	return new ModelAndView("/questionlib/import_result", "result", result);
	}
	
	
	//導出exports
	@RequestMapping(method=RequestMethod.GET,value="exports.spr")
	public ModelAndView exports(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		String libid=request.getParameter("libid");
		String searchString=request.getParameter("search");
		List<Map> list=questionlibSrv.exports(libid,searchString);
		try {
		switch (list.size()) {
		case 0:
			
			break;
		default:
			OutputStream os=response.getOutputStream();
			response.reset();
			String filename="question.xls";
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-Disposition", "attachment;filename="+ new String(filename.getBytes(), "ISO8859-1"));
            HSSFWorkbook wb = new HSSFWorkbook();
		    HSSFSheet sheet = wb.createSheet("試題列表");
		    HSSFRow  row=sheet.createRow((int)0);
		    HSSFCellStyle cellStyle=wb.createCellStyle();
		    sheet.setColumnWidth(0, (short)2);
		    cellStyle.setVerticalAlignment(HSSFCellStyle.ALIGN_CENTER);
		    cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		    //cellStyle.setWrapText(true);
		    
		    HSSFFont font=wb.createFont();
		    font.setColor(HSSFFont.COLOR_RED);
		    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    cellStyle.setFont(font);
		    
		    HSSFCell cell=row.createCell((int)1);
		    cell.setCellValue("題目類型");cell.setCellStyle(cellStyle);
		    cell=row.createCell(2);
		    cell.setCellValue("考題內容"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(3);
		    cell.setCellValue("選項A"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(4);
		    cell.setCellValue("選項B"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(5);
		    cell.setCellValue("選項C"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(6);
		    cell.setCellValue("選項D"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(7);
		    cell.setCellValue("選項E"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(8);
		    cell.setCellValue("正確答案"); cell.setCellStyle(cellStyle);
		    cell=row.createCell(9);
		    cell.setCellValue("是否必答"); cell.setCellStyle(cellStyle);
			for(int i=1;i<=list.size();i++){
				HSSFRow _row=sheet.createRow((int)i);
				_row.createCell(1).setCellValue(list.get(i-1).get("QUESTION_TYPE").toString());
				_row.createCell(2).setCellValue(list.get(i-1).get("QUESTION_TITLE").toString());
				if(list.get(i-1).get("A")!=null){
					_row.createCell(3).setCellValue(list.get(i-1).get("A").toString());
				}
			    else {
			    	_row.createCell(3).setCellValue("");
				}
				if(list.get(i-1).get("B")!=null){
					_row.createCell(4).setCellValue(list.get(i-1).get("B").toString());
				}
			    else {
			    	_row.createCell(4).setCellValue("");
				}
				if(list.get(i-1).get("C")!=null){
					_row.createCell(5).setCellValue(list.get(i-1).get("C").toString());
				}
			    else {
			    	_row.createCell(5).setCellValue("");
				}
				if(list.get(i-1).get("D")!=null){
					_row.createCell(6).setCellValue(list.get(i-1).get("D").toString());
				}
			    else {
			    	_row.createCell(6).setCellValue("");
				}
				if(list.get(i-1).get("E")!=null){
					_row.createCell(7).setCellValue(list.get(i-1).get("E").toString());
				}
			    else {
			    	_row.createCell(7).setCellValue("");
				}
				//_row.createCell(3).setCellValue(list.get(i-1).get("A"). ?"":list.get(i-1).get("A").toString());
				//_row.createCell(4).setCellValue(list.get(i-1).get("B").equals("")?"":list.get(i-1).get("B").toString());
				//_row.createCell(5).setCellValue(list.get(i-1).get("C").equals("")?"":list.get(i-1).get("C").toString());
				//_row.createCell(6).setCellValue(list.get(i-1).get("D").equals("")?"":list.get(i-1).get("D").toString());
				//_row.createCell(7).setCellValue(list.get(i-1).get("E").equals("")?"":list.get(i-1).get("E").toString());
				_row.createCell(8).setCellValue(list.get(i-1).get("RIGHT_ANWER").toString());
				_row.createCell(9).setCellValue(list.get(i-1).get("PRIORITY").toString());
			}
			wb.write(os);
			os.close();
			break;
		}
		} catch (Exception e) {
			// TODO: handle exception
			
		}	
		return new ModelAndView();
	}
	
	//下載試題模板downloads
	@RequestMapping(method=RequestMethod.GET,value="downloads.spr")
	public ModelAndView downloads(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
		File file=FileUtils.getQuestionsImportFile();
		response.setContentType("application/vnd.ms-excel");
		response.setContentLength((int)file.length());
		response.setHeader("Content-Disposition","attachment; filename=\"" 
//				+ URLEncoder.encode(file.getName(), "UTF-8") + "\"");
				+ URLEncoder.encode("試題導入模板.xls", "UTF-8") + "\"");		
		FileCopyUtils.copy(new FileInputStream(file), response.getOutputStream());
		return null;
	}
	
	//導出錯誤數據
	@RequestMapping(method=RequestMethod.GET,value="exportError.spr")
	public ModelAndView exportError(HttpServletRequest request,HttpServletResponse response) throws IOException {
		String filepath=request.getParameter("filepath");
		File file=new File(filepath);
		if(file.exists()){
			response.setContentType("application/vnd.ms-excel");
			response.setContentLength((int)file.length());
			response.setHeader("Content-Disposition","attachment; filename=\"" 
					+ URLEncoder.encode("errorData.xls", "UTF-8") + "\"");
			FileCopyUtils.copy(new FileInputStream(file), response.getOutputStream());
		}
		return null;
	}
	
	
}
