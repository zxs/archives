package com.foxconn.gds.sce.melp.organization.service.impl;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.organization.dao.OrganizationDao;
import com.foxconn.gds.sce.melp.organization.service.OrganizationService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * @author franco
 */
@Transactional
@Service(value = "organizationService")
public class OrganizationServiceImpl
        extends CrudServiceImpl<Organization, OrganizationDao> implements OrganizationService{


   //private final transient Logger logger = LoggerFactory.getLogger(OrganizationServiceImpl.class);

   @Autowired
   public void setOrganizationDao(OrganizationDao organizationDao) {
        this.daoSupport = organizationDao;
   }

    /**
    * Init method
    */
    public void init() {
        if (this.daoSupport == null) {
            String msg = "%s property must be set";
            throw new IllegalStateException(String.format(msg, "organizationDao"));
        }
    }

    @Transactional (readOnly = true)
    public List<Organization> getRootOrganizations() {
        return daoSupport.getRootOrganizations();
    }

    @Transactional (readOnly = true)
    public Organization getUserOrganization(String userId) {
        return daoSupport.getUserOrganization(userId);
    }

    @Transactional (readOnly = true)
    public List<Organization> getChildren(String organizatioId) {
        Organization organization = daoSupport.read(organizatioId);
        if (organization.getChildrenOrganizations() != null){
            return organization.getChildrenOrganizations();
        } else {
            return new ArrayList<Organization>();
        }

    }

    @Transactional (readOnly = true)
    public List<Organization> getOrganizations(Set<String> organizationIds) {
        return daoSupport.getOrganizations(organizationIds);
    }

    @Transactional (readOnly = true)
    public List<Organization> getOrganizations() {
        return daoSupport.getOrganizations();
    }

    /**
     * Adds a child organization (organization) to a parent organization (parentOrganization)
     * @param organization
     * @param parentOrganization
     */
    public void addChildToParentOrganization(Organization organization, Organization parentOrganization) {
        List<Organization> children = parentOrganization.getChildrenOrganizations();
        if (children == null){
            children = new ArrayList<Organization>();
            parentOrganization.setIsParentOrganization(true);
        }
        children.add(organization);
        parentOrganization.setIsParentOrganization(true);
        parentOrganization.setChildrenOrganizations(children);
        daoSupport.update(parentOrganization);
    }

    /**
     * Removes a child organization (organization) from its parent (parentOrganization)
     * @param organization
     * @param parentOrganization
     */
    public boolean removeChildFromParentOrganization(Organization organization, Organization parentOrganization) {
        List<Organization> children = parentOrganization.getChildrenOrganizations();
        boolean toReturn = false;
        if (children.isEmpty()){
            toReturn = children.remove(organization);
            if (children.size() == 0){
                parentOrganization.setIsParentOrganization(false);
            }
            daoSupport.update(parentOrganization);
        }

        return toReturn;
    }

    @Transactional
    public void create(Organization organization){
        organization.setEntityCreationTimestamp(new Date());
        organization.setEntityVersion(1);
        daoSupport.create(organization);
    }

    //TODO: Review this method to see if it makes sense and is required.
//    public boolean isCustomUserIdAvailable(String customUserId, String organizationId) {
//        return daoSupport.isCustomUserIdAvailable(customUserId, organizationId);
//    }

    //TODO: Review this method to see if it makes sense and is required.
//    public boolean isOrganizationNameAvailable(String organizationName, String parentId) {
//        return daoSupport.isOrganizationNameAvailable(organizationName, parentId);
//    }

      //TODO: Review this method to see if it makes sense and is required.
//    public List<Organization> getOrganizationsWithLogo() {
//        return daoSupport.getOrganizationsWithLogo();
//    }


}
