package com.foxconn.gds.sce.melp.courseInfo.service.impl;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.courseInfo.dao.CourseInfoDao;
import com.foxconn.gds.sce.melp.courseInfo.service.CourseInfoService;
import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.CourseInfo;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "courseInfoService")
public class CourseInfoServiceImpl extends CrudServiceImpl<CourseInfo, CourseInfoDao> implements CourseInfoService{

	@Autowired
	public void setIbCourseInfoDao(CourseInfoDao courseInfoDao){
		this.daoSupport=courseInfoDao;
	}

	@Override
	public DataTableReturn ListAllCourseInfo(DataTable dt) {
		// TODO Auto-generated method stub
		String userId="";
		if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userId="";
		}
		else
		{
			userId=SecurityUtils.getCurrentUser().getUserId();
		}
		//暂时没有用到userid,对角色对应资源的需求不了解。稍候添加
		
		DataTableReturn dtr=new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map<String,Object> params = new HashMap<String, Object>();
		params.put(DataTable.SEARCH, dt.getSearch());
		params.put("DT_USER", userId);
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		PaginatedResult<CourseInfo>  questions=daoSupport.ListAllCourseInfo(params, skipResults, maxResults);
		dtr.setAaData(questions.getResult());
		dtr.setiTotalDisplayRecords(questions.getTotalResults());
		dtr.setiTotalRecords(questions.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

	@Override
	public void saveOrUpdateCourseInfo(CourseInfo courseInfo) {
		// TODO Auto-generated method stub
		/*courseInfo.setCreateUser(SecurityUtils.getCurrentUser().getUsername());
		courseInfo.setModifyUser(SecurityUtils.getCurrentUser().getUsername());*///modified by lyl
		courseInfo.setCreateUser(SecurityUtils.getCurrentUser().getUserId());
		courseInfo.setModifyUser(SecurityUtils.getCurrentUser().getUserId());
		this.daoSupport.saveOrUpdateCourseInfo(courseInfo);
	}

	@Override
	public List<BaseCode> getCourseTypeSelect() {
		// TODO Auto-generated method stub
		return this.daoSupport.getCourseTypeSelect();
	}

	@Override
	public CourseInfo getCourseInfoById(String id) {
		// TODO Auto-generated method stub
		return this.daoSupport.getCourseInfoById(id);
	}

	@Override
	public void deleteCourseInfoById(String courseId) {
		// TODO Auto-generated method stub
		List<String> courseIdList = new ArrayList<String>();
		for(String courseIdTmp : courseId.split(",")){
			courseIdList.add(courseIdTmp);
		}
		this.daoSupport.deleteCourseInfoById(courseIdList);
	}

	@Override
	public void insertEvaluationItemsBatch(List<EvaluationItems> evaluationItems) {
		// TODO Auto-generated method stub
		this.daoSupport.insertEvaluationItemsBatch(evaluationItems);
	}

	@Override
	public Object inputStudentInfoExcel(InputStream inputStream, String courseId) throws Exception {
		// TODO Auto-generated method stub
		String message = "";
		Workbook workbook = new HSSFWorkbook(inputStream);
		int sheetCount = workbook.getNumberOfSheets();
		List<EvaluationItems> list = new ArrayList<EvaluationItems>();
		for(int i = 0; i < sheetCount; i ++){
			Sheet sheet = workbook.getSheetAt(i);
			String sheetName = sheet.getSheetName();
			if(sheet.getLastRowNum() > 1){
				Row titleRow = sheet.getRow(0);
				if(titleRow.getLastCellNum() != 2){
					message = sheetName + "sheet與模板格式不符!";
					return message;
				}else if(!titleRow.getCell(0).getStringCellValue().equals("評估部份") || !titleRow.getCell(1).getStringCellValue().equals("項目")){
					message = "請不要修改模板標題行內容!";
					return message;
				}
				for(int j = 1; j < sheet.getLastRowNum(); j ++){   //行
					Row row = sheet.getRow(j);
					String content = "";
					String partName = "";
					Object object = new Object();
					EvaluationItems evaluationItems = new EvaluationItems();
					for(int k = 0; k < row.getLastCellNum(); k++){ //列
						Cell cell = row.getCell(k);
						object = inputAndValidateExcelData(evaluationItems,cell.getStringCellValue(),j,k);
						if(object instanceof String){
							message = "第" + j + "行" + (String)object;
							return message;
						}
					}
					if(object instanceof EvaluationItems)
						evaluationItems = (EvaluationItems)object;
						evaluationItems.setCourseId(courseId);
						list.add((EvaluationItems) object);
					
				}
			}
		}
		return list;
	}
	/**
	 * 驗證excel表格內容並且設定值內容進入bean
	 *@author F3226075
	 *@date 2012-3-6 上午9:22:20
	 *@param content
	 *@param partName
	 */
	private Object inputAndValidateExcelData(EvaluationItems evaluationItems,String detail,int j,int k) {
		// TODO Auto-generated method stub
		String message = "";
		if(k == 0){
			if("".equals(detail)){
				message = "評估部份不能為空";
				return message;
			}else if(detail.length() > 50){
				message = "評估部份不能超過50個字符";
				return message;
			}else
				evaluationItems.setPartName(detail);
		}else if(k == 1){
			if("".equals(detail)){
				message = "項目不能為空";
				return message;
			}else if (detail.length() > 200){
				message = "項目不能超過200個字符";
				return message;
			}else
				evaluationItems.setContent(detail);
		}
		evaluationItems.setItemOrder(String.valueOf(j));
	/*	evaluationItems.setModifyUser(SecurityUtils.getCurrentUser().getUsername());
		evaluationItems.setCreateUser(SecurityUtils.getCurrentUser().getUsername()); modified by lyl 20120903*/
		evaluationItems.setModifyUser(SecurityUtils.getCurrentUser().getUserId());
		evaluationItems.setCreateUser(SecurityUtils.getCurrentUser().getUserId());
		return evaluationItems;
	}

	@Override
	public List<EvaluationItems> getEvaluationItemsByCourseId(String courseId) {
		// TODO Auto-generated method stub
		return this.daoSupport.getEvaluationItemsByCourseId(courseId);
	}

	@Override
	public void deleteEvaluationItems(String evCourseId) {
		// TODO Auto-generated method stub
		this.daoSupport.deleteEvaluationItems(evCourseId);
	}
}
