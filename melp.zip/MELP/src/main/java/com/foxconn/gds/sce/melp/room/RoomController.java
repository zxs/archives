package com.foxconn.gds.sce.melp.room;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.paper.service.PaperService;
import com.foxconn.gds.sce.melp.room.service.RoomService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;


@Controller
@RequestMapping(value="/room/**")
public class RoomController {
    private RoomService roomSrv;
    private PaperService paperSrv;

	@Autowired
    public void setRoomService(RoomService roomService){
        this.roomSrv=roomService;
    }
	
	@Autowired
    public void setPaperService(PaperService paperService){
        this.paperSrv=paperService;
    }
	
	@RequestMapping(method=RequestMethod.GET, value="ListAllRoom.spr")
	public ModelAndView listAllRooms(@RequestParam("iframe") String iframe) {
		return new ModelAndView("room/ListAllRoom", "iframe", "true".equals(iframe)?"true":"false");
	}
	
	@RequestMapping(method=RequestMethod.POST, value="ListAll.spr")
	public @ResponseBody Object ListAll(@RequestParam("_dt_json") String dtjso) {
		DataTable _dt= JackJson.fromJsonToObject(dtjso,DataTable.class);
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		DataTableReturn _returndt=roomSrv.ListAllRoom(_dt,userType);
		return _returndt;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="Add.spr")
	public ModelAndView addRoom() {
		return new ModelAndView();
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="insert.spr")
	public Map<String, String> insertRoom(HttpServletRequest req) throws Exception {
		ExamRoom roomInfo=new ExamRoom();
		String _roomid= roomSrv.GetMaxRoomID();
		roomInfo.setId(_roomid);
		roomInfo.setPaperId(req.getParameter("papername"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			roomInfo.setStartTime(sdf.parse(req.getParameter("startime")));
			roomInfo.setEndTime(sdf.parse(req.getParameter("endtime")));
		} catch (ParseException e) {
		
		}
		roomInfo.setRoom(req.getParameter("room"));
		roomInfo.setIsSync(req.getParameter("issync")==null?"0":"1");
		String _name=SecurityUtils.getCurrentUser().getUserId().toUpperCase();
		roomInfo.setCreator(_name);
		Map<String, String> _toJson=new HashMap<String, String>();
		try {
			roomSrv.InsertRoom(roomInfo);
			_toJson.put("status", "true");
			_toJson.put("msg", "新增考場成功");
		} catch (Exception e) {
			_toJson.put("status", "false");
			_toJson.put("msg", "新增考場失敗");
		}
		return _toJson;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="ListPaperIDName.spr")
	public List<PaperInfo> ListPaperIDName()
	{
		PaperInfo _paperInfo=new PaperInfo();
		String _name=SecurityUtils.getCurrentUser().getUserId();
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		if(userType!=0)
		   _paperInfo.setCreateor(_name.toUpperCase());
		List<PaperInfo> _listInfos= paperSrv.QueryPaperNameID(_paperInfo);
		return _listInfos;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="queryPaperInfoByID.spr")
	public PaperInfo queryPaperInfoByID(HttpServletRequest req) {
		String _id= req.getParameter("id")==null?"":req.getParameter("id");
		PaperInfo _paperInfo=new PaperInfo();
		_paperInfo.setId(_id);
		return paperSrv.QueryPaperByPara(_paperInfo);
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="updateRoom.spr")
	public Map<String, String> updateRoom(HttpServletRequest req)
	{
		String _id= req.getParameter("autoid");
		ExamRoom _room=new ExamRoom();
		_room.setId(_id);
		_room.setPaperId(req.getParameter("papername"));
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		try {
			_room.setStartTime(sdf.parse(req.getParameter("startime")));
			_room.setEndTime(sdf.parse(req.getParameter("endtime")));
		} catch (ParseException e) {
		}
		_room.setRoom(req.getParameter("room"));
		
		_room.setIsSync(req.getParameter("issync")==null?"0":"1");
		String _name= SecurityUtils.getCurrentUser().getUserId();
		_room.setModifier(_name.toUpperCase());
		Map<String, String> _toJson=new HashMap<String, String>();
		if(roomSrv.UpdateRoom(_room))
		{
			_toJson.put("status", "true");
			_toJson.put("msg", "編輯成功");
		}
		else {
			_toJson.put("status", "false");
			_toJson.put("msg", "編輯失敗");
		}
		return _toJson;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="selByForUpdate.spr")
	public ExamRoom selByForUp(HttpServletRequest req) {
		String _id= req.getParameter("id");
		ExamRoom _roomInfo=new ExamRoom();
		_roomInfo.setId(_id);
		return roomSrv.QueryRoomByPara(_roomInfo);
	}	
	

	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="deleteroom.spr")
	public Map<String, String> deletePaper(HttpServletRequest req) {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _id= req.getParameter("id");
			ObjectMapper mapper=new ObjectMapper();
			List<String> _Str=mapper.readValue(_id,List.class);
			List<ExamRoom> _list= new LinkedList<ExamRoom>();
			ExamRoom exRoom=null;
			String _modifier= SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<_Str.size();i++){
				exRoom = new ExamRoom();
				exRoom.setId(_Str.get(i).toString());
				exRoom.setModifier(_modifier);
				_list.add(exRoom);
			}
		    roomSrv.DeleteRoom(_list);
		    _reHashMap.put("status", "true");
		    _reHashMap.put("msg", "刪除成功");
		} catch (Exception e) {
			_reHashMap.put("status", "false");
	        _reHashMap.put("msg", "刪除失敗");
		}
	    return _reHashMap;
	}	
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="getMaxRoomID.spr")
	public Map<String, String> GetMaxRoomID() {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _roomid= roomSrv.GetMaxRoomID();
	        _reHashMap.put("msg", _roomid);
		} catch (Exception e) {
	        _reHashMap.put("msg", "");
		}
		return _reHashMap;
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="updateSync.spr")
	public Map<String, String> updateSync(HttpServletRequest req) {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _str= req.getParameter("jsonstr");
			String _issync=req.getParameter("issync");
			ObjectMapper mapper=new ObjectMapper();
			List<String> _Strs=mapper.readValue(_str,List.class);
			List<ExamRoom> _list= new LinkedList<ExamRoom>();
			ExamRoom exRoom=null;
			String _modifier=SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<_Strs.size();i++){
				exRoom = new ExamRoom();
				exRoom.setId(_Strs.get(i).toString());
				exRoom.setIsSync(_issync);
				exRoom.setModifier(_modifier);
				_list.add(exRoom);
			}
			roomSrv.UpdateSync(_list);
			_reHashMap.put("status", "true");
	        _reHashMap.put("msg",_issync);
		} catch (Exception e) {
			_reHashMap.put("status", "false");
	        _reHashMap.put("msg", "設置失敗");
		}
		return _reHashMap;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="addPersonToRoom.spr")
	public Map<String, String> addPersonToRoom(HttpServletRequest req) {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _personArr= req.getParameter("personArr");
			String _roomid=req.getParameter("roomid");
			ObjectMapper mapper=new ObjectMapper();
			List<String> _Str=mapper.readValue(_personArr,List.class);
			List<Examinees> _list= new LinkedList<Examinees>();
			Examinees examinees=null;
			String creator=SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<_Str.size();i++){
				examinees = new Examinees();
				examinees.setEmpNo(_Str.get(i).toString());
				examinees.setExamRoomId(_roomid);
				examinees.setCreator(creator);
				_list.add(examinees);
			}
			roomSrv.InsertExaminees(_list);
			_reHashMap.put("status", "true");
	        _reHashMap.put("msg","添加考生名單成功");
		} catch (Exception e) {
			_reHashMap.put("status", "false");
	        _reHashMap.put("msg","添加考生名單失敗");
		}
		return _reHashMap;
	}

	@RequestMapping(method=RequestMethod.POST, value="ListExaminees.spr")
	public @ResponseBody Object ListAllExaminees(@RequestParam("_dt_json") String dtjso,HttpServletRequest req) {
		DataTable _dt= JackJson.fromJsonToObject(dtjso,DataTable.class);
		String _roomid=req.getParameter("roomid");
		DataTableReturn _returndt=roomSrv.ListAllExaminees(_dt,_roomid);
		return _returndt;
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="delPerFromRoom.spr")
	public Map<String, String> DelPerFromRoom(HttpServletRequest req) {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _id= req.getParameter("personArr");
			ObjectMapper mapper=new ObjectMapper();
			List<String> _Str=mapper.readValue(_id,List.class);
			List<Examinees> _list= new LinkedList<Examinees>();
			Examinees examinees=null;
			String _modifier= SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<_Str.size();i++){
				examinees = new Examinees();
				examinees.setId(_Str.get(i).toString());
				examinees.setModifier(_modifier);
				_list.add(examinees);
			}
		    roomSrv.DelPerFromRoom(_list);
		    _reHashMap.put("status", "true");
		    _reHashMap.put("msg", "刪除成功");
		} catch (Exception e) {
			_reHashMap.put("status", "false");
	        _reHashMap.put("msg", "刪除失敗");
		}
	    return _reHashMap;
	}
	

	@RequestMapping(method=RequestMethod.GET, value="expRoomPer.spr")
	public ModelAndView expRoomPer(HttpServletRequest req,HttpServletResponse response) {
		String _roomid=req.getParameter("roomid");
		Integer _count=0;
		try {
			List<Examinees> _lists=roomSrv.exportRoomPerson(_roomid);
			OutputStream fout =response.getOutputStream();
			response.reset();
            String filename="student.xls";
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-Disposition", "attachment;filename="+ new String(filename.getBytes(), "ISO8859-1"));
		
			HSSFWorkbook wb = new HSSFWorkbook();
		    HSSFSheet sheet = wb.createSheet("學生名單");
		    HSSFRow row = sheet.createRow((int)0);
		    HSSFCellStyle style = wb.createCellStyle();
	        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			HSSFCell cell = row.createCell(0);
	        cell.setCellValue("工號"); cell.setCellStyle(style);
	        cell = row.createCell(1);
	        cell.setCellValue("姓名"); cell.setCellStyle(style);
	        cell = row.createCell(2);
	        cell.setCellValue("部門"); cell.setCellStyle(style);
	        cell = row.createCell(3);
	        cell.setCellValue("角色"); cell.setCellStyle(style);
	        for(int i=0;i<_lists.size();i++){
	            row = sheet.createRow((int)i+1);
	            Examinees stu = (Examinees)_lists.get(i);
	            row.createCell(0).setCellValue(stu.getEmpNo());
	            row.createCell(1).setCellValue(stu.getEmpName());
	            row.createCell(2).setCellValue(stu.getDeptName());
	            row.createCell(3).setCellValue(stu.getRoleName());
	        }
            wb.write(fout);
            fout.close();
		}
		catch(Exception e)
		{}
		return new ModelAndView();
	}
	
}
		
	
