package com.foxconn.gds.sce.melp.model;

public class StudyRecord extends BasicEntity {
	private  String CLASS_NO;
	private  String CLASS_NAME;
	private  String EMP_NO;
	private  String STUDY_START_TIME;
	private  String STUDY_END_TIME;
	private  String COURSE_NAME;
	private  String STUDY_HOUR;
	private  String COURSE_HOUR;
	private  String USERNAME;
	private  String CREATE_USER;
	
	public String getCLASS_NO() {
		return CLASS_NO;
	}
	public void setCLASS_NO(String CLASS_NO) {
		this.CLASS_NO = CLASS_NO;
	}
	
	public String getCLASS_NAME() {
		return CLASS_NAME;
	}
	public void setCLASS_NAME(String CLASS_NAME) {
		this.CLASS_NAME = CLASS_NAME;
	}
	
	public String getEMP_NO() {
		return EMP_NO;
	}
	public void setEMP_NO(String EMP_NO) {
		this.EMP_NO = EMP_NO;
	}
	
	
	public String getSTUDY_START_TIME() {
		return STUDY_START_TIME;
	}
	public void setSTUDY_START_TIME(String STUDY_START_TIME) {
		this.STUDY_START_TIME = STUDY_START_TIME;
	}
	
	public String getSTUDY_END_TIME() {
		return STUDY_END_TIME;
	}
	public void setSTUDY_END_TIME(String STUDY_END_TIME) {
		this.STUDY_END_TIME = STUDY_END_TIME;
	}
	
	
	public String getCOURSE_NAME() {
		return COURSE_NAME;
	}
	public void setCOURSE_NAME(String COURSE_NAME) {
		this.COURSE_NAME = COURSE_NAME;
	}
	
	public String getSTUDY_HOUR() {
		return STUDY_HOUR;
	}
	public void setSTUDY_HOUR(String STUDY_HOUR) {
		this.STUDY_HOUR = STUDY_HOUR;
	}
	
	
	public String getCOURSE_HOUR() {
		return COURSE_HOUR;
	}
	public void setCOURSE_HOUR(String COURSE_HOUR) {
		this.COURSE_HOUR = COURSE_HOUR;
	}
	
	public String getUSERNAME() {
		return USERNAME;
	}
	public void setUSERNAME(String USERNAME) {
		this.USERNAME = USERNAME;
	}
	
	public String getCREATE_USER() {
		return CREATE_USER;
	}
	public void setCREATE_USER(String CREATE_USER) {
		this.CREATE_USER = CREATE_USER;
	}
	
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
