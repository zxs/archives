package com.foxconn.gds.sce.melp.learnCourse.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.foxconn.gds.sce.melp.learnCourse.dao.LearnCourseDao;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value = "ibLeranCourseDao")
public class IbLearnCourseDao extends GenericDaoIbatisImpl<MyClassInfo, String>
		implements LearnCourseDao {

	@Autowired
	public IbLearnCourseDao(SqlMapClient sqlMapClient) {
		super(MyClassInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<MyClassInfo> listCourse(String empNo) {
		// TODO Auto-generated method stub
	/*	if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
        empNo="Admin"; 
		}*///modified by lyl
		return (List<MyClassInfo>) getSqlMapClientTemplate().queryForList(
				"listCourseByEmpNo", empNo);

	}
	public Boolean insertRecord(String empNo,String coursewareUrl,String uuid,String classNo) {
		// TODO Auto-generated method stub
	Map map=new HashMap();
	map.put("empNo", empNo);
	map.put("coursewareUrl", coursewareUrl);
	map.put("uuid", uuid);
	map.put("classNo", classNo);
	try {
		  getSqlMapClientTemplate().insert(
				"insertLearnRecord",map);
return true;
	} catch (Exception e) {
		return false;
	}
	}
	public Boolean updateRecord(String empNo,String coursewareUrl,String uuid,String classNo) {
		// TODO Auto-generated method stub
	Map map=new HashMap();
	map.put("empNo", empNo);
	map.put("coursewareUrl", coursewareUrl);
	map.put("uuid", uuid);
	map.put("classNo", classNo);
	try {
		  getSqlMapClientTemplate().update(
				"updateLearnRecord",map);
return true;
	} catch (Exception e) {
		return false;
	}
	}
}


