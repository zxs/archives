package com.foxconn.gds.sce.melp.queryScore.dao.ibatis;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;


import com.foxconn.gds.sce.melp.model.VO_Front_ViewExam;
import com.foxconn.gds.sce.melp.queryScore.dao.QueryScoreDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibQueryScoreDao")
public class IbQueryScoreDao extends GenericDaoIbatisImpl<VO_Front_ViewExam, String> implements QueryScoreDao {
	
	@Autowired
	public IbQueryScoreDao(SqlMapClient sqlMapClient) {
		super(VO_Front_ViewExam.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<VO_Front_ViewExam> QueryScoreRecords(VO_Front_ViewExam exam,int userType) {
		// TODO Auto-generated method stub
		List<VO_Front_ViewExam> examRes=null;
		if(userType==0){
			examRes =getSqlMapClientTemplate().queryForList("select_score_paperName_byAdmin",exam);
		}else if(userType==1){
			examRes =getSqlMapClientTemplate().queryForList("select_score_paperName_byExamer",exam);
		}else if(userType==2){
			examRes =getSqlMapClientTemplate().queryForList("select_score_paperName_byExaminees",exam);
		}else{
			examRes = new LinkedList<VO_Front_ViewExam>();
		}
		return examRes;
	}

	public VO_Front_ViewExam QueryScoreTitle(VO_Front_ViewExam score) {
		// TODO Auto-generated method stub
		VO_Front_ViewExam title=(VO_Front_ViewExam)getSqlMapClientTemplate().queryForObject("select_score_title",score);
		return title;
	}
	
	public List<VO_Front_ViewExam> QueryScoreContent(VO_Front_ViewExam exam) {
		// TODO Auto-generated method stub
		List<VO_Front_ViewExam> examRes=getSqlMapClientTemplate().queryForList("select_score_content",exam);
		return examRes;
	}
}
