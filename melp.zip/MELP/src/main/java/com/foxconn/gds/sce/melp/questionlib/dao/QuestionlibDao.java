
package com.foxconn.gds.sce.melp.questionlib.dao;


import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.VO_QuestonOption;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;



public interface QuestionlibDao extends  GenericDao<QuestionLib, String> {
//   List<QuestionLib> listByNull();
   List<QuestionLib> findAllByCondition(QuestionLib questionLib);
   
   public PaginatedResult<QuestionLib> findAllQuestionLib(Map parameters, int skipResults, int maxResults);
   
   //查詢所有試題
   public PaginatedResult<Question> findAllQuestion( Map parameters,int skipResults, int maxResults );
   
   
   
   public boolean insertLib(QuestionLib questionLib) ;
   
   public  boolean updateLib(QuestionLib questionLib);
   
   public List<Question> findAllQustionByLibID(Question question);
   
   //新增試題
   public boolean insertQuestion(Question question) ;
   
   //新增選項
   public boolean insertOption(QuestionOptions questionOptions);
   
   //根據試題ID查出所有選項
   public  List<VO_QuestonOption> findByQuestionID ( VO_QuestonOption vo_QuestonOption) ;

   public boolean delQuestionByID(Question question);
   
 //根據題目ID刪除選項
   public  boolean delOptionByID(Question question);
   
   
   //根據選項ID刪除選項
   public  boolean delOptionByID(String optionid); 
   
   public boolean delQuestionLib(QuestionLib questionLib);
   
   //導入時插入試題
   public void importTitle(final List<Map> titleList);
   
   //導入時插入選項
   public void importOption(final List<Map> optionList);
   
   //查詢試題庫是否有試卷
   public Object findPaperByLibid(String libid);
   
   //導出
   public  List<Map> exports(Map paraMap);
}
