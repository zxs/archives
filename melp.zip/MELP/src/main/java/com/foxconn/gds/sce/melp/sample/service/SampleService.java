package com.foxconn.gds.sce.melp.sample.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface SampleService extends CrudService<User>{

	public User addUser(User nUser);
	
	public List<User> listAllUser();
}
