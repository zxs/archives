package com.foxconn.gds.sce.melp.model;

import java.util.Date;

public class MyClassInfo extends CourseInfo {
private String classNo;
private String teacher;
private String className;
private Date startTime;
private Date endTime;
private Date learnStartTime;
private Date learnEndTime;
//private float learnHour;
private String  learnHour; //modified by lyl
private String classID;
private Integer evaTimes = null;
public Integer getEvaTimes() {
	return evaTimes;
}
public void setEvaTimes(Integer evaTimes) {
	this.evaTimes = evaTimes;
}
private String evSettings;
private String isLearned;
public String getIsLearned() {
	return isLearned;
}
public void setIsLearned(String isLearned) {
	this.isLearned = isLearned;
}
public String getEvSettings() {
	return evSettings;
}
public void setEvSettings(String evSettings) {
	this.evSettings = evSettings;
}
public String getClassID() {
	return classID;
}
public void setClassID(String classID) {
	this.classID = classID;
}
public String getLearnHour() {
	return learnHour;
}
public void setLearnHour(String learnHour) {
	this.learnHour = learnHour;
}
public Date getLearnStartTime() {
	return learnStartTime;
}
public void setLearnStartTime(Date learnStartTime) {
	this.learnStartTime = learnStartTime;
}
public Date getLearnEndTime() {
	return learnEndTime;
}
public void setLearnEndTime(Date learnEndTime) {
	this.learnEndTime = learnEndTime;
}
public Date getStartTime() {
	return startTime;
}
public void setStartTime(Date startTime) {
	this.startTime = startTime;
}
public Date getEndTime() {
	return endTime;
}
public void setEndTime(Date endTime) {
	this.endTime = endTime;
}
public String getTeacher() {
	return teacher;
}
public void setTeacher(String teacher) {
	this.teacher = teacher;
}
public String getClassNo() {
	return classNo;
}
public void setClassNo(String classNo) {
	this.classNo = classNo;
}
public String getClassName() {
	return className;
}
public void setClassName(String className) {
	this.className = className;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public String getCourseType() {
	return courseType;
}
public void setCourseType(String courseType) {
	this.courseType = courseType;
}


@Override
public boolean onEquals(Object o) {
	// TODO Auto-generated method stub
	return false;
}
@Override
public int onHashCode() {
	// TODO Auto-generated method stub
	return 0;
}

}
