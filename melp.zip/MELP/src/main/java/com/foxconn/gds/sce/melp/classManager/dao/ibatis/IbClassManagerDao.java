package com.foxconn.gds.sce.melp.classManager.dao.ibatis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.classManager.dao.ClassManagerDao;
import com.foxconn.gds.sce.melp.model.BasicEntity;
import com.foxconn.gds.sce.melp.model.ClassInfo;
import com.foxconn.gds.sce.melp.model.ClassMember;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

/**
 * 班級管理
 * Dao層實現類
 * @author F3228777
 *
 */
@SuppressWarnings("unchecked")
@Repository("classManagerDao")
public class IbClassManagerDao extends GenericDaoIbatisImpl<ClassInfo, String> implements ClassManagerDao{

	private static Log log = LogFactory.getLog(ClientUtil.class);
	
	@Autowired
    public IbClassManagerDao(SqlMapClient sqlMapClient) {
		super(ClassInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	/**
	 * 新增班級信息
	 */
	@Override
	public void saveClassInfo(ClassInfo classInfo) {
			getSqlMapClientTemplate().insert("saveClassInfo", classInfo);
	}

	/**
	 * 顯示班級信息列表
	 */
	@SuppressWarnings({ "rawtypes" })
	@Override
	public PaginatedResult<ClassInfo> showAllClassInfoList(Map parameters,
			int skipResults, int maxResults) {
		int page = skipResults/maxResults; 
		int pageSize = maxResults;
		PaginatedResult<ClassInfo> classInfo = new PaginatedResult<ClassInfo>(page, pageSize);
		List<ClassInfo> result=null;
		if(maxResults<0) { 
			result = getSqlMapClientTemplate().queryForList("getAllClassInfo", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("getAllClassInfo", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("getAllClassInfoCount", parameters);
		classInfo.setResult(result);
		classInfo.setTotalResults(count);
		return classInfo;
	}

	/**
	 * 判斷班級編號是否已存在
	 */
	@Override
	public int isClassNoExist(String classNo) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classNo", classNo);
		return  (Integer) getSqlMapClientTemplate().queryForObject("isClassNoExist",map);
	}

	/**
	 * 判斷修改之后的班級編號是否已經存在,用于修改班級信息
	 */
	@Override
	public int isClassNoExistForUpdate(String classNo,String classId) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classNo", classNo);
		map.put("classId", classId);
		return  (Integer) getSqlMapClientTemplate().queryForObject("isClassNoExistForUpdate",map);
	}
	
	/**
	 * 修改班級信息
	 */
	@Override
	public void updateClassInfo(ClassInfo classInfo) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classId", classInfo.getClassId());
		map.put("classNo", classInfo.getClassNo());
		map.put("className", classInfo.getClassName());
		map.put("startTime", classInfo.getStartTime());
		map.put("endTime", classInfo.getEndTime());
		map.put("courseId", classInfo.getCourseId());
		map.put("modifyUser", classInfo.getModifyUser());
		getSqlMapClientTemplate().update("updateClassInfo", map);
	}

	/**
	 * 刪除班級信息
	 */
	@Override
	public void deleteClassInfo(ClassInfo classInfo) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classId", classInfo.getClassId());
		map.put("modifyUser", classInfo.getModifyUser());
		getSqlMapClientTemplate().update("deleteClassInfo", map);
	}

	/**
	 * 預覽班級信息
	 */
	@Override
	public ClassInfo checkClassInfo(String classId) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classId", classId);
		return (ClassInfo)getSqlMapClientTemplate().queryForObject("checkClassInfo", map);
	}

	/**
	 * 通過classId獲取指定班級的學員人數
	 */
	@Override
	public int getStudentCountByClassId(String classId) {
		Map<String,String> map = new HashMap<String,String>();
		map.put("classId", classId);
		return (Integer)getSqlMapClientTemplate().queryForObject("getStudentCountByClassId", map);
	}

	/**
	 * 獲取指定班級的學員列表
	 */
	@Override
	public PaginatedResult<ClassMember> getStudentListByClassId(Map map,
			int skipResults, int maxResults) {
		int page = skipResults/maxResults; 
		int pageSize = maxResults;
		PaginatedResult<ClassMember> studentInfo = new PaginatedResult<ClassMember>(page, pageSize);
		List<ClassMember> result=null;
		if(maxResults<0) { 
			result = getSqlMapClientTemplate().queryForList("getStudentListByClassId", map);			
		} else {
			result = getSqlMapClientTemplate().queryForList("getStudentListByClassId", map, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("getStudentCountByClassId", map);
		studentInfo.setResult(result);
		studentInfo.setTotalResults(count);
		return studentInfo;
	}

	/**
	 * 為班級添加學員名單
	 */
	@Override
	public void addPersonToClass(final List<ClassMember> classMemberlist) {
		try {
			if (classMemberlist != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(final SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = classMemberlist.size(); i < n; i++) {
	                         executor.insert("addPersonToClass", classMemberlist.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [addPersonToClass], parameterObject ["+ classMemberlist + "].  Cause: "+ e.getMessage());
	           }
		}
		
	}

	/**
	 * 從班級中刪除學員名單
	 */
	@Override
	public void delClassMemberFromClass(final List<ClassMember> classMemberList) {
		try {
			if (classMemberList != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = classMemberList.size(); i < n; i++) {
	                         executor.update("delClassMemberFromClass", classMemberList.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [delClassMemberFromClass], parameterObject ["+ classMemberList + "].  Cause: "+ e.getMessage());
	           }
		} 
		
	}

	/**
	 * 導出學員名單
	 */
	@Override
	public List<ClassMember> getClassMemberListForExp(String classId) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("classId", classId);
		List<ClassMember> classMemberList = (List<ClassMember>)getSqlMapClientTemplate().queryForList("getStudentListByClassId",map);
	    return classMemberList;
	}
	
	/**
	 * 通過id獲取課程相關信息
	 */
	@Override
	public ClassInfo getCourseInfoById(ClassInfo classInfo){
		Map<String, String> map = new HashMap<String, String>();
		map.put("courseId", classInfo.getCourseId());
		return (ClassInfo) getSqlMapClientTemplate().queryForObject("getCourseInfoByCourseId", map);
	}

	@Override
	public List<ClassInfo> getAutoClassNo() {

		return (List<ClassInfo>) getSqlMapClientTemplate().queryForList("getAutoClassNo");
	}
	
	@Override
	public String getCurrentDate() {

		return  (String) getSqlMapClientTemplate().queryForObject("getCurrentDate");
	}
	
}
