package com.foxconn.gds.sce.melp.roomRecord;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.roomRecord.service.ExamineesRecordService;
import com.foxconn.gds.sce.melp.roomRecord.service.RoomRecordService;
import com.foxconn.gds.sce.melp.sample.service.SampleService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;

@Controller
@RequestMapping(value="/roomRecord/**")
public class RoomRecordController {
	
	private RoomRecordService roomService;	
	@Autowired
	public void setRoomRecordService(RoomRecordService roomRecordService)
	{
		this.roomService=roomRecordService;
	}
	
	private ExamineesRecordService examineesService;
	@Autowired
	public void setExamineesRecordService(ExamineesRecordService examineesRecordService){
		this.examineesService=examineesRecordService;
	}
	
	//考場記錄頁面
	@RequestMapping(method={RequestMethod.GET}, value="roomRecordSearch.spr")
	public ModelAndView ShowRoomRecordSearchView()
	{
		return new ModelAndView("roomRecord/roomRecordSearch");
	}
	
	//點擊考場記錄按鈕出現考場記錄編輯頁面
	@RequestMapping(method={RequestMethod.GET}, value="roomRecordUpdate.spr")
	public ModelAndView ShowRoomRecordUpdateView(HttpServletRequest  request)
	{
		String roomId=request.getParameter("roomId");
		ModelAndView mv = new ModelAndView();
		mv.addObject("roomid", roomId);
		return mv;
	}
	
	//考場記錄主頁面查詢，根據考卷名稱
	@RequestMapping(method=RequestMethod.POST,headers="Accept=application/json",value="searchResult.spr")
	@ResponseBody
	public  List<ExamRoom> QueryAllByPaperName(HttpServletRequest  request) throws UnsupportedEncodingException
	{
		String loger=SecurityUtils.getCurrentUser().getUserId();
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		request.setCharacterEncoding("UTF-8");
		String paper_name=request.getParameter("examName");
		ExamRoom er=new ExamRoom();
		er.setPaperName(paper_name);
		er.setCreator(loger);
 		List<ExamRoom> rooms = this.roomService.QueryAllBy(er,userType);
// 		Map m=new HashMap();
// 		m.put("total", 2); 		
// 		m.put("rows", rooms);
		return rooms;
	}
	
	//點擊考場記錄按鈕,根據工號和姓名查詢
	@RequestMapping(method={RequestMethod.GET}, value="queryExaminees.spr")
	@ResponseBody
	public List<Examinees> QueryExamineesRecord(HttpServletRequest  request) throws Exception
	{
		String roomID=request.getParameter("roomID");
		String empNo=request.getParameter("empNo");
		String empName=request.getParameter("empName");//request.getParameter("empName");
		empName = new String(empName.getBytes("iso8859-1"), "utf-8");
		Examinees examinees = new Examinees();
		examinees.setExamRoomId(roomID);
		examinees.setEmpNo(empNo);
		examinees.setEmpName(empName);
		List<Examinees> innes = this.examineesService.Query_ExamineesByRoomid(examinees);
		return innes;
	}
	
	//更新考場記錄
	@RequestMapping(method={RequestMethod.POST}, value="updateExaminees.spr")
	@ResponseBody
	public HashMap<String,String> UpdateExamIneesRecord(HttpServletRequest  request) throws JsonParseException, JsonMappingException, IOException
	{
		String records=request.getParameter("json");
		List<Examinees> innes=new LinkedList<Examinees>();
		Examinees examinees = null;		
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true); 
		try {
			@SuppressWarnings("unchecked")
			List<Map<String, Examinees>> rawContatcs = mapper.readValue(records, List.class);			
			for (Map<String, Examinees> item : rawContatcs) {
				examinees = new Examinees();
				if(String.valueOf(item.get("examRoomId"))!=null)
				{		
					examinees.setExamRoomId(String.valueOf(item.get("examRoomId")));
				}
				if(String.valueOf(item.get("empNo"))!=null)
				{					
					examinees.setEmpNo(String.valueOf(item.get("empNo")));
				}	
				if(String.valueOf(item.get("status"))!=null)
				{					
					examinees.setStatus(String.valueOf(item.get("status")));
				}	
				examinees.setModifier(ClientUtil.getCurrentUser().getUserId());
				innes.add(examinees);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
			
		int flag = this.examineesService.UpdateExaminees(innes);
		HashMap<String,String> resultMap=new HashMap<String,String>();
		if(flag==1){
			resultMap.put("success", "true");
			resultMap.put("message", "更新成功");
		}
		else{
			resultMap.put("success", "false");
			resultMap.put("message", "更新失敗");
		}
		return resultMap;
	}
}
