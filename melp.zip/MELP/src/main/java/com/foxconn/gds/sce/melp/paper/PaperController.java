package com.foxconn.gds.sce.melp.paper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.security.Principal;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.paper.service.PaperService;
import com.foxconn.gds.sce.melp.questionlib.service.QuestionlibService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;


@Controller
@RequestMapping(value="/paper/**")
public class PaperController {
	
	private PaperService paperService;
	
	@Autowired
	public void setPaperService(PaperService paperService) {
	     this.paperService = paperService;
     }
    private QuestionlibService questionlibSrv;
	@Autowired
	public void setQuestionlibSrv(QuestionlibService questionlibSrv) {
		this.questionlibSrv = questionlibSrv;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="ListAllPaper.spr")
	public ModelAndView listAllPapers(@RequestParam("iframe") String iframe) {
		return new ModelAndView("paper/ListAllPaper", "iframe", "true".equals(iframe)?"true":"false");
	}

	@RequestMapping(method=RequestMethod.POST, value="ListAll.spr")
	public @ResponseBody Object listAll(@RequestParam("_dt_json") String dtjso) {
		DataTable _dt= JackJson.fromJsonToObject(dtjso,DataTable.class);
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		DataTableReturn _returndt=paperService.ListAllPaper(_dt,userType);
		return _returndt;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="AddPaper.spr")
	public ModelAndView addPaper() {
		return new ModelAndView();
	}	
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="insertPaper.spr")
	public Map<String, String> insertPaper(HttpServletRequest req) {
		PaperInfo paperInfo=new PaperInfo();
    	paperInfo.setPaperName(req.getParameter("papername"));
    	paperInfo.setQuestionLibId(req.getParameter("libname"));
    	paperInfo.setExamTimesMax(new BigDecimal(req.getParameter("exammax"))); 
    	paperInfo.setTimeTotal(new BigDecimal(req.getParameter("timetotal")));
    	paperInfo.setPassScore(new BigDecimal(req.getParameter("passsore")));
    	paperInfo.setNumberS(new BigDecimal(req.getParameter("snum")));
    	paperInfo.setNumberM(new BigDecimal(req.getParameter("mnum")));
    	paperInfo.setNumberTf(new BigDecimal(req.getParameter("ifnum")));
    	paperInfo.setScoreS(new BigDecimal(req.getParameter("sscore")));
    	paperInfo.setScoreM(new BigDecimal(req.getParameter("mscore")));
    	paperInfo.setScoreTf(new BigDecimal(req.getParameter("ifscore")));
        String _currentUser=SecurityUtils.getCurrentUser().getUserId();
        
    	paperInfo.setCreateor(_currentUser.toUpperCase());
    	Map<String, String> toJson = new HashMap<String, String>();
    	try {
    		paperService.InsertPaper(paperInfo);
    		toJson.put("status", "true");
        	toJson.put("msg", "新增試卷成功");
		} catch (Exception e) {
			toJson.put("status", "false");
        	toJson.put("msg", "新增試卷失敗");
		}
		return toJson;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="ListLibIDName.spr")
	public List<QuestionLib> listAllLibIDName() {
		QuestionLib _lib= new QuestionLib();
		String _name=SecurityUtils.getCurrentUser().getUserId();
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		if(userType!=0)
		   _lib.setCreator(_name.toUpperCase());
		List<QuestionLib> _listLibs= questionlibSrv.findAllByCondition(_lib);
		return _listLibs;
	}
	
	@SuppressWarnings("unchecked")
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="IsPaperExist.spr")
	public Map<String, String> IsPaperExist(HttpServletRequest req) throws UnsupportedEncodingException 
	{
		String _str=req.getParameter("papername");
		String _autoid=req.getParameter("autoid");
		String _name= SecurityUtils.getCurrentUser().getUserId();
		PaperInfo paperinfo=new PaperInfo();
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		if(userType!=0)
			paperinfo.setCreateor(_name.toUpperCase());
		paperinfo.setPaperName(_str);
		paperinfo.setId(_autoid);    
		Map<String, String> _reHashMap=new HashMap<String, String>();
		if(paperService.IsPaperExist(paperinfo))
			_reHashMap.put("status", "true");
		else 
			_reHashMap.put("status", "false");
		return _reHashMap;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="delete.spr")
	public Map<String, String> deletePaper(HttpServletRequest req) {
		Map<String, String> _reHashMap=new HashMap<String, String>();
		try {
			String _id= req.getParameter("id");
			ObjectMapper mapper=new ObjectMapper();
			List<String> _Str=mapper.readValue(_id,List.class);
			List<PaperInfo> _list= new LinkedList<PaperInfo>();
			PaperInfo papers=null;
			String _modifier= SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<_Str.size();i++){
				papers = new PaperInfo();
				papers.setId(_Str.get(i).toString());
				papers.setModifier(_modifier);
				_list.add(papers);
			}
			paperService.DeletePaper(_list);
		    _reHashMap.put("status", "true");
		    _reHashMap.put("msg", "刪除成功");
		} catch (Exception e) {
			_reHashMap.put("status", "false");
	        _reHashMap.put("msg", "刪除失敗");
		}
	    return _reHashMap;
	}	
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="updatePaper.spr")
	public PaperInfo updatePaper(HttpServletRequest req) {
		String _id= req.getParameter("id");
		PaperInfo _paperInfo=new PaperInfo();
		_paperInfo.setId(_id);
		return paperService.QueryPaperByPara(_paperInfo);
	}	
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="queryLibNumByID.spr")
	public PaperInfo queryLibNumByID(HttpServletRequest req) {
		String _id= req.getParameter("id");
		PaperInfo _paperInfo=new PaperInfo();
		_paperInfo.setQuestionLibId(_id);
		return paperService.QueryLibNumByID(_paperInfo);
	}	
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="update.spr")
	public HashMap<String, String> update(HttpServletRequest req) {
		PaperInfo paperInfo=new PaperInfo();
		String _id= req.getParameter("autoid");
		paperInfo.setId(req.getParameter("autoid"));
    	paperInfo.setPaperName(req.getParameter("papername"));
    	paperInfo.setQuestionLibId(req.getParameter("libname"));
    	paperInfo.setExamTimesMax(new BigDecimal(req.getParameter("exammax"))); 
    	paperInfo.setTimeTotal(new BigDecimal(req.getParameter("timetotal")));
    	paperInfo.setPassScore(new BigDecimal(req.getParameter("passsore")));
    	paperInfo.setNumberS(new BigDecimal(req.getParameter("snum")));
    	paperInfo.setNumberM(new BigDecimal(req.getParameter("mnum")));
    	paperInfo.setNumberTf(new BigDecimal(req.getParameter("ifnum")));
    	paperInfo.setScoreS(new BigDecimal(req.getParameter("sscore")));
    	paperInfo.setScoreM(new BigDecimal(req.getParameter("mscore")));
    	paperInfo.setScoreTf(new BigDecimal(req.getParameter("ifscore")));
        String _name=SecurityUtils.getCurrentUser().getUserId();
    	paperInfo.setModifier(_name.toUpperCase());
        paperInfo.setModifyDate(new Date());
	    HashMap<String, String> _reHashMap=new HashMap<String, String>();
	    if( paperService.UpdatePaper(paperInfo))
	    {	
	    	_reHashMap.put("status", "true");
	        _reHashMap.put("msg", "編輯成功");
	    }
	    else {
	    	_reHashMap.put("status", "false");
	        _reHashMap.put("msg", "編輯失敗");
		}
	    return _reHashMap;
	}	
}
