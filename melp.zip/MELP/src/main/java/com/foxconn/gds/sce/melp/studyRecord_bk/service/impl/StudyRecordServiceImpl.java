package com.foxconn.gds.sce.melp.studyRecord_bk.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.model.StudyRecord;
import com.foxconn.gds.sce.melp.model.Teacher;

import com.foxconn.gds.sce.melp.studyRecord_bk.dao.StudyRecordDao;
import com.foxconn.gds.sce.melp.studyRecord_bk.service.StudyRecordService;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.teacher.dao.TeacherDao;

@Service(value="StudyRecordService")
public class StudyRecordServiceImpl extends CrudServiceImpl<StudyRecord, StudyRecordDao> implements StudyRecordService {
	@Autowired
	public void  setTeacherDao(StudyRecordDao studyRecordDao) {
		this.daoSupport=studyRecordDao;
   }
	
	public DataTableReturn selStudyRecord(DataTable dt,String userid)
	{
		DataTableReturn dtr=new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		params.put(DataTable.SEARCH, dt.getSearch());
		
		for( SortInfo sInfo : dt.getSortInfo() ) {
			System.out.print(params.get("DT_ORDER_COLUMN_SORT"));
			if(params.get("DT_ORDER_COLUMN_SORT")!=null){//modified by lyl 20120827
				params.put(DataTable.ORDER_COLUMN_SORT, 
						params.get("DT_ORDER_COLUMN_SORT")+","+sInfo.getColumnId()+ " " + sInfo.getSortOrder());
			}
			else{
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());		
			}
		}
		
		params.put("CONDITION", userid);
		PaginatedResult<StudyRecord>  records=daoSupport.selStudyRecord(params, skipResults, maxResults);
		dtr.setAaData(records.getResult());
		dtr.setiTotalDisplayRecords(records.getTotalResults());
		dtr.setiTotalRecords(records.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}
	
	
	@SuppressWarnings("unchecked")
	public List<Map> exports(String userid,String searchString) {
		Map paraMap=new HashMap();
		paraMap.put("CONDITION", userid);
		paraMap.put("DT_SEARCH",searchString);
		return daoSupport.exports(paraMap);
	}
	
}
