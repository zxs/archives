package com.foxconn.gds.sce.melp.security.voter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;
/**
 * This class votes if an logged user can access an specified secured object. 
 * It assumes that the configAttributes will have the preffix P_, otherwise this class will abstain
 * @author jperez
 *
 */
/**
 * @author jperez
 *
 */
@Component(value = "rolePermissionVoter")
public class RolePermissionVoter implements AccessDecisionVoter{

	
	private String rolePrefix = "P_";

	public String getRolePrefix() {
		return rolePrefix;
	}

	public void setRolePrefix(String rolePrefix) {
		this.rolePrefix = rolePrefix;
	}

	/**
	 * Support any class
	 * @param aClass any class
	 * @return always <tt>true</tt>
	 */
	public boolean supports(Class aClass) {
		return true;
	}

	
	/**
	 * Checks if support the attribute
	 * @param configAttribute
	 * @return <tt>true</tt> if supported 
	 * @see org.springframework.security.vote.AccessDecisionVoter#supports(org.springframework.security.ConfigAttribute)
	 */
	public boolean supports(ConfigAttribute configAttribute) {
		String attribute = configAttribute.getAttribute();
		return attribute != null && attribute.startsWith(getRolePrefix());
	}

	/**
	 * Votes for the specified secured object
	 * @param authentication 
	 * @param securedObject
	 * @param configAttributeDefinition
	 * @return vote 
	 *
	 */
	@SuppressWarnings("unchecked")
	public int vote(Authentication authentication, Object securedObject,
			Collection<ConfigAttribute> attributes) {
		int result = ACCESS_ABSTAIN;
		
		List<String> userAuthorities = getUserAuthorities(authentication.getAuthorities());
		
		Iterator<ConfigAttribute> configAttributes = attributes.iterator();
		
		while (configAttributes.hasNext()) {
			ConfigAttribute configAttribute = (ConfigAttribute) configAttributes.next();
			
			if (this.supports(configAttribute)){
				String attribute = configAttribute.getAttribute();
				boolean hasAuthority = userAuthorities.contains(attribute);
				result = hasAuthority ? ACCESS_GRANTED : ACCESS_DENIED;
				if (hasAuthority) break;
			}
			
		}
		
		return result;
	}

	private List<String> getUserAuthorities(Collection<GrantedAuthority> authorities) {
		List<String> userAuthorities = new ArrayList<String>(authorities.size());
		for (GrantedAuthority grantedAuthority : authorities) {
			userAuthorities.add(grantedAuthority.getAuthority());
		}
		return userAuthorities;
	}


}

