package com.foxconn.gds.sce.melp.fdownloadpaper.dao;


import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.VO_ExamineesInfo;
import com.foxconn.gds.sce.melp.model.VO_RolePermission;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface DownloadPaperDao  extends GenericDao<ExamRoom, String> {
	
	List<ExamRoom> listByUser(String loginUserEmpNo);
	
	ExamRoom ListByRoomId(String examRoomId);
	
	//管理員列出所有考場信息
	List<ExamRoom> listByAdmin();
	
	//獲取學員信息
	List<Examinees> getExamineedList(String examRoomId);
	
	//獲取可登陸用戶信息
	List<VO_ExamineesInfo> getUserList(String examRoomId);
	//獲取可登陸用戶信息-當前登錄人員及管理員
	List<VO_ExamineesInfo> getCurrentUserAndAdmin(String empNo);
	
	//獲取學員考試信息
	List<ExamInfo> getExamIfoList(String examRoomId);
	
	List<VO_RolePermission> listAllRolePermissions();
	
	//獲取考卷設置信息
	PaperInfo listPaperInfo(String paperId);
	
	//獲取考卷對應題庫試題信息
	List<Question> listQuestions(String paperId);
	
	//獲取考卷試題選項信息
	List<QuestionOptions> listQuestionOptions(String paperId);
	
	//獲取考試結果信息
	List<ExamResults> listExamResults(String examRoomId);
	
}
