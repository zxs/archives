package com.foxconn.gds.sce.melp.model;

import java.util.Date;


public class ClassInfo extends BasicEntity{

	/**
	 * C_CLASS_T
	 * column:ID
	 * 班級id
	 */
	private String classId;
	
	/**
	 * C_CLASS_T
	 * column:CLASS_NO
	 * 班級編號
	 */
	private String classNo;
	
	/**
	 * C_CLASS_T
	 * column:COURSE_ID
	 * 課程id
	 */
	private String courseId;
	
	/**
	 * C_CLASS_T
	 * column:CLASS_NAME
	 * 班級名稱
	 */
	private String className;
	
	/**
	 * C_CLASS_T
	 * column:START_TIME
	 * 學習開始時間
	 */
	private String startTime;
	
	/**
	 * C_CLASS_T
	 * column:END_TIME
	 * 學習結束時間
	 */
	private String endTime;
	
	/**
	 * C_CLASS_T
	 * column:CREATE_DATE
	 * 錄入時間
	 */
	private String createDate;
	
	/**
	 * C_CLASS_T
	 * column:CREATE_USER
	 * 錄入人
	 */
	private String createUser;
	
	/**
	 * C_CLASS_T
	 * column:MODIFY_DATE
	 * 修改時間
	 */
	private String modifyDate;
	
	/**
	 * C_CLASS_T
	 * column:MODIFY_USER
	 * 修改人
	 */
	private String modifyUser;
	
	/**
	 * C_CLASS_T
	 * column:IS_ENABLE
	 * 刪除標記 ：1代表有效，0代表已刪除
	 */
	private String isEnable;
	
	/**
	 * C_COURSE_INFO_T
	 * column:COURSE_NAME
	 * 課程名稱
	 */
	private String courseName;
	
	/**
	 * C_COURSE_INFO_T
	 * column:COURSE_TYPE
	 * 課程類別
	 */
	private String courseType;
	
	/**
	 * C_COURSE_INFO_T
	 * column:COURSE_HOUR
	 * 課程時長
	 */
	private String courseHour;
	
	/**
	 * C_COURSE_INFO_T
	 * column:COURSEWARE_URL
	 * 課件URL
	 */
	private String coursewareUrl;
	
	/**
	 * C_COURSE_INFO_T
	 * column:COURSE_SUMMARY
	 * 課程介紹
	 */
	private String courseSummary;
	
	/**
	 * C_COURSE_INFO_T
	 * column:OWNER
	 * 制作人
	 */
	private String owner;
	
	/**
	 * C_COURSE_INFO_T
	 * column:OWNER_DEPT
	 * 制作單位
	 */
	private String ownerDept;
	
	/**
	 * C_TEACHER_T
	 * column:EMP_NAME
	 * 講師名稱
	 */
	private String teacherName;
	
	/**
	 * 統計記錄數
	 */
	private String myCount;

	/**
	 * 學習時間
	 */
	private String classTime;
	
	/**
	 * 學員人數
	 */
	private int studentCount;
	
	/**
	 * 當前系統日期(數據庫系統日期)
	 */
	private String currentDate;
	/**
	 * add by Hualing Wei
	 * @return
	 */
	public String resultId;
	public String getClassId() {
		return classId;
	}

	public void setClassId(String classId) {
		this.classId = classId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}


	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseType() {
		return courseType;
	}

	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}

	public String getCourseHour() {
		return courseHour;
	}

	public void setCourseHour(String courseHour) {
		this.courseHour = courseHour;
	}

	public String getTeacherName() {
		return teacherName;
	}

	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}

	public String getCoursewareUrl() {
		return coursewareUrl;
	}

	public void setCoursewareUrl(String coursewareUrl) {
		this.coursewareUrl = coursewareUrl;
	}

	public String getCourseSummary() {
		return courseSummary;
	}

	public void setCourseSummary(String courseSummary) {
		this.courseSummary = courseSummary;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerDept() {
		return ownerDept;
	}

	public void setOwnerDept(String ownerDept) {
		this.ownerDept = ownerDept;
	}

	public String getMyCount() {
		return myCount;
	}

	public void setMyCount(String myCount) {
		this.myCount = myCount;
	}

	public String getClassTime() {
		return classTime;
	}

	public void setClassTime(String classTime) {
		this.classTime = classTime;
	}

	public int getStudentCount() {
		return studentCount;
	}

	public void setStudentCount(int studentCount) {
		this.studentCount = studentCount;
	}

	public String getCurrentDate() {
		return currentDate;
	}

	public void setCurrentDate(String currentDate) {
		this.currentDate = currentDate;
	}
	public String getResultId() {
		return resultId;
	}

	public void setResultId(String resultId) {
		this.resultId = resultId;
	}
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	
}
