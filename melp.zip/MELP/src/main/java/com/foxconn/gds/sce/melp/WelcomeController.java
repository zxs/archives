package com.foxconn.gds.sce.melp;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.stereotype.Controller;

import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * @author: andres.vega
 */
@Controller
public class WelcomeController {

    @RequestMapping(method=RequestMethod.GET , value="/index.spr")
    public ModelAndView showIndex(HttpServletRequest request,
                             HttpServletResponse response)
    throws ServletException, IOException {
    	//load here any information needed at index page
    	return new ModelAndView();
    }

    @RequestMapping(method=RequestMethod.GET , value="/welcome.spr")
    public String showWelcome(HttpServletRequest request,
    		HttpServletResponse response) {
    	return 	ClientUtil.returnView(request, "welcome");
    }
    @RequestMapping(method=RequestMethod.POST,value="/getRole.spr")
	@ResponseBody
	public Boolean paperContent(HttpServletRequest request){
	if(SecurityUtils.examineePlayedbyCurrentUser()){
	return true;
	}
	else{
	return false;
	}
	}
}
