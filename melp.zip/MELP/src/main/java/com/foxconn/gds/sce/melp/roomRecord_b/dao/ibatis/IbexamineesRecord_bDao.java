package com.foxconn.gds.sce.melp.roomRecord_b.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.roomRecord_b.dao.examineesRecord_bDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value = "ibexamineesRecord_bDao")
public class IbexamineesRecord_bDao extends GenericDaoIbatisImpl<Examinees, String>
		implements examineesRecord_bDao {

	@Autowired
	public IbexamineesRecord_bDao(SqlMapClient sqlMapClient) {
		super(Examinees.class);
		setSqlMapClient(sqlMapClient);
	}
	
	public String create(Examinees newInstance) {
		// TODO Auto-generated method stub
		return null;
	}

	public Examinees read(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Examinees transientObject) {
		// TODO Auto-generated method stub

	}

	public void delete(Examinees persistentObject) {
		// TODO Auto-generated method stub

	}

	public PaginatedResult<Examinees> listExaminees(Map parameters, int skipResults,
			int maxResults) {
		int page = skipResults / maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<Examinees> prExaminees = new PaginatedResult<Examinees>(
				page, pageSize);
		List<Examinees> result = null;
		if (maxResults < 0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList(
					"listExamniees", parameters);
		} else {
			result = getSqlMapClientTemplate().queryForList(
					"listExamniees", parameters, skipResults, maxResults);
		}
		Integer count = (Integer) getSqlMapClientTemplate().queryForObject(
				"countExamniees", parameters);

		prExaminees.setResult(result);
		prExaminees.setTotalResults(count);

		return prExaminees;
	}

}
