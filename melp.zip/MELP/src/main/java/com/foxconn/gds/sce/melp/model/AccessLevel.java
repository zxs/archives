package com.foxconn.gds.sce.melp.model;

/**
 * Defines the permission access level
 *  
 * @author jperez
 *
 */
public enum AccessLevel {
	
	Access("ACCESS"),
	Full("FULL");
	
	private String code;

	private AccessLevel(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	
	
	
	

}
