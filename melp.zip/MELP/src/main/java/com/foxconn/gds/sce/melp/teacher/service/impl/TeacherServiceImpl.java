package com.foxconn.gds.sce.melp.teacher.service.impl;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.Teacher;
import com.foxconn.gds.sce.melp.questionlib.dao.QuestionlibDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.teacher.dao.TeacherDao;
import com.foxconn.gds.sce.melp.teacher.service.TeacherService;

@Service(value="TeacherService")
public class TeacherServiceImpl extends CrudServiceImpl<Teacher, TeacherDao> implements TeacherService  {

	@Autowired
	public void  setTeacherDao(TeacherDao teacherDao) {
		this.daoSupport=teacherDao;
   }
	
	public DataTableReturn findAllTeacher(DataTable dt,String userid)
	{
		DataTableReturn dtr=new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		params.put(DataTable.SEARCH, dt.getSearch());
		
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		params.put("CONDITION", userid);
		PaginatedResult<Teacher>  questions=daoSupport.selTeacherList(params, skipResults, maxResults);
		dtr.setAaData(questions.getResult());
		dtr.setiTotalDisplayRecords(questions.getTotalResults());
		dtr.setiTotalRecords(questions.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

	
	//新增講師
		public Boolean addTeacher(Teacher p_teacher)
		{
			return daoSupport.addTeacher(p_teacher);
		}
		
		//判斷講師是否存在
		public  boolean isTeacherExist(Teacher p_teacher) 
		{
			return daoSupport.isTeacherExist(p_teacher);
		}
		
		
		public List<BaseCode> selTeacherType()
		{
			return daoSupport.selTeacherType();
		}
		
		public List<BaseCode> selTeacherLevel()
		{
			return daoSupport.selTeacherLevel();
		}
		
		/*根據ID查詢講師信息*/
		public Teacher selTeacherByID(Teacher p_teacher)
		{
			return daoSupport.selTeacherByID(p_teacher);
		}
		
		/*更新講師*/
		public boolean updTeacher(Teacher p_teacher)
		{
			return daoSupport.updTeacher(p_teacher);
		}
		
		/*刪除講師*/
		@Transactional
		public boolean delTeacher(String p_id)
		{
			String _id=p_id.substring(0,p_id.length()-1);
			String[] _array_id=_id.split(",");
			for (String per : _array_id) {
				daoSupport.delTeacher(per.trim());
			}
			return true;
		}
}
