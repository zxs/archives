package com.foxconn.gds.sce.melp.classManager.dao;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ClassInfo;
import com.foxconn.gds.sce.melp.model.ClassMember;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface ClassManagerDao {

	void saveClassInfo(ClassInfo classInfo);

	PaginatedResult<ClassInfo> showAllClassInfoList(Map params,	int skipResults, int maxResults);

	int isClassNoExist(String classNo);

	void updateClassInfo(ClassInfo classInfo);

	void deleteClassInfo(ClassInfo classInfo);

	ClassInfo checkClassInfo(String classId);

	int getStudentCountByClassId(String classId);

	PaginatedResult<ClassMember> getStudentListByClassId(Map params, int skipResults, int maxResults);

	void addPersonToClass(final List<ClassMember> list);

	void delClassMemberFromClass(final List<ClassMember> classMemberList);

	List<ClassMember> getClassMemberListForExp(String classId);

	ClassInfo getCourseInfoById(ClassInfo classInfo);

	int isClassNoExistForUpdate(String classNo, String classId);

	List<ClassInfo> getAutoClassNo();
	
	String getCurrentDate();

}
