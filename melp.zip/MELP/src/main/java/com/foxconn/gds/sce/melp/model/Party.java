package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.ForeignKey;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Party refers to contact information (email addresses, phone numbers and postal addresses)
 * This entity is extended by Organization and Person
 * 
 * User: Anai
 * Date: Feb 16, 2009
 * Time: 1:01:11 PM
 */

@MappedSuperclass
@Inheritance(strategy=InheritanceType.JOINED)
public abstract class Party extends BasicEntity{
    
    @OneToMany( fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id")
//    @ForeignKey(name = "fk_party_email_id")
    @org.hibernate.annotations.IndexColumn(name="list_index")
    protected List<EmailAddress> emailAddresses;

    @OneToMany( fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id")
//    @ForeignKey(name = "fk_party_postaladdress_id")
    @org.hibernate.annotations.IndexColumn(name="list_index")
    protected List<PostalAddress> postalAddresses;


    @OneToMany( fetch = FetchType.LAZY)
    @JoinColumn(name = "party_id")
//    @ForeignKey(name = "fk_party_phonenumber_id")
    @org.hibernate.annotations.IndexColumn(name="list_index")
    protected List<PhoneNumber> phoneNumbers;

    //TODO create an entity to include persons and complete the contacts list
    //TODO create methods to add, remove, verify contacts for a party
    //private List<Person> contacts;

    public List<EmailAddress> getEmailAddresses() {
        return emailAddresses;
    }

    public void setEmailAddresses(List<EmailAddress> emailAddresses) {
        this.emailAddresses = emailAddresses;
    }

    public List<PostalAddress> getPostalAddresses() {
        return postalAddresses;
    }

    public void setPostalAddresses(List<PostalAddress> postalAddresses) {
        this.postalAddresses = postalAddresses;
    }

    public List<PhoneNumber> getPhoneNumbers() {
        return phoneNumbers;
    }

    public void setPhoneNumbers(List<PhoneNumber> phoneNumbers) {
        this.phoneNumbers = phoneNumbers;
    }

    public int onHashCode(){
        return new HashCodeBuilder().toHashCode();

    }

//    public boolean onEquals(Object o) {
//        return false;
//    }

    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    public Object clone(){
        try{
            Party cloneEntity = (Party)super.clone();
            cloneEntity.setEmailAddresses(this.getEmailAddresses());
            cloneEntity.setPhoneNumbers(this.getPhoneNumbers());
            cloneEntity.setPostalAddresses(this.getPostalAddresses());
            return cloneEntity;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }

    /***********************************  EMAIL ADDRESSES ***********************************/


     /**
     * Adds an email address to this party's collection of {@link #getEmailAddresses() email
     * addresses}.
     * If the existing emailAddresses collection is <tt>null</tt>, a new collection will be
     * created and assigned to this party and then the email address will be added.
     * If the specified email address already exists in this party's collection, it will not be
     * added again.
     *
     * @param email the email address to add/associate with this party.
     */
    public void addEmailAddress( EmailAddress email ) {
        List<EmailAddress> emails = this.getEmailAddresses();
        if ( emails == null ) {
            emails = new ArrayList<EmailAddress>();
            setEmailAddresses( emails );
        }
        if ( !emails.contains( email ) ) {
            emails.add( email );
        } else {
            if ( log.isDebugEnabled() ) {
                log.debug( "emailAddresses collection already contains email address [" +
                           email + "].  Ignoring addition." );
            }
        }
    }

    /**
     * Removes the given email from this Party's email collection.
     * @param email the email address to remove.
     * @return true if the email address was removed, false if it wasn't removed.
     */
    public boolean removeEmailAddress( EmailAddress email ) {
        List<EmailAddress> emails = getEmailAddresses();
        if ( emails == null || emails.isEmpty() ) {
            return false;
        } else {
            return emails.remove( email );
        }
    }

    /**
     * Returns whether or not the specified email address has already been associated with this
     * party.
     * @param email the email to check for association
     * @return true if the specified email address has already been added to this party's
     * emailAddresses collection.
     */
    public boolean hasEmailAddress( EmailAddress email ) {
        List<EmailAddress> emails = getEmailAddresses();
        if ( emails != null ) {
            return emails.contains( email );
        } else {
            return false;
        }
    }

    /**
     * Returns an email address that is associated with this label for this party
     * @param label The label associated with this email address (for example,'Home', 'Work', ...)
     * @return the email address related to the specified label
     */
    public EmailAddress getEmailAddress( String label ) {
        List<EmailAddress> emails = getEmailAddresses();
        if ( emails != null ) {
            for( EmailAddress emailAddress : emails ) {
                if ( emailAddress.getText().equals( label ) ) {
                    return emailAddress;
                }
            }
        }
        return null;
    }

    /***********************************  POSTAL ADDRESSES ***********************************/


    /**
     * Adds an email address to this party's collection of {@link #getPostalAddresses() postal
     * addresses}.
     * If the existing postalAddresses collection is <tt>null</tt>, a new collection will be
     * created and assigned to this party and then the postal address will be added.
     * If the specified postal address already exists in this party's collection, it will not be
     * added again.
     *
     * @param postalAddress the postal address to add/associate with this party.
     */
    public void addPostalAddress( PostalAddress postalAddress ) {
        List<PostalAddress> postalAddresses = getPostalAddresses();
        if ( postalAddresses == null ) {
            postalAddresses = new ArrayList<PostalAddress>();
            setPostalAddresses( postalAddresses );
        }
        if ( !postalAddresses.contains( postalAddress ) ) {
            postalAddresses.add( postalAddress );
        } else {
            if ( log.isDebugEnabled() ) {
                log.debug( "postalAddresses collection already contains postal address [" +
                           postalAddress + "].  Ignoring addition." );
            }
        }
    }

    /**
     * Removes the given postal address from this Party's postal addresses collection.
     * @param postalAddress the postal address to remove.
     * @return true if the postal address was removed, false if it wasn't removed.
     */
    public boolean removePostalAddress( PostalAddress postalAddress ) {
        List<PostalAddress> postalAddresses = getPostalAddresses();
        if ( postalAddresses == null || postalAddresses.isEmpty() ) {
            return false;
        } else {
            return postalAddresses.remove( postalAddress );
        }
    }

    /**
     * Returns whether or not the specified postal address has already been associated with this
     * party.
     * @param postalAddress the postal address to check for association
     * @return true if the specified postal address has already been added to this party's
     *         postalAddresses collection.
     */
    public boolean hasPostalAddress( PostalAddress postalAddress ) {
        List<PostalAddress> addresses = getPostalAddresses();
        if ( addresses != null ) {
            return addresses.contains( postalAddress );
        } else {
            return false;
        }
    }


    /***********************************  PHONE NUMBERS ***********************************/


    /**
     * Adds an phone number to this party's collection of {@link #getPhoneNumbers() phone numbers}.
     * If the existing phoneNumbers collection is <tt>null</tt>, a new collection will be created
     * and assigned to this party and then the phone number will be added.
     * If the specified phone number already exists in this party's collection, it will not be
     * added again.
     *
     * @param phoneNumber the phone number to add/associate with this party.
     */
    public void addPhoneNumber( PhoneNumber phoneNumber ) {
        List<PhoneNumber> phoneNumbers = getPhoneNumbers();
        if ( phoneNumbers == null ) {
            phoneNumbers = new ArrayList<PhoneNumber>();
            setPhoneNumbers( phoneNumbers );
        }
        if ( !phoneNumbers.contains( phoneNumber ) ) {
            phoneNumbers.add( phoneNumber );
        } else {
            if ( log.isDebugEnabled() ) {
                log.debug( "phoneNumbers collection already contains phone number [" +
                           phoneNumber + "].  Ignoring addition." );
            }
        }
    }


    /**
     * Removes the given phone number from this Party's phone numbers collection.
     * @param phoneNumber the phone number to remove.
     * @return true if the phone number was removed, false if it wasn't removed.
     */
    public boolean removePhoneNumber( PhoneNumber phoneNumber ) {
        List<PhoneNumber> phoneNumbers = getPhoneNumbers();
        if ( phoneNumbers == null || phoneNumbers.isEmpty() ) {
            return false;
        } else {
            return phoneNumbers.remove( phoneNumber );
        }
    }

    /**
     * Returns whether or not the specified phone number has already been associated with this
     * party.
     * @param pn the phone number to check for association
     * @return true if the specified phone number has already been added to this party's
     *         phoneNumbers collection.
     */
    public boolean hasPhoneNumber( PhoneNumber phoneNumber ) {
        List<PhoneNumber> phoneNumbers = getPhoneNumbers();
        if ( phoneNumbers != null ) {
            return phoneNumbers.contains( phoneNumber );
        } else {
            return false;
        }
    }

    /**
     * Searches a phone number in the PhoneNumber collection using its label as search criteria
     * @param label the label used as search criteria over the PhoneNumber collection
     * @return the first PhoneNumber found in the collection with a matching label, or
     * <tt>null</tt> if there's no matching label in the collection
     */
    public PhoneNumber getPhoneNumber( String label ) {
        List<PhoneNumber> phoneNumbers = getPhoneNumbers();
        if ( (label != null) && (phoneNumbers != null) ) {
            for( PhoneNumber phoneNumber : phoneNumbers ) {
                if ( label.equals( phoneNumber.getLabel() ) ) {
                    return phoneNumber;
                }
            }
        }
        return null;
    }


}
