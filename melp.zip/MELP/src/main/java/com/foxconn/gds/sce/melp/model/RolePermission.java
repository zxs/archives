package com.foxconn.gds.sce.melp.model;

import org.hibernate.annotations.ForeignKey;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "melp_role_permission")
public class RolePermission extends BasicPermission{
	
	
	@ManyToOne
    @ForeignKey(name = "fk_role_permission_id")
	@JoinColumn(name = "role_id", nullable = false)
	private Role role;

	public RolePermission(){
		super();
	}
	
	
	public RolePermission(Role role, PermissionType permissionType, AccessLevel accessLevel) {
		super(permissionType, accessLevel, true);
		this.role = role;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	@Override
	public int onHashCode() {
		int prime = 31;
		int result = super.onHashCode();
		result = prime * result + ((role == null) ? 0 : role.hashCode());
		return result;
	}

	@Override
	public boolean onEquals(Object obj) {
		if (this == obj){
            return true;}
		if (!super.onEquals(obj)){
			return false;}
		if (getClass() != obj.getClass()){
			return false;}
		RolePermission other = (RolePermission) obj;
		if (role == null) {
			if (other.role != null){
				return false;}
		} else {
            if (!role.equals(other.role)){
			    return false;}
        }
        return true;
	}
	//
	// Only for this Project 
	// 
	@Column(name="URL")
	private String url;
	@Column(name="MENU_TYPE")
	private Integer menuType;
	@Column(name="MENU_ORDER")
	private Integer menuOrder;
	
	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public Integer getMenuType() {
		return menuType;
	}


	public void setMenuType(Integer menuType) {
		this.menuType = menuType;
	}


	public Integer getMenuOrder() {
		return menuOrder;
	}


	public void setMenuOrder(Integer menuOrder) {
		this.menuOrder = menuOrder;
	}
	
	
	
	
	

}
