package com.foxconn.gds.sce.melp.questionnaires;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.questionnaires.service.QuestionnairesService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;

@Controller
@RequestMapping(value = "/questionnaires/**")
public class QuestionnairesController {
	public QuestionnairesService questionnairesService; 
	@Autowired
	public void setQuestionnairesService(QuestionnairesService questionnairesService){
		this.questionnairesService = questionnairesService;
	}
	@RequestMapping(method=RequestMethod.GET,value = "showquestionnaires.spr")
	public ModelAndView showquestionnaires(@RequestParam("iframe") String iframe){
		List<Questionnaires> list_P=questionnairesService.showQuestionnaires_P();
		ModelAndView mav=new ModelAndView("questionnaires/questionnairesMain","iframe","true".equals(iframe)?"true":"false");
	     mav.addObject("questionnaires_p",list_P);
		return mav;
		}
	 @RequestMapping( method = RequestMethod.POST, value = "QuestionnairesImport.spr")
	    public ModelAndView QuestionnairesImport(@RequestParam("name") String name, @RequestParam("file") MultipartFile file,HttpServletResponse response) throws Exception{
			Map<String, Object> result = new HashMap<String,Object>();
	    	result.put("status", false);
	    	String userid=SecurityUtils.getCurrentUser().getUserId();
	    	try {
		        if (!file.isEmpty()) {
		        	boolean imported = questionnairesService.importQuestionnaires(file,userid,name);
		        	result.put("status", imported);
		        	result.put("msg", "導入模板成功！");
		        }
	        } catch(Exception ex) {
	        	result.put("status", false);
	        	result.put("msg", "導入異常，請聯繫系統管理員！ EX:"+ex.getMessage());
	        	
	        }
	    	return new ModelAndView("/questionnaires/import-result","result", result);
	    }
}
