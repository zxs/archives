package com.foxconn.gds.sce.melp.model;

public class VO_ExamineesInfo extends Examinees {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public int getExamTimes() {
		return examTimes;
	}
	public void setExamTimes(int examTimes) {
		this.examTimes = examTimes;
	}
	public int getAddTimes() {
		return addTimes;
	}
	public void setAddTimes(int addTimes) {
		this.addTimes = addTimes;
	}
	private String password;
	private String roleId;
	private String roleName;
	private int examTimes;
	private int addTimes;

}
