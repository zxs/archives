package com.foxconn.gds.sce.melp.makeup.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.makeup.dao.MakeupDao;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository("ibMakeupDao")
public class IbMakeupDao extends GenericDaoIbatisImpl<ExamInfo, String> implements MakeupDao  {
	
	@Autowired
	public IbMakeupDao(SqlMapClient sqlMapClient) {
		super(ExamInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	@SuppressWarnings("unchecked")
	public PaginatedResult<HashMap<String, String>> getListForDataTable(
			Map<String, String> parameterMap, int skipResults, int maxResults) {
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<HashMap<String, String>> prExamInfo = new PaginatedResult<HashMap<String, String>>(page, pageSize);
		List<HashMap<String, String>> examInfoList = null;
		if(maxResults<0) { // Query All Records
			examInfoList = getSqlMapClientTemplate().queryForList("makeupInfo.getListWithRole", parameterMap);			
		} else {
			examInfoList = getSqlMapClientTemplate().queryForList("makeupInfo.getListWithRole", parameterMap, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("makeupInfo.getListWithRoleCount", parameterMap);
		
		prExamInfo.setResult(examInfoList);
		prExamInfo.setTotalResults(count);
		return prExamInfo;
	}

	public PaginatedResult<HashMap<String, String>> getMakeupInfoForDataTable(
			Map<String, String> parameterMap, int skipResults, int maxResults) {
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<HashMap<String, String>> prMakeupInfo = new PaginatedResult<HashMap<String, String>>(page, pageSize);
		List<HashMap<String, String>> makeupInfoList = null;
		if(maxResults<0) { // Query All Records
			makeupInfoList = getSqlMapClientTemplate().queryForList("makeupInfo.getMakeupInfoForDataTable", parameterMap);			
		} else {
			makeupInfoList = getSqlMapClientTemplate().queryForList("makeupInfo.getMakeupInfoForDataTable", parameterMap, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("makeupInfo.getMakeupInfoForDataTableCount", parameterMap);
		
		prMakeupInfo.setResult(makeupInfoList);
		prMakeupInfo.setTotalResults(count);
		return prMakeupInfo;
	}

	public void addMakeupTimes(String id) {
			this.getSqlMapClientTemplate().update("makeupInfo.addMakeupTimes", id);
	}

	public void reduceMakeupTimes(String id) {
		this.getSqlMapClientTemplate().update("makeupInfo.reduceMakeupTimes", id);
		
	}

}
