package com.foxconn.gds.sce.melp.evaluateCourse.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface EvaluateCourseService extends CrudService<Questionnaires>{
	List<Questionnaires> showQuestionnaires_P(String courseID,String courseCreator);
	Boolean updateEvRecord(String questionId,String option,String classID,String courseID,String empNo);
	int getEvType(String courseID);
	String getCourseCreator(String courseID);
	Boolean insertEvRecord(String classID, String courseID, String empNo);
}
