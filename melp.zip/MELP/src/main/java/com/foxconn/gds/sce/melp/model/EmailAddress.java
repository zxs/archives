package com.foxconn.gds.sce.melp.model;

import java.util.regex.Pattern;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang.builder.HashCodeBuilder;

import com.foxconn.gds.sce.melp.support.ValidationUtils;

/**
 * An email address represents the textual string of an
 * <a href="http://www.ietf.org/rfc/rfc2822.txt">RFC 2822</a> email address and other corresponding
 * information of interest.
 *
 * User: Anai
 * Date: Feb 16, 2009
 * Time: 8:21:34 AM
 */

@Entity
@Table(name = "melp_email_address")
public class EmailAddress extends BasicEntity{

    //RFC 2822 token definitions for valid email - only used together to form a java Pattern object:
    private static final String sp = "!#$%&'*+-/=?^_`{|}~";
    private static final String atext = "[a-zA-Z0-9" + sp + "]";
    private static final String atom = atext + "+"; //one or more atext chars
    private static final String dotAtom = "\\." + atom;
    private static final String localPart = atom + "(" + dotAtom + ")*"; //one atom followed by 0 or more dotAtoms.
    //RFC 1035 tokens for domain names:
    private static final String letter = "[a-zA-Z]";
    private static final String letDig = "[a-zA-Z0-9]";
    private static final String letDigHyp = "[a-zA-Z0-9-]";
    public static final String rfcLabel = letDig + letDigHyp + "{0,61}" + letDig;
    private static final String domain = rfcLabel + "(\\." + rfcLabel + ")*\\." + letter + "{2,6}";
    //Combined together, these form the allowed email regexp allowed by RFC 2822:
    private static final String addrSpec = "^" + localPart + "@" + domain + "$";
    //now compile it:
    public static final Pattern VALID_PATTERN = Pattern.compile( addrSpec );

    @Column(name="text")
    private String text;

    @Column(name="bouncing", nullable = false)    
    private boolean bouncing = true;

    @Column(name="verified", nullable = false)
    private boolean verified;
    
    @Column(name="label")
    private String label;

    public EmailAddress() {
        super();
    }

    public EmailAddress( String text ) {
        super();
        setText( text );
    }

    /**
     * Returns the actual email address string, e.g. <tt>someone@somewhere.com</tt>
     * @return the actual email address string.
     */
    public String getText() {
        return text;
    }

    public void setText( String text ) {
        this.text = text;
    }

    /**
     * Returns whether or not any emails sent to this email address come back as bounced
     * (undeliverable).
     *
     * <p>Default is <tt>true</tt> until verification can be made.
     *
     * @return whether or not any emails sent to this email address come back as bounced
     * (undeliverable).
     */
    public boolean isBouncing() {
        return bouncing;
    }

    public void setBouncing( boolean bouncing ) {
        this.bouncing = bouncing;
    }

    /**
     * Returns whether or not the party associated with this email has verified that it is
     * their email address.
     *
     * <p>Verification is usually done by sending an email to this
     * address and waiting for the party to respond or click a specific link in the email.
     *
     * <p>Default is <tt>false</tt>.
     *
     * @return whether or not the party associated with this email has verified that it is
     * their email address.
     */
    public boolean isVerified() {
        return verified;
    }

    public void setVerified( boolean verified ) {
        this.verified = verified;
    }

    /**
     * Party label associated with this address, for example, 'Home', 'Work', etc.
     * @return a label associated with this address, for example 'Home', 'Work', etc.
     */
    public String getLabel() {
        return label;
    }

    public void setLabel( String label ) {
        this.label = label;
    }

    public static boolean isValidText( String email ) {
        return !ValidationUtils.isEmpty( email ) && VALID_PATTERN.matcher( email ).matches();
    }

    public boolean onEquals( Object obj ) {
        if ( obj instanceof EmailAddress ) {
            EmailAddress email = (EmailAddress)obj;
            return getText().equals( email.getText() );
        }

        return false;
    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getText())
                .append(getLabel()).toHashCode();

    }

    
    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    public Object clone() {
        try {
            EmailAddress cloneEntity = (EmailAddress) super.clone();
            cloneEntity.setLabel(this.getLabel());
            cloneEntity.setBouncing(this.isBouncing());
            cloneEntity.setVerified(this.isVerified());
            cloneEntity.setText(this.getText());
            return cloneEntity;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }

    public StringBuffer toStringBuffer() {
        return new StringBuffer(getText());
    }

}
