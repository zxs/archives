package com.foxconn.gds.sce.melp.model;

/**
 * 評價項目
 * @author F3226075
 *
 */
public class EvaluationItems extends BasicEntity{

	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
	/**
	 * Column: ID
	 * 主鍵
	 */
	public String id;
	/**
	 * Column:PART_NAME
	 * 評估部分
	 */
	public String partName;
	/**
	 * Column: CONTENT
	 * 評估項目內容
	 */
	public String content;
	/**
	 * Column: COURSE_ID
	 * 課程ID
	 */
	public String courseId;
	/**
	 * Column: CREATE_DATE
	 * 創建時間
	 */
	public String createDate;
	/**
	 * Column: CREATE_USER
	 * 創建人
	 */
	public String createUser;
	/**
	 * Column: MODIFY_DATE
	 * 修改時間
	 */
	public String modifyDate;
	/**
	 * Column: MODIFY_USER
	 * 修改人
	 */
	public String modifyUser;
	/**
	 * Column: IS_ENABLE
	 * 是否有效
	 */
	public String isEnable;
	/**
	 * Column: ITEM_ORDER
	 * 評估項順序
	 */
	public String itemOrder;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCourseId() {
		return courseId;
	}

	public void setCourseId(String courseId) {
		this.courseId = courseId;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public String getItemOrder() {
		return itemOrder;
	}

	public void setItemOrder(String itemOrder) {
		this.itemOrder = itemOrder;
	}
	
}
