package com.foxconn.gds.sce.melp.security.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.DataAccessException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.sample.dao.SampleDao;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.security.UserSessionDetails;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.user.dao.UserDao;

/**
 * @author: andres.vega
 */
@Service(value = "userDetailsService")
public class UserDetailsServiceImpl extends CrudServiceImpl <User, UserDao> implements UserDetailsService {

    @Autowired
    @Qualifier("hi")
    public void setUserDao(UserDao userDao) {
        this.daoSupport = userDao;
    }

    @Transactional(readOnly=true)
    public UserDetails loadUserByUsername(String username)
            throws UsernameNotFoundException, DataAccessException {
        //User user = daoSupport.getUserByUsername(username);
        User user = daoSupport.getUserByUserId(username);

        if(user==null){
            throw new UsernameNotFoundException(
                    "No user with username '" + username + "' was found in the system");
        }
        
        user.setUserId( user.getUserId().toUpperCase() );
        UserDetails userDetails = new UserSessionDetails(user);
        return userDetails;

    }
    
}
