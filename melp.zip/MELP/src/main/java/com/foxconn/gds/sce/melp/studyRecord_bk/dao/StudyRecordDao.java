package com.foxconn.gds.sce.melp.studyRecord_bk.dao;

import java.awt.List;
import java.util.HashMap;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.StudyRecord;

import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface StudyRecordDao extends GenericDao<StudyRecord, String> {

	public PaginatedResult<StudyRecord> selStudyRecord(Map parameters,int skipResults, int maxResults) ;
	
	public java.util.List<Map> exports(Map paraMap);
	
	
}
