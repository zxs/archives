package com.foxconn.gds.sce.melp.password;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.password.service.PasswordService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.user.service.UserService;

/*
 *  @Service用于标注业务层组件 
 *  @Repository用于标注数据访问组件，即DAO组件 
 *  @Controller用于标注控制层组件，如Struts中的Action 
 *  @Component泛指组件，当组件不要好归类时，可以使用这个注解进行标注
 *  @RequestMapping  映射
 * 
 */

@Controller
@RequestMapping(value = "/password/**")
// 映射路径
public class PasswordController {

	UserService user_src;
	PasswordService pwd_Srv;

	@Autowired
	public void getPasswordService(PasswordService passwordService) {
		pwd_Srv = passwordService;
	}

	@Autowired
	public void getUserService(UserService userService) {
		user_src = userService;
	}

	@RequestMapping(method = RequestMethod.GET, value = "passwordupdatepage.spr")
	// 映射路径
	public ModelAndView updatePasswordPage(@RequestParam("iframe") String iframe) {
		return new ModelAndView("password/uppassword", "iframe",
				"true".equals(iframe) ? "true" : "false");
		// return "password/uppassword";//指向文件
	}
	
	//added by Cube @120915
	@RequestMapping(method = RequestMethod.GET, value = "mdfInitPwdAdmin.spr")
	public ModelAndView mdfInitPwdAdmin() {
		return new ModelAndView();
	}

	@RequestMapping(method = RequestMethod.POST, value = "passwordupdateproc.spr")
	@ResponseBody
	public Map PasswordUpdate(HttpServletRequest request,
			HttpServletResponse response) {
		String msg = "";
		String success = "";
		String pad_old = request.getParameter("password_old"); // 获取旧密码
		String pad_new = request.getParameter("password_new"); // 获取新密码
		pad_old = SecurityUtils.EncryptMD5(pad_old);
		pad_new = SecurityUtils.EncryptMD5(pad_new);
		User user = ClientUtil.getCurrentUser();
		// String pad_username="root";
		String pad_username = user.getUserId(); // 获取UserID
		// 根据账号查密码-->验证旧密码
		// 更新密码

		// boolean flag = pwd_Srv.updatePassword(pad_username, pad_old,
		// pad_new);
		System.out.println(pad_username + "-" + pad_old + "-" + pad_new);
		Map result=pwd_Srv.updatePassword(pad_username, pad_old, pad_new);
		return	result;
	}
}
