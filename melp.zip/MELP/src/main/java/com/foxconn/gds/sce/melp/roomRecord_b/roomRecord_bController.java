package com.foxconn.gds.sce.melp.roomRecord_b;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.roomRecord_b.service.examineesRecord_bService;
import com.foxconn.gds.sce.melp.roomRecord_b.service.roomRecord_bService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;

@Controller
@RequestMapping(value = "/roomRecord_b/**")
public class roomRecord_bController {

	private roomRecord_bService service;

	@Autowired
	public void setRoomRecord_bService(roomRecord_bService roomRecordService) {
		this.service = roomRecordService;
	}

	@RequestMapping(method = RequestMethod.GET, value = "roomRecord_b.spr")
	public ModelAndView roomRecord_b(@RequestParam("iframe") String iframe) {
		return new ModelAndView("/roomRecord/roomRecord_b", "iframe", "true".equals(iframe)?"true":"false");		
	}

	@RequestMapping(method = { RequestMethod.POST }, value = "list.spr")
	public @ResponseBody
	Object list(@RequestParam("_dt_json") String dtjson) {
		DataTable dataTable = JackJson
				.fromJsonToObject(dtjson, DataTable.class);
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		DataTableReturn tableReturn = this.service.listForDT(dataTable,userType);
		return tableReturn;
	}

	private examineesRecord_bService examineesService;

	@Autowired
	public void setExamineesRecord_bService(examineesRecord_bService srv) {
		this.examineesService = srv;
	}

	@RequestMapping(method = { RequestMethod.POST }, value = "listExaminess.spr")
	public @ResponseBody
	Object listExaminess(@RequestParam("_dt_json") String dtjson,
			@RequestParam("roomID") String roomID) {
		DataTable dataTable = JackJson
				.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn = this.examineesService.listForDT(
				dataTable, roomID);
		return tableReturn;
	}
}
