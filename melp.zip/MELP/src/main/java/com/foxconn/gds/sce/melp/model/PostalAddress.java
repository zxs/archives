package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.*;
import java.util.regex.Pattern;

/**
 *
 * User: Anai
 * Date: Feb 16, 2009
 * Time: 9:02:25 AM
 */

@Entity
@Table(name = "melp_postal_address")
public class PostalAddress extends BasicEntity{
        /** Valid regexp pattern for United States zip codes. */
    public static final Pattern US_VALID_ZIP_PATTERN = Pattern.compile("(\\d{5})(\\-\\d{4})?");

    @Column(name="line1")
    private String line1;

    @Column(name="line2")
    private String line2;

    @Column(name="line3")
    private String line3;

    @Column(name="city")
    private String city;

    @Column(name="county")
    private String county;

    @Column(name="state")
    private String state;

    @Column(name="zip")
    private String zip;

    @Column(name="zip_extension")
    private String zipExtension;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Country country;

    @Column(name="label")
    private String label;

    public String getLine1() {
        return line1;
    }

    public void setLine1( String line1 ) {
        this.line1 = line1;
    }

    public String getLine2() {
        return line2;
    }

    public void setLine2( String line2 ) {
        this.line2 = line2;
    }

    public String getLine3() {
        return line3;
    }

    public void setLine3( String line3 ) {
        this.line3 = line3;
    }

    public String getCity() {
        return city;
    }

    public void setCity( String city ) {
        this.city = city;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty( String county ) {
        this.county = county;
    }

    public String getState() {
        return state;
    }

    public void setState( String state ) {
        this.state = state;
    }

    public String getZip() {
        return zip;
    }

    public void setZip( String zip ) {
        this.zip = zip;
    }

    public String getZipExtension() {
        return zipExtension;
    }

    public void setZipExtension( String zipExtension ) {
        this.zipExtension = zipExtension;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry( Country country ) {
        this.country = country;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel( String label ) {
        this.label = label;
    }

    public StringBuffer toStringBuffer() {

        StringBuffer stringBuffer = new StringBuffer();

        stringBuffer.append(",line1=").append(getLine1());
        if ( getLine2() != null ) { stringBuffer.append( ",line2=" ).append( getLine2() ); }
        if ( getLine3() != null ) { stringBuffer.append( ",line3=" ).append( getLine3() ); }
        stringBuffer.append(",city=").append( getCity() );
        if ( getCounty() != null ) { stringBuffer.append(",county=").append( getCounty() ); }
        stringBuffer.append(",state=").append( getState() );
        stringBuffer.append(",zip=").append( getZip() );
        if ( getZipExtension() != null ) { stringBuffer.append(",zipExt=").append( getZipExtension() ); }
        stringBuffer.append(",country=").append( getCountry() );
        if ( getLabel() != null ) { stringBuffer.append(",label=").append( getLabel() ); }

        return stringBuffer;
    }

    public boolean onEquals( Object obj ) {
        if ( obj instanceof PostalAddress ) {

            PostalAddress postalAddress = (PostalAddress)obj;

            return
                (line1.equals( postalAddress.getLine1() ) ) &&
                (line2 == null ? postalAddress.getLine2() == null : line2.equals( postalAddress.getLine2() ) ) &&
                (line3 == null ? postalAddress.getLine3() == null : line3.equals( postalAddress.getLine3() ) ) &&
                (city.equals( postalAddress.getCity() ) ) &&
                (county == null ? postalAddress.getCounty() == null : county.equals( postalAddress.getCounty() ) ) &&
                (state.equals( postalAddress.getState() ) ) &&
                (zip.equals( postalAddress.getZip() ) ) &&
                (zipExtension == null ? postalAddress.getZipExtension() == null : zipExtension.equals( postalAddress.getZipExtension() ) ) &&
                (country.equals( postalAddress.getCountry() ) ) &&
                (label == null ? postalAddress.getLabel() == null : label.equals( postalAddress.getLabel() ) );
        }

        return false;
    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getCity())
                .append(getCounty())
                .append(getLine1())
                .append(getState())
                .append(getZip())
                .append(getLine2())
                .append(getLine3())
                .append(getLabel()).toHashCode();
    }

    @Override
    @SuppressWarnings( { "CloneDoesntDeclareCloneNotSupportedException" } )
    public Object clone() {
        try{
            PostalAddress clone = (PostalAddress)super.clone();
            clone.setLine1( getLine1() );
            clone.setLine2( getLine2() );
            clone.setLine3( getLine3() );
            clone.setCity( getCity() );
            clone.setCounty( getCounty() );
            clone.setState( getState() );
            clone.setZip( getZip() );
            clone.setZipExtension( getZipExtension() );
            clone.setCountry( getCountry() );
            clone.setLabel( getLabel() );
            return clone;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }
}
