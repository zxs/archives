package com.foxconn.gds.sce.melp.password.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.paperInfo.dao.PaperInfoDao;
import com.foxconn.gds.sce.melp.paperInfo.service.PaperInfoService;
import com.foxconn.gds.sce.melp.password.dao.PasswordDao;
import com.foxconn.gds.sce.melp.password.service.PasswordService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.user.service.impl.UserServiceImpl;

//public class ImplPasswordService {
@Service(value = "passwordService")
@Transactional
public class ImplPasswordService extends
	CrudServiceImpl<User, PasswordDao> implements PasswordService {

	private final static Logger logger = LoggerFactory
			.getLogger(UserServiceImpl.class);

	 /**
     * * Returns true if the user is deleted
     *
     * @param userId id from the user
     * @param old Password from the user
     * @param new Password from the user
     * @return change status
     */
    //boolean updatePassword(String userId,String oldPassword,String newPassword);
	

	// 注入password
	private PasswordDao _passwordDao;

	@Autowired
	public void setPasswordDao(PasswordDao passwordDao) {
		this._passwordDao = passwordDao;
	}

	
	// River 20111213 update password
	/**
	 * This is to change the user password to true or false.
	 */
	public Map updatePassword(String userName, String oldPassword,
			String newPassword) {
		Map resultMap=new HashMap();
		String messageString="密碼修改成功";
		System.out.println(userName + "-" + oldPassword + "-" + newPassword);
		String flag = "false";
		if (validatePassword(userName, oldPassword)) {
			User user = new User();
			//user = this.getUser(userName);
			user.setUsername(userName);
			user.setPassword(newPassword);
			
			String Id = this._passwordDao.getUserIdByUserName(userName);
			user.setId(Id);

			// System.out.println("id:"+user.getId());
			// System.out.println("new Password"+user.getPassword());
			// daoSupport.update(user);//更新密碼
			
			if (this._passwordDao.getUpdatePassword(Id, newPassword)) {

				logger.debug("Update Flag Changed. Id: {}, Username: {}",
						user.getId(), user.getUsername());
				// logger.debug 更新密碼日誌				
				flag = "true";
			}else{
				flag = "false";
				messageString="密碼修改失敗！";
			}

		} else {		
			flag = "false";
			messageString="舊密碼錯誤！";
		}
		resultMap.put("success", flag);
		resultMap.put("msg", messageString);
		return resultMap;
	}

	// River 20111214 判斷輸入密碼是否正確
	public boolean validatePassword(String username, String oldPassword) {
		String userPsd = this._passwordDao.getUserPasswordByUserName(username);

		// 判斷輸入密碼是否正確
		if (userPsd.equalsIgnoreCase(oldPassword)) {
			return true;
		} else {
			return false;
		}
	}	
}
