package com.foxconn.gds.sce.melp.QuestionnaireStatistics;

import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.QuestionnaireStatistics.service.QuestionnaireStatisticsService;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.QuestionnaireStatistics;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.questionlib.service.QuestionlibService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.user.UserController;

@Controller
@RequestMapping("/QuestionnaireStatistics/**")
public class QuestionnaireStatisticsController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
	private QuestionnaireStatisticsService QuestionnaireStatisticsSrv;
	
	@Autowired
	public void setQuestionnaireStatisticsSrv(QuestionnaireStatisticsService QuestionnaireStatisticsSrv) {
		this.QuestionnaireStatisticsSrv = QuestionnaireStatisticsSrv;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="showStatisticsList.spr")
	public ModelAndView showStatisticsList(@RequestParam("iframe") String iframe) {
		
		return new ModelAndView("/QuestionnaireStatistics/StatisticsList", "iframe", "true".equals(iframe)?"true":"false");
	}
	
	@RequestMapping(method=RequestMethod.GET,value="showResult.spr")
	public ModelAndView showResult(HttpServletRequest request,HttpServletResponse httpServletResponse){
	String ID=request.getParameter("ID");
	String classID=request.getParameter("classID");
	  HashMap hashMap=new HashMap();
		hashMap.put("ID",ID);
		hashMap.put("classID", classID);
		List<QuestionnaireStatistics> list_C=QuestionnaireStatisticsSrv.showQuestionnaireStatistics_S(hashMap);
		List<QuestionnaireStatistics> list_P=QuestionnaireStatisticsSrv.showQuestionnaireStatistics_P(hashMap);
		
		ModelAndView mav=new ModelAndView("/QuestionnaireStatistics/Statisticsdetail");
		mav.addObject("statisticscontent_S",list_C);
		mav.addObject("statisticscontent_P",list_P);
		
		return mav;
	}
	
	
}
