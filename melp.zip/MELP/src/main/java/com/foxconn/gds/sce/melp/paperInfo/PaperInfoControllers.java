package com.foxconn.gds.sce.melp.paperInfo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.foxconn.gds.sce.melp.paperInfo.service.PaperInfoService;
import com.foxconn.gds.sce.melp.paperInfo.service.impl.PaperInfoServiceImpl;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.user.service.UserService;
import com.foxconn.gds.sce.melp.user.service.impl.UserServiceImpl;

@Service(value = "paperSrv")
@Transactional
public class PaperInfoControllers {

	private final static Logger logger = LoggerFactory
			.getLogger(PaperInfoServiceImpl.class);
	private PaperInfoService paperSrv;
	
	@Autowired
	public void setUserService(PaperInfoService paperSrv) {
		this.paperSrv = paperSrv;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="main.spr")
	public  String userMain() {
		return "/user/main";
	}
	
	@RequestMapping(method=RequestMethod.POST, value="list.spr")
	public @ResponseBody Object list(@RequestParam("_dt_json") String dtjson) {
		logger.info("String dtjson=" + dtjson);

		//可套用，返回
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);

//		DataTableReturn tableReturn = this.paperSrv.queryPaperInfo(dataTable);

		return null;
	}	
}
