package com.foxconn.gds.sce.melp.examresults.service;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface ExamResultsService extends CrudService<ExamResults>{
	 
	public List<ExamResults> listExamResults(ExamResults examResult);
	public Paper showPaperTitle(HashMap hashMap);
	public List<Paper> showPaperContent_S(HashMap hashMap);
	public List<Paper> showPaperContent_M(HashMap hashMap);
	public List<Paper> showPaperContent_TF(HashMap hashMap);
	
	public DataTableReturn listExamResults4DT(DataTable dataTable);
	
}
