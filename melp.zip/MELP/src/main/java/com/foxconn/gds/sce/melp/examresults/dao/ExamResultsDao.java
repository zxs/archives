package com.foxconn.gds.sce.melp.examresults.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface ExamResultsDao extends GenericDao<ExamResults, String>{
	
	public List<ExamResults> listExamResults(ExamResults examResult);
	public Paper showPaperTitle(HashMap hashMap);
	public List<Paper> showPaperContent_S(HashMap hashMap);
	public List<Paper> showPaperContent_M(HashMap hashMap);
	public List<Paper> showPaperContent_TF(HashMap hashMap);
	
	public PaginatedResult<ExamResults> listExamResults(Map params,
			int skipResults, int maxResults);
	
		
}
