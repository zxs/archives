package com.foxconn.gds.sce.melp.role.dao.hibernate;

import java.io.Serializable;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.support.DataAccessUtils;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.role.dao.RoleDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;

/**
 * @author: ronvargas
 * Date: Feb 11, 2009
 */
@Repository(value = "roleDao")
public class HibernateRoleDao extends GenericDaoHibernateImpl<Role, String> implements RoleDao {

	@Autowired
    public HibernateRoleDao(SessionFactory sessionFactory) {
		super(Role.class);
		setSessionFactory(sessionFactory);
	}

    /**
     * Retrieves a role by role id
     *
     * @see com.foxconn.gds.sce.melp.role.dao.RoleDao#getRole(String roleId)
     * @see com.foxconn.gds.sce.melp.model.Role
     */
    public Role getRole(final String roleId) {
    
        List<Role> roleList = (List<Role>) getHibernateTemplate().find("from Role r where r.id = ?", roleId);
        return DataAccessUtils.uniqueResult(roleList);
    }

    /**
     * Retrieves a Role list identified by the specified name (many roles can have the same name across organizations)
     *
     * @param roleName role name
     * @return A role list
     */
    @SuppressWarnings(value = "unchecked")
    public List<Role> getRolesByName(final String roleName) {
        String query = "from Role r where r.name = ?";
        return getHibernateTemplate().find(query, roleName);
    }

    /**
     * get Roles associated to this Organization object
     *
     * @param organization Organization
     * @return A role list
     */
    public List<Role> getRolesByOrganization(final Organization organization) {
        return getRolesByOrganizationId(organization.getId());
    }

    /**
     * get Roles associated to this Organization id
     *
     * @param organizationId Organization id
     * @return A role list
     */
    @SuppressWarnings(value = "unchecked")
    public List<Role> getRolesByOrganizationId(final String organizationId) {
        String query = "from Role r where r.organization.id = ?";
        return getHibernateTemplate().find(query, organizationId);
    }

    /**
     * get Roles associated to this Organization name
     *
     * @param organizationName Organization name
     * @return A role list
     */
    @SuppressWarnings(value = "unchecked")
    public List<Role> getRolesByOrganizationName(final String organizationName) {
        String query = "from Role r where r.organization.name = ?";
        return getHibernateTemplate().find(query, organizationName);
    }

}
