package com.foxconn.gds.sce.melp.examresults.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.examresults.dao.ExamResultsDao;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value = "ibExamResultsDao")
public class IbExamResultsDao extends GenericDaoIbatisImpl<ExamResults, String>
		implements ExamResultsDao {
	@Autowired
	public IbExamResultsDao(SqlMapClient sqlMapClient) {
		super(ExamResults.class);
		setSqlMapClient(sqlMapClient);
	}

	

	public List<ExamResults> listExamResults(ExamResults examResult) {
		return (List<ExamResults>) getSqlMapClientTemplate().queryForList(
				"selectByCondition", examResult);
	}

	public Paper showPaperTitle(HashMap hashMap) {
		return (Paper) getSqlMapClientTemplate().queryForObject(
				"showPaperTitle", hashMap);
	}

	public List<Paper> showPaperContent_S(HashMap hashMap) {
		return (List<Paper>) getSqlMapClientTemplate().queryForList(
				"showPaperContent_S",hashMap);
	}

	public List<Paper> showPaperContent_M(HashMap hashMap) {
		return (List<Paper>) getSqlMapClientTemplate().queryForList(
				"showPaperContent_M",hashMap);
	}

	public List<Paper> showPaperContent_TF(HashMap hashMap) {
		return (List<Paper>) getSqlMapClientTemplate().queryForList(
				"showPaperContent_TF",hashMap);
	}

	public PaginatedResult<ExamResults> listExamResults(Map params,
			int skipResults, int maxResults) {
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<ExamResults> prExams = new PaginatedResult<ExamResults>(page, pageSize);
		List<ExamResults> result = null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("ExamResults.listWithUser", params);			
		} else {
			result = getSqlMapClientTemplate().queryForList("ExamResults.listWithUser", params, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("ExamResults.listWithUser_count", params);
		
		prExams.setResult(result);
		prExams.setTotalResults(count);
		
		return prExams;
	}

}
