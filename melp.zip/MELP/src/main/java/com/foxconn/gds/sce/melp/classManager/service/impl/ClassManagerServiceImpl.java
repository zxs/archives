package com.foxconn.gds.sce.melp.classManager.service.impl;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.classManager.dao.ClassManagerDao;
import com.foxconn.gds.sce.melp.classManager.service.ClassManagerService;
import com.foxconn.gds.sce.melp.model.ClassInfo;
import com.foxconn.gds.sce.melp.model.ClassMember;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;

/**
 * 班級管理
 * Service層實現類
 * @author F3228777
 *
 */
@Service("classManagerServiceImpl")
public class ClassManagerServiceImpl implements ClassManagerService{

	@Autowired
	@Resource(name = "classManagerDao")
	private ClassManagerDao classManagerDao;
	
	/**
	 * 新增班級信息
	 */
	@Override
	public void saveClassInfo(ClassInfo classInfo) {
		classManagerDao.saveClassInfo(classInfo);
		
	}

	/**
	 * 顯示班級信息列表
	 */
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly = true)
	public DataTableReturn showAllClassInfoList(DataTable dateTable, int userType) {
		DataTableReturn dtr = new DataTableReturn();
    	int skipResults = dateTable.getDisplayStart();
		int maxResults = dateTable.getDisplayLength();
		@SuppressWarnings("rawtypes")
		Map params = new HashMap();
		String username = SecurityUtils.getCurrentUser().getUserId();
		if(userType!=0)
		    params.put("DT_USER", username.toUpperCase());	
		else
			params.put("DT_USER", "");
		params.put(DataTable.SEARCH, dateTable.getSearch());
		for( SortInfo sInfo : dateTable.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
    	PaginatedResult<ClassInfo> classList= classManagerDao.showAllClassInfoList(params, skipResults, maxResults);
    	
    	List<ClassInfo> classInfoList = classList.getResult();
    	for(ClassInfo classInfo:classInfoList){
    		classInfo.setClassTime(classInfo.getStartTime().substring(0, 10)+"~"+classInfo.getEndTime().substring(0,10));
    		classInfo.setStudentCount(classManagerDao.getStudentCountByClassId(classInfo.getClassId()));
    	}
    	classList.setResult(classInfoList);
    	dtr.setAaData(classList.getResult());
		dtr.setiTotalDisplayRecords(classList.getTotalResults());
		dtr.setiTotalRecords(classList.getTotalResults());
		dtr.setsEcho(dateTable.getEcho());
		return dtr;
	}

	/**
	 * 判斷班級編號是否已經存在
	 */
	@Override
	@Transactional(readOnly = true)
	public boolean isClassNoExist(String classNo) {
		boolean isExist = false;
			int count = 0;
			count = classManagerDao.isClassNoExist(classNo);
			if(count == 0){
				isExist = true;
			}else{
				isExist = false;
			}
		return isExist;
	}
	
	/**
	 * 判斷修改之后的班級編號是否已經存在,用于修改班級信息
	 */
	@Override
	@Transactional(readOnly = true)
	public boolean isClassNoExistForUpdate(String classNo,String classId) {
		boolean isExist = false;
			int count = 0;
			count = classManagerDao.isClassNoExistForUpdate(classNo,classId);
			if(count == 0){
				isExist = true;
			}else{
				isExist = false;
			}
		return isExist;
	}

	/**
	 * 修改班級信息
	 */
	@Override
	public void updateClassInfo(ClassInfo classInfo) {
		classManagerDao.updateClassInfo(classInfo);
		
	}

	/**
	 * 刪除班級信息
	 */
	@Override
	public void deleteClassInfo(ClassInfo classInfo) {
		String ids[] = classInfo.getClassId().split(",");
		for(int i = 0;i < ids.length; i++){
			classInfo.setClassId(ids[i]);
			classManagerDao.deleteClassInfo(classInfo);
		}
	}

	/**
	 * 查看班級信息
	 * 可用于點擊“預覽”按鈕，查看班級信息，也可用于點擊“修改”按鈕，顯示班級信息以進行修改操作
	 */
	@Override
	public ClassInfo checkClassInfo(String classId) {
		ClassInfo classInfo = classManagerDao.checkClassInfo(classId);
		String start = classInfo.getStartTime().substring(0,10);
		classInfo.setStartTime(start);
		String end = classInfo.getEndTime().substring(0,10);
		classInfo.setEndTime(end);
		return classInfo;
	}

	/**
	 * 獲取指定班級的學員列表
	 */
	@SuppressWarnings("unchecked")
	@Override
	public DataTableReturn getStudentListByClassId(DataTable dt, String classId) {
		DataTableReturn dtr = new DataTableReturn();
	    int skipResults = dt.getDisplayStart();
	    int maxResults = dt.getDisplayLength();
	    @SuppressWarnings("rawtypes")
		Map params = new HashMap();
	    params.put(DataTable.SEARCH, dt.getSearch());
	    params.put("classId",classId);
	    for( SortInfo sInfo : dt.getSortInfo() ) {
		params.put( DataTable.ORDER_COLUMN_SORT, 
				sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
	    }
	    PaginatedResult<ClassMember> list=classManagerDao.getStudentListByClassId(params, skipResults, maxResults);
	    dtr.setAaData(list.getResult());
		dtr.setiTotalDisplayRecords(list.getTotalResults());
		dtr.setiTotalRecords(list.getTotalResults());
		dtr.setsEcho(dt.getEcho());
	    return dtr;
	}

	@Override
	public void addPersonToClass(List<ClassMember> list) {
		classManagerDao.addPersonToClass(list);
		
	}

	/**
	 * 從班級學員名單中刪除學員
	 */
	@Override
	public void delClassMemberFromClass(List<ClassMember> classMemberList) {
		classManagerDao.delClassMemberFromClass(classMemberList);
		
	}

	/**
	 *  導出學員名單
	 */
	@Override
	public List<ClassMember> exportClassMember(String classId) {
		List<ClassMember> classMemberList = new LinkedList<ClassMember>();
		  try {
			  classMemberList= classManagerDao.getClassMemberListForExp(classId);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
		return classMemberList;

	}

	/**
	 * 通過id獲取課程相關信息
	 */
	@Override
	public ClassInfo getCourseInfoById(ClassInfo classInfo){
		return classManagerDao.getCourseInfoById(classInfo);
	}

	/**
	 * 在新增班級信息時，生成班級編號
	 */
	@Override
	public ClassInfo getAutoClassNo() {
		ClassInfo classInfo = new ClassInfo();
		List<ClassInfo> classInfoList = classManagerDao.getAutoClassNo();
		String currentDate = classManagerDao.getCurrentDate();
		if(classInfoList.size()!= 0){
			for(ClassInfo cla:classInfoList){
				String classNo = cla.getClassNo();
				String currentNo = classNo.substring(10, classNo.length());
				String nextNo = String.valueOf(Integer.parseInt(currentNo)+1);
				classInfo.setClassNo("C"+currentDate.substring(2, 10).replace("-", "")+"-00"+nextNo);
				break;
			}
		}else{
			classInfo.setClassNo("C"+currentDate.substring(2, 10).replace("-", "")+"-001");
		}
		return classInfo;
	}
}
