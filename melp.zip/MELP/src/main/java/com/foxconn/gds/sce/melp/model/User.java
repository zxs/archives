package com.foxconn.gds.sce.melp.model;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.ForeignKey;

/**
 * User: ronvargas
 * Date: Jan 27, 2009
 */
@Entity
@Table(name = "melp_user")
@NamedQueries(value = {
		@NamedQuery(name = "User.findByNull", query = "from User"),
		@NamedQuery(name = "User.findBySifRedId", query = "from User u where u.sifRefId=:sifRefId") 
})
public class User extends BasicEntity {

	@Column(nullable = false)
    private String username;

    private String grade;

    @Column(nullable = false)
    private String password;

    @Column(name = "sif_ref_id", unique = true)
    private String sifRefId;

    @ManyToMany
    @ForeignKey(name = "fk_user_role_id")
    @JoinTable(name = "melp_user_role_maps",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles;

    /*
    * The following fields will be added because they are required
    * to implement in UserSessionDetails
    * the 4 of them -- locked, active,enabled,expired
    * @TODO implement ExpiredCredentials
    */
    @Column(nullable = false)
    private boolean locked;

    @Column(nullable = false)
    private boolean active;

    @Column(nullable = false)
    private boolean enable;

    @Column(nullable = false)
    private boolean expired;

    @Column(nullable = false)
    private boolean deleted;

    @OneToOne(cascade = CascadeType.ALL)
    @ForeignKey(name = "fk_user_calendar_id")
    @JoinColumn(name = "user_calendar_id")
    private SimsCalendar calendar;

    
    
    
    
    public User() {
		super();
		this.active  = true;
		this.enable = true;
	}

	public boolean isEnabled() {
        return enable;
    }

    public void setEnabled(boolean enable) {
        this.enable = enable;
    }

    public boolean isExpired() {
        return expired;
    }

    public void setExpired(boolean expired) {
        this.expired = expired;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSifRefId() {
        return sifRefId;
    }

    public void setSifRefId(String sifRefId) {
        this.sifRefId = sifRefId;
    }

    public Set<Role> getRoles() {
    	if (roles == null){
    		setRoles(new HashSet<Role>());
    	}
    	return roles;
    }

    public void setRoles(Set<Role> roles) {
        this.roles = roles;
    }
    
    public void addRole(Role role){
    	Set<Role> roles = getRoles();
    	roles.add(role);
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public SimsCalendar getCalendar() {
        return calendar;
    }

    public void setCalendar(SimsCalendar calendar) {
        this.calendar = calendar;
    }

    public boolean onEquals(Object obj) {
        return new EqualsBuilder()
                .append(getId(), ((User) obj).getId())
                .append(getEntityCreationTimestamp(), ((User) obj).getEntityCreationTimestamp())
                .append(getUsername(), ((User) obj).getUsername())
                .append(getUserId(), ((User) obj).getUserId())
                .append(getDeptName(), ((User) obj).getDeptName())                
                .append(getGrade(), ((User) obj).getGrade())
                .append(getPassword(), ((User) obj).getPassword())
                .append(getSifRefId(), ((User) obj).getSifRefId())
                .append(isLocked(), ((User) obj).isLocked())
                .append(isActive(), ((User) obj).isActive())
                .append(isExpired(), ((User) obj).isExpired())
                .append(isEnabled(), ((User) obj).isEnabled())
                .isEquals();
    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getId())
                .append(getUsername())
                .append(getUserId())                
                .append(getEntityCreationTimestamp().toString())
                .append(getGrade())
                .toHashCode();
    }

    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    protected Object clone() throws CloneNotSupportedException {
        try {
            User cloneEntity = (User) super.clone();
            cloneEntity.setUsername(this.getUsername());
            cloneEntity.setUserId(this.getUserId());
            cloneEntity.setDeptName(this.getDeptName());
            
            cloneEntity.setGrade(this.getGrade());
            cloneEntity.setPassword(this.getPassword());
            cloneEntity.setSifRefId(this.getSifRefId());
            cloneEntity.setLocked(this.isLocked());
            cloneEntity.setActive(this.isActive());
            cloneEntity.setEnabled(this.isEnabled());
            cloneEntity.setExpired(this.isExpired());

            Set<Role> clonedRoles = null;
            if (this.getRoles() != null) {
                clonedRoles = new HashSet<Role>(this.getRoles().size());
                clonedRoles.addAll(this.getRoles());
            }
            cloneEntity.setRoles(clonedRoles);

            return cloneEntity;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen 
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }
    
    // ONLY FOR THIS MELP PROJECT
    @Column(name="USER_ID", nullable=false)
    private String userId;
    @Column(name="DEPT_NAME")
    private String deptName;


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
    
    
    
}
