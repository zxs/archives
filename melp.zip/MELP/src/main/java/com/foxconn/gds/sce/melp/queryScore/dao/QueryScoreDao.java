package com.foxconn.gds.sce.melp.queryScore.dao;

import java.util.List;
import com.foxconn.gds.sce.melp.model.VO_Front_ViewExam;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface QueryScoreDao extends GenericDao<VO_Front_ViewExam, String>{
	List<VO_Front_ViewExam> QueryScoreRecords(VO_Front_ViewExam exam,int userType);
	VO_Front_ViewExam QueryScoreTitle(VO_Front_ViewExam score);
	List<VO_Front_ViewExam> QueryScoreContent(VO_Front_ViewExam exam);
}
