package com.foxconn.gds.sce.melp.questionnaires.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface QuestionnairesService extends CrudService<Questionnaires> {
    public List<Questionnaires> showQuestionnaires_P();

    /**
	 * 批量新增評估項
	 *@author F3226075
	 *@date 2012-3-5 上午10:19:08
	 *@param evaluationItems
	 */
	 boolean importQuestionnaires(MultipartFile file,String user_id,String name) throws IOException;
	
}
