package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.ForeignKey;

import javax.persistence.*;
import java.util.List;

/**
 * An organization can be any education institution (schools, county/district education office, ...)
 * 
 * User: franco
 * Date: 23/01/2009
 * Time: 09:17:01 AM
 * 
 */

@Entity
@Table(name = "melp_organization")
public class Organization extends Party{

    //Name of the organization
	@Column(name = "name")
    private String name;

	//A second name used to refer to the organization
    @Column(name = "display_name")
    @OrderBy
    private String displayName;

    //Logo of the organization
    @Column(name = "logo_resource_id")
    private String logoResourceId;

    //Calendar of the organization
    @ManyToOne(cascade = CascadeType.ALL)
    @ForeignKey(name = "fk_organization_calendar_id")
    private SimsCalendar calendar;

    //Whether or not the organization has children organizations
    @Column(name = "is_parent_organization", nullable = false)
    private boolean isParentOrganization;

    //Whether or not the organization has been marked as deleted
    @Column(name = "deleted", nullable = false)
    private boolean deleted;

    //List of children organizations
    @OneToMany( fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
//    @ForeignKey(name = "fk_organization_organization_id")
    @org.hibernate.annotations.IndexColumn(name="list_index")        
    private List<Organization> childrenOrganizations;

    //Parent organization
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "parent_id")
    private Organization parent;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getLogoResourceId() {
        return logoResourceId;
    }

    public void setLogoResourceId(String logoResourceId) {
        this.logoResourceId = logoResourceId;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }


    public List<Organization> getChildrenOrganizations() {
        return childrenOrganizations;
    }

    public void setChildrenOrganizations(List<Organization> childrenOrganizations) {
        this.childrenOrganizations = childrenOrganizations;
    }

    public SimsCalendar getCalendar() {
        return calendar;
    }

    public void setCalendar(SimsCalendar calendar) {
        this.calendar = calendar;
    }



    public boolean isParentOrganization() {
        return isParentOrganization;
    }

    public void setIsParentOrganization(boolean parentOrganization) {
        isParentOrganization = parentOrganization;
    }

    public Organization getParent() {
        return parent;
    }

    public void setParent(Organization parent) {
        this.parent = parent;
    }

    public boolean onEquals(Object obj) {
    return new EqualsBuilder().append(getName(), ((Organization)obj).getName()).
            append(getDisplayName(), ((Organization)obj).getDisplayName()).
            append(getEntityCreationTimestamp(), ((Organization)obj).getEntityCreationTimestamp()).isEquals();
    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getName())

                .append(getDisplayName())
                .append(getEntityCreationTimestamp()).toHashCode();
    }

//    @Override
//    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
//    public Object clone() {
//            Organization cloneEntity = (Organization) super.clone();
//            cloneEntity.setName(this.getName());
//            cloneEntity.setDeleted(this.getDeleted());
//            cloneEntity.setCalendar(this.getCalendar());
//            cloneEntity.setChildrenOrganizations(this.getChildrenOrganizations());
//            cloneEntity.setCreationDate(this.getCreationDate());
//            cloneEntity.setDisplayName(this.getDisplayName());
//            cloneEntity.setIsParentOrganization(this.isParentOrganization());
//            //cloneEntity.setParent(this.getParent());
//            cloneEntity.setLogoResourceId(this.getLogoResourceId());
//            return cloneEntity;
//    }

}
