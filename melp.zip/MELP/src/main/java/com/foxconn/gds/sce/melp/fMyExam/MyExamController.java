package com.foxconn.gds.sce.melp.fMyExam;

import java.security.Principal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.support.DaoSupport;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.fMyExam.service.MyExamService;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionAndOption;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;

@Controller
@RequestMapping(value = "/fMyExam/**")
public class MyExamController {
	private MyExamService myExamService;
	
	@Autowired
	public void setMyExamService(MyExamService myExamService){
		this.myExamService=myExamService;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="myExamList.spr")
	public ModelAndView myExamList(){
		return new ModelAndView();
	}
	
	@RequestMapping(method=RequestMethod.POST,value="getMyExamList.spr")
	@ResponseBody
	public List<VO_ExamRoom> listMyExam(){
		String empNo="";
		empNo=SecurityUtils.getCurrentUser().getUserId();
		List<VO_ExamRoom> myExamRoomList=myExamService.listMyExam(empNo);
		return myExamRoomList;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="fMyExamList.spr")
	public String fMyExamList(){
		return "/fMyExam/myExamList";
	}
	
	@RequestMapping(method=RequestMethod.GET,value="examPaper.spr")
	public ModelAndView examPaper(HttpServletRequest request){
		ModelAndView modelAndView=new ModelAndView();
		ExamInfo examInfo=new ExamInfo();
		String loginUserId="";
		loginUserId=SecurityUtils.getCurrentUser().getUserId();
		String paperId=request.getParameter("paperId");
		String examRoomId=request.getParameter("examRoomId");		
//		String paperId="579AC62B88714F118EF9FE5E18DDB603";
//		String examRoomId="20111210003";
		PaperInfo paperInfo=myExamService.getPaperInfo(paperId);
		examInfo.setPaperId(paperId);
		examInfo.setEmpNo(loginUserId);
		examInfo.setCreator(loginUserId);
		examInfo.setExamRoomId(examRoomId);
		
		User user=new User();
/*		user.setUsername("邱連");
		user.setUserId("F3221433");*/
	    user=ClientUtil.getCurrentUser();
		
		myExamService.updateExamInfo(examInfo);
		modelAndView.addObject("paperInfo",paperInfo);
		modelAndView.addObject("paperId",paperId);
		modelAndView.addObject("examRoomId",examRoomId);
		modelAndView.addObject("user",user);
		return  modelAndView;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="getQuestions.spr")
	@ResponseBody
	public List<QuestionAndOption> getQuestions(HttpServletRequest request,HttpSession session){
		String paperId=request.getParameter("paperId");
		PaperInfo paperInfo=myExamService.getPaperInfo(paperId);
		int numS=paperInfo.getNumberS().intValue();
		int numM = paperInfo.getNumberM().intValue();
		int numTf= paperInfo.getNumberTf().intValue();
		List<QuestionAndOption> questionAndOptions=myExamService.getQuestionAndOptions(paperId,numTf,numS,numM);
		
//		List<QuestionAndOption> questionAndOptions=myExamService.getQuestionAndOptions("579AC62B88714F118EF9FE5E18DDB603", 3, 3, 3);
		session.setAttribute("questions", questionAndOptions);
		return questionAndOptions;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="checkExamPaper.spr")
	@ResponseBody
	public Map checkExamPaper(HttpServletRequest request,HttpSession session) throws ParseException{
		PaperDetail paperDetail=new PaperDetail();
		String loginUserId="";
		loginUserId=SecurityUtils.getCurrentUser().getUserId();
		String questionIdsString=request.getParameter("questionIds");
		String selectedOptionsString=request.getParameter("selectedOptions");
		String paperId=request.getParameter("paperId");
		String examRoomId=request.getParameter("examRoomId");
		String startTimeStr=request.getParameter("startTime");
//		String endTimeStr=request.getParameter("endTime");
		DateFormat df = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		
		Date startTime=df.parse(startTimeStr);
		Date endTime=new Date();
//		Date endTime=df.parse(endTimeStr);
		
		UUID uuid=UUID.randomUUID();
		String paperDetailId = uuid.toString().replace("-","");
		paperDetail.setId(paperDetailId);
		paperDetail.setEmpNo(loginUserId);
		paperDetail.setPaperId(paperId);
		paperDetail.setExamRoomId(examRoomId);
		paperDetail.setStartTime(startTime);
		paperDetail.setEndTime(endTime);
		paperDetail.setCreator(loginUserId);
		String[] questionIds=questionIdsString.split(",");
		String[] selectedOptions=selectedOptionsString.split("`");
		
		List<QuestionAndOption> questionAndOptions=(List<QuestionAndOption>)session.getAttribute("questions");
		Map map=myExamService.checkAnswer(loginUserId, paperId, paperDetailId, examRoomId, questionIds, selectedOptions, questionAndOptions);
		myExamService.insertExamPaper(paperDetail, questionAndOptions, selectedOptions);
		return map;
	}
	
	
}
