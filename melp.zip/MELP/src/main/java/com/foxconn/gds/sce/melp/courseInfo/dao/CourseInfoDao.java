package com.foxconn.gds.sce.melp.courseInfo.dao;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.CourseInfo;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface CourseInfoDao extends GenericDao<CourseInfo, String> {
	/**
	 * 查询课程列表显示
	 * @author F3226075 JTX
	 * @date Mar 1, 2012
	 * @param parameters
	 * @param skipResults
	 * @param maxResults
	 * @return PaginatedResult<ExamRoom>
	 */
	public PaginatedResult<CourseInfo> ListAllCourseInfo(Map<String,Object> parameters, int skipResults, int maxResults);
	/**
	 * 新增或修改課程
	 *@author F3226075
	 *@date 2012-3-2 上午9:58:01
	 * @param courseInfo
	 */
	public void saveOrUpdateCourseInfo(CourseInfo courseInfo);
	/**
	 * 獲取下拉框中的課程類型列表
	 *@author F3226075
	 *@date 2012-3-2 下午2:06:18
	 *@return
	 */
	public List<BaseCode> getCourseTypeSelect();
	 /**
	  * 根據id獲取課程信息
	  *@author F3226075
	  *@date 2012-3-2 下午3:53:45
	  *@param id
	  *@return
	  */
	public CourseInfo getCourseInfoById(String id);
	/**
	 * 通過id刪除課程
	 *@author F3226075
	 *@date 2012-3-2 下午4:58:39
	 *@param courseId
	 */
	public void deleteCourseInfoById(List<String> courseId);
	/**
	 * 批量新增評估項
	 *@author F3226075
	 *@date 2012-3-5 上午10:19:08
	 *@param evaluationItems
	 */
	public void insertEvaluationItemsBatch(List<EvaluationItems> evaluationItems);
	/**
	 * 通過課程id獲取評估項目
	 *@author F3226075
	 *@date 2012-3-6 下午3:38:43
	 *@param courseId
	 *@return
	 */
	public List<EvaluationItems> getEvaluationItemsByCourseId(String courseId);
	/**
	 * 刪除課程對應的評估項目
	 * @param evCourseId
	 */
	public void deleteEvaluationItems(String evCourseId);
}
