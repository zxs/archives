package com.foxconn.gds.sce.melp.courseInfo.service;

import java.io.InputStream;
import java.util.List;

import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.CourseInfo;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface CourseInfoService extends CrudService<CourseInfo>{
	/**
	 * 获取班级查询列表
	 * @author F3226075 JTX
	 * @date Mar 1, 2012
	 * @param dt
	 * @return DataTableReturn
	 */
	 public DataTableReturn ListAllCourseInfo(DataTable dt);
	 /**
	  * 新增或修改課程信息
	  *@author F3226075
	  *@date 2012-3-2 上午10:33:32
	  *@param courseInfo
	  */
	 public void saveOrUpdateCourseInfo(CourseInfo courseInfo);
	 /**
	  * 獲取課程代碼下拉列表
	  *@author F3226075
	  *@date 2012-3-2 下午2:12:49
	  *@return
	  */
	 public List<BaseCode> getCourseTypeSelect();
	 /**
	  * 根據id獲取課程信息
	  *@author F3226075
	  *@date 2012-3-2 下午3:53:45
	  *@param id
	  *@return
	  */
	public CourseInfo getCourseInfoById(String id);
	/**
	 * 通過id刪除課程
	 *@author F3226075
	 *@date 2012-3-2 下午4:58:39
	 *@param courseId
	 */
	public void deleteCourseInfoById(String courseId);
	/**
	 * 批量新增評估項
	 *@author F3226075
	 *@date 2012-3-5 上午10:19:08
	 *@param evaluationItems
	 */
	public void insertEvaluationItemsBatch(List<EvaluationItems> evaluationItems);
	/**
	 * 驗證幷獲取excel中內容
	 *@author F3226075
	 *@date 2012-3-5 下午4:56:32
	 *@param inputStream
	 * @param evSettings 
	 *@return
	 * @throws Exception 
	 */
	public Object inputStudentInfoExcel(InputStream inputStream, String evSettings) throws Exception;
	/**
	 * 通過課程id獲取評估項目
	 *@author F3226075
	 *@date 2012-3-6 下午3:38:43
	 *@param courseId
	 *@return
	 */
	public List<EvaluationItems> getEvaluationItemsByCourseId(String courseId);
	/**
	 * 刪除課程對應的評估項目
	 * @param evCourseId
	 */
	public void deleteEvaluationItems(String evCourseId);
}
