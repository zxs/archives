package com.foxconn.gds.sce.melp.studyRecord_bk.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.StudyRecord;
import com.foxconn.gds.sce.melp.model.Teacher;
import com.foxconn.gds.sce.melp.studyRecord_bk.dao.StudyRecordDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibStudyRecord")
public class IbStudyRecordDao extends GenericDaoIbatisImpl<StudyRecord, String> implements StudyRecordDao {

	@Autowired
	public IbStudyRecordDao(SqlMapClient sqlMapClient) {
		super(StudyRecord.class);
		setSqlMapClient(sqlMapClient);
	}

	public PaginatedResult<StudyRecord> selStudyRecord(Map parameters,int skipResults, int maxResults) 
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<StudyRecord> prStudyRecord = new PaginatedResult<StudyRecord>(page, pageSize);
		List<StudyRecord> result = null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("StudyRecord.findAllRecord", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("StudyRecord.findAllRecord", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("StudyRecord.findAllRecord_count", parameters);
		
		prStudyRecord.setResult(result);
		prStudyRecord.setTotalResults(count);
		
		return prStudyRecord;
	}
	
	
	 public List<Map> exports(Map paraMap)
	 {
		 List<Map> result=null;
		 result=(List<Map>)getSqlMapClientTemplate().queryForList("StudyRecord.findAllRecord_export", paraMap);
		 return result;
	 }
	
}
