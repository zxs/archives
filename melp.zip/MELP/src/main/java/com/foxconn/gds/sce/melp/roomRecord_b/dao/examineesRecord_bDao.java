package com.foxconn.gds.sce.melp.roomRecord_b.dao;

import java.util.Map;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface examineesRecord_bDao extends GenericDao<Examinees, String> {
	PaginatedResult<Examinees> listExaminees(Map parameters, int skipResults,
			int maxResults);
}
