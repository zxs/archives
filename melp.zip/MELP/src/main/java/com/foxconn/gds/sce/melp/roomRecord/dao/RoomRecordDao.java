package com.foxconn.gds.sce.melp.roomRecord.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface RoomRecordDao extends GenericDao<ExamRoom, String> {
	List<ExamRoom> QueryAllBy(ExamRoom exRoom,int userType);
}
