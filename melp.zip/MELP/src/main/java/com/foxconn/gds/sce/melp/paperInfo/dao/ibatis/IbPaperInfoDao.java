package com.foxconn.gds.sce.melp.paperInfo.dao.ibatis;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.paperInfo.dao.PaperInfoDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibPaperInfoDao")
public class IbPaperInfoDao extends GenericDaoIbatisImpl<PaperInfo, String> implements PaperInfoDao{
	
	@Autowired
    public IbPaperInfoDao(SqlMapClient sqlMapClient) {
		super(PaperInfo.class);
		setSqlMapClient(sqlMapClient);
	}
	

	//根据考卷名、用户去查询考场资料   River  20111215
	public List<PaperInfo> getQueryPaperInfo(String paperName, String userId) {
		// TODO Auto-generated method stub
		List listPaperInfo = null;
		try {
			Map<String, Object> hs = new HashMap<String, Object>();
			hs.put("creator", userId);
			// hs.put("paper_name", paperName);
			System.out.println("工号：" + userId + "_考卷名：" + paperName);
//			getSqlMapClientTemplate().queryForList(
//					"query_paperinfo_papernameandid", hs);
			System.out.println("getQueryPaperInfo" + 
					getSqlMapClientTemplate().queryForList("query_paperinfo_papernameandid", hs).size());
		} catch (Exception e) {
			System.out.println(e.toString());
			return null;
		}
		return listPaperInfo;
	}

	//根据用户去查询考场资料(页面初始化)  River  20111215
	public List<PaperInfo> getAllQueryPaperInfo(String userId) {
		// TODO Auto-generated method stub
		List<PaperInfo> listPaperInfo;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("creator", userId);			
			listPaperInfo = getSqlMapClientTemplate().queryForList("query_paperinfo_id", hs);
			
		}catch(Exception e){
				System.out.println(e.toString());
				return null;
			}		
			return listPaperInfo;
	}
}
