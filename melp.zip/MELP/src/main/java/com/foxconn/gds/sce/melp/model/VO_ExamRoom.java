package com.foxconn.gds.sce.melp.model;

import java.math.BigDecimal;

public class VO_ExamRoom extends ExamRoom {
	private BigDecimal totalScore; //總分
	private BigDecimal passScore; //合格分數
	private BigDecimal timeTotal; //考試時間
//	private BigDecimal examTimes; //已考試次數
//	private BigDecimal examTimesMax; //可考次數
//	private BigDecimal addTimes; //可補考次數
	private BigDecimal makeupTimes; //已補考次數
	private BigDecimal getScore; //得分

	public BigDecimal getGetScore() {
		return getScore;
	}
	public void setGetScore(BigDecimal getScore) {
		this.getScore = getScore;
	}
	public BigDecimal getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}
	public BigDecimal getPassScore() {
		return passScore;
	}
	public void setPassScore(BigDecimal passScore) {
		this.passScore = passScore;
	}
	public BigDecimal getTimeTotal() {
		return timeTotal;
	}
	public void setTimeTotal(BigDecimal timeTotal) {
		this.timeTotal = timeTotal;
	}
//	public BigDecimal getExamTimes() {
//		return this.examTimes;
//	}
//	public void setExamTimes(BigDecimal examTimes) {
//		this.examTimes = examTimes;
//	}
//	public BigDecimal getExamTimesMax() {
//		return examTimesMax;
//	}
//	public void setExamTimesMax(BigDecimal examTimesMax) {
//		this.examTimesMax = examTimesMax;
//	}
//	public BigDecimal getAddTimes() {
//		return addTimes;
//	}
//	public void setAddTimes(BigDecimal addTimes) {
//		this.addTimes = addTimes;
//	}
	public BigDecimal getMakeupTimes() {
		/*BigDecimal result=new BigDecimal(0);
		if(examTimes.subtract(examTimesMax).compareTo(result)>0){
			return examTimes.subtract(examTimesMax);
		}
		else {
			return result;
		}*/
		return makeupTimes;
	}
	public void setMakeupTimes(BigDecimal makeupTimes) {
		this.makeupTimes = makeupTimes;
	}
}
