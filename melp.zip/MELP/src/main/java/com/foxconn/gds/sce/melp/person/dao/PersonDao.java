package com.foxconn.gds.sce.melp.person.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.Person;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

/**
 * @author Edward
 */
public interface PersonDao extends GenericDao<Person, String> {

    /**
    * Retrieves All Persons
    * @return A list of person Objects
    */
   List<Person> getPersons();

    /**
    * Retrieves a person
    * @param personId person id
    * @return A Person Object
    */
   Person getPerson(String personId);
}
