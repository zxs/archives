package com.foxconn.gds.sce.melp.room.dao;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
public interface RoomDao extends GenericDao<ExamRoom, String>{
	public void InsertRoom(ExamRoom roominfo);
	public PaginatedResult<ExamRoom> ListAllRoom(Map parameters, int skipResults, int maxResults);
	public Integer UpdateRoom(ExamRoom examRoom);
	public ExamRoom QueryRoomByPara(ExamRoom examRoom);
	public void DeleteRoom(final List<ExamRoom> listexamRoom); 
	public String GetMaxRoomID() throws Exception;
	public void UpdateSync(final List<ExamRoom> examRoom);
	public void InsertExaminees(final List<Examinees> examinees);
	public PaginatedResult<Examinees> ListExamineesByRoom(Map parameters, int skipResults, int maxResults);
	public void DelPerFromRoom(final List<Examinees> listExaminees); 
	public List<Examinees> GetExamineeForExp(String roomid);
}
