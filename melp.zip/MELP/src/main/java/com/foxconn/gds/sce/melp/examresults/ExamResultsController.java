package com.foxconn.gds.sce.melp.examresults;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.examresults.service.ExamResultsService;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;

@Controller
@RequestMapping(value = "/examresults/**")
public class ExamResultsController {

	private ExamResultsService examResultsService;

	@Autowired
	public void setExamResultsService(ExamResultsService examResultsService) {
		this.examResultsService = examResultsService;
	}

	@RequestMapping(method = RequestMethod.GET, value = "examresults.spr")
	//@ResponseBody
	public ModelAndView showExamResults(@RequestParam("iframe") String iframe) {
		
		return new ModelAndView("examresults/examresults", "iframe","true".equals(iframe)?true:false);
	}
	@RequestMapping(method=RequestMethod.POST,value="listExamResults.spr")
	@ResponseBody
	public Object listExamResults(@RequestParam("_dt_json") String dtjson){
//		String paperName = request.getParameter("papername");
//		String empNo = request.getParameter("userid");

//		ExamResults examResult = new ExamResults();
//		examResult.setPaperName(paperName);
//		examResult.setEmpNo(empNo);
//		examResult.setEmpName(empName);
//		List<ExamResults> list = examResultsService.listExamResults(examResult);
//		HashMap map=new HashMap();
//		map.put("aaData", list);
//		String userName = request.getParameter("username");
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn = examResultsService.listExamResults4DT(dataTable);

		return tableReturn;
	}
	@RequestMapping(method=RequestMethod.GET,value="showPaper.spr")
	public ModelAndView showPaper(HttpServletRequest request,HttpServletResponse httpServletResponse){
		/*String paperName = request.getParameter("papername");
		String empNo = request.getParameter("userid");
		String userName = request.getParameter("username");*/
		ExamResults examResult = new ExamResults();
		/*examResult.setPaperName(paperName);
		examResult.setEmpNo(empNo);
		examResult.setUserName(userName);*/
		
		String paperID=request.getParameter("paperID");
		String examRoomID=request.getParameter("examRoomID");
		String empNo=request.getParameter("empNo");
		//added by Cube @111227
		String PAPERDETAILID=request.getParameter("PAPERDETAILID");
		
		HashMap hashMap=new HashMap();
		hashMap.put("paperID",paperID);
		hashMap.put("examRoomID", examRoomID);
		hashMap.put("empNo", empNo);
		hashMap.put("PAPERDETAILID", PAPERDETAILID);
		
		Paper paper = examResultsService.showPaperTitle(hashMap);
		List<Paper> list_S=examResultsService.showPaperContent_S(hashMap);
		List<Paper> list_M=examResultsService.showPaperContent_M(hashMap);
		List<Paper> list_TF=examResultsService.showPaperContent_TF(hashMap);
		ModelAndView mav=new ModelAndView("/examresults/paperdetail");
		mav.addObject(paper);
		mav.addObject("papercontent_s",list_S);
		mav.addObject("papercontent_m",list_M);
		mav.addObject("papercontent_tf",list_TF);
		return mav;
	}
	

}
