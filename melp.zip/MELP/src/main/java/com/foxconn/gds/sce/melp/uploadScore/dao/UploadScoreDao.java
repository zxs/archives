package com.foxconn.gds.sce.melp.uploadScore.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface UploadScoreDao extends GenericDao<Examinees, String>{
	boolean updateOrInsertInfos(final List<Examinees> inees,
			final List<ExamResults> results,final List<ExamInfo> info,
			final List<PaperDetail> paperDetail,
			final List<QuestionDetail> quesDetail,
			final List<OptionDetail> optionDetail);
}
