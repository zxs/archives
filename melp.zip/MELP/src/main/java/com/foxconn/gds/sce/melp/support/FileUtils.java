package com.foxconn.gds.sce.melp.support;

import java.io.File;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.foxconn.gds.sce.melp.support.listener.FilePathListener;

public final class FileUtils {

	private static Logger log = LoggerFactory.getLogger(FileUtils.class);
	
	public static File getUsersFile() {
		return new File(FilePathListener.templateFilePath + File.separator + "UsersFile.xls");
	}
	
	public static File getExamineesImportFile() {
		return new File(FilePathListener.templateFilePath + File.separator + "ExamineesImportFile.xls");
	}	

	public static File getExamineesExportFile() {
		return new File(FilePathListener.templateFilePath + File.separator + "ExamineesExportFile.xls");
	}	
	
	public static File getQuestionsImportFile() {
		return new File(FilePathListener.templateFilePath + File.separator + "QuestionsImportFile.xls");
	}	
	
	public static File getQuestionsExportFile() {
		return new File(FilePathListener.templateFilePath + File.separator + "QuestionsExportFile.xls");
	}	
	
	/**
	 * 根據給定的文件名(帶文件類型) 獲得一個位於上傳目錄的文件
	 * @param name
	 * @return
	 */
	public static File getUploadFile(String name) {
		if( !(name!=null && name.length()!=0) ) {
			name = UUID.randomUUID().toString();
		}
		return new File(FilePathListener.uploadFilePath + File.separator + name);
	}
}
