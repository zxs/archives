package com.foxconn.gds.sce.melp.model;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BasicPermission extends BasicEntity implements java.security.acl.Permission{
	

	@Enumerated(value = EnumType.STRING)
	@Column(name = "access_level", nullable = false)
	private AccessLevel accessLevel;

	@Enumerated(value = EnumType.STRING)
	@Column(name = "permission_type", nullable = false)
	private PermissionType permissionType;
	
	public BasicPermission(){
		
	}
	
	protected BasicPermission(PermissionType permissionType, 
			AccessLevel accessLevel,
			boolean enabled) {
		super();
		this.accessLevel = accessLevel;
		this.permissionType = permissionType;
		this.enabled = enabled;
	}

	private boolean enabled;
	
	
	
	
	public PermissionType getPermissionType() {
		return permissionType;
	}

	public void setPermissionType(PermissionType permissionType) {
		this.permissionType = permissionType;
	}

	public AccessLevel getAccessLevel() {
		return accessLevel;
	}

	public void setAccessLevel(AccessLevel accessLevel) {
		this.accessLevel = accessLevel;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	@Override
	public int onHashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((accessLevel == null) ? 0 : accessLevel.hashCode());
		result = prime * result
		+ ((permissionType == null) ? 0 : permissionType.hashCode());
		return result;
	}

	@Override
	public boolean onEquals(Object obj) {
		if (this == obj)
			return true;
		if (getClass() != obj.getClass())
			return false;
		BasicPermission other = (BasicPermission) obj;
		if (accessLevel == null) {
			if (other.accessLevel != null)
				return false;
		} else if (!accessLevel.equals(other.accessLevel))
			return false;
		if (permissionType == null) {
			if (other.permissionType != null)
				return false;
		} else if (!permissionType.equals(other.permissionType))
			return false;
		return true;
	}

	
	
	

}
