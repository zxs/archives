package com.foxconn.gds.sce.melp.support.dao.impl;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.orm.ObjectRetrievalFailureException;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.finder.FinderArgumentTypeFactory;
import com.foxconn.gds.sce.melp.support.dao.finder.FinderExecutor;
import com.foxconn.gds.sce.melp.support.dao.finder.FinderNamingStrategy;
import com.foxconn.gds.sce.melp.support.dao.finder.impl.SimpleFinderArgumentTypeFactory;
import com.foxconn.gds.sce.melp.support.dao.finder.impl.SimpleFinderNamingStrategy;
import com.foxconn.gds.sce.melp.support.dao.util.DaoUtils;
import com.ibatis.sqlmap.client.SqlMapClient;

/**
 * Ibatis implementation of GenericDao. <br>
 * A typesafe implementation of CRUD and finder methods based on Ibatis and Spring AOP.<br>
 * 
 * The finders are implemented through the executeFinder method. <br>
 * Normally called by the FinderIntroductionInterceptor
 */
public class GenericDaoIbatisImpl<T, PK extends Serializable> implements
		GenericDao<T, PK>, FinderExecutor<T> {
	
	private static final Logger log = LoggerFactory.getLogger(DaoUtils.class);
	
	private SqlMapClient sqlMapClient;
	private SqlMapClientTemplate sqlMapClientTemplate;
	// Default. Can override in config
	private FinderNamingStrategy namingStrategy = new SimpleFinderNamingStrategy();
	// Default. Can override in config
	private FinderArgumentTypeFactory argumentTypeFactory = new SimpleFinderArgumentTypeFactory();

	private Class<T> type;

	public GenericDaoIbatisImpl(Class<T> type) {
		this.type = type;
	}
	

	@SuppressWarnings("unchecked")
	public PK create(T o) {
		String className = ClassUtils.getShortName(o.getClass());
        Object primaryKey = DaoUtils.getPrimaryKeyValue(o);
        Class primaryKeyClass = DaoUtils.getPrimaryKeyFieldType(o);
        String keyId = null;

        // check for null id
        if (primaryKey != null) {
            keyId = primaryKey.toString();
        }

        // check for new record
        if (StringUtils.isBlank(keyId)) {
            DaoUtils.prepareObjectForSaveOrUpdate(o);
            primaryKey = getSqlMapClientTemplate().insert(DaoUtils.getInsertQuery(className), o);
            DaoUtils.setPrimaryKey(o, primaryKeyClass, primaryKey);
        } else {
            DaoUtils.prepareObjectForSaveOrUpdate(o);
            getSqlMapClientTemplate().update(DaoUtils.getUpdateQuery(className), o);
        }

        // check for null id
        if (DaoUtils.getPrimaryKeyValue(o) == null) {
            throw new ObjectRetrievalFailureException(className, o);
        } else {
            return (PK) primaryKey;
        }
	}

	@SuppressWarnings("unchecked")
	public T read(PK id) {
		String className = ClassUtils.getShortName(this.type);
		T object = (T) getSqlMapClientTemplate().queryForObject(DaoUtils.getFindQuery(className), id);
		if (object == null) {
			log.warn("Uh oh, '" + this.type + "' object with id '" + id	+ "' not found...");
			throw new ObjectRetrievalFailureException(className, id);
		}
		return object;
	}

	public void update(T o) {
		this.create(o);
	}

	/**
	 * TODO 
	 */
	public void delete(T o) {
		
	}
	
	
	public List executeFinder(Method method, Object[] queryArgs) {
		String statId = namingStrategy.queryNameFromMethod(type, method);
		return sqlMapClientTemplate.queryForList(statId, queryArgs);
	}

	public Iterator iterateFinder(Method method, Object[] queryArgs) {
		// TODO Auto-generated method stub
		return null;
	}
	

	private SqlMapClient getSqlMapClient() {
		return sqlMapClient;
	}
	
	public SqlMapClientTemplate getSqlMapClientTemplate() {
		if(sqlMapClientTemplate==null) {
			sqlMapClientTemplate =new SqlMapClientTemplate(getSqlMapClient());
		}
		return sqlMapClientTemplate;
	}	
	
	public void setSqlMapClient(SqlMapClient sqlMapClient) {
		Assert.notNull(sqlMapClient, "sqlMapClient object must not be null");
		this.sqlMapClient = sqlMapClient;
	}
	


	public FinderNamingStrategy getNamingStrategy() {
		return namingStrategy;
	}


	public void setNamingStrategy(FinderNamingStrategy namingStrategy) {
		this.namingStrategy = namingStrategy;
	}


	public FinderArgumentTypeFactory getArgumentTypeFactory() {
		return argumentTypeFactory;
	}


	public void setArgumentTypeFactory(FinderArgumentTypeFactory argumentTypeFactory) {
		this.argumentTypeFactory = argumentTypeFactory;
	}



}
