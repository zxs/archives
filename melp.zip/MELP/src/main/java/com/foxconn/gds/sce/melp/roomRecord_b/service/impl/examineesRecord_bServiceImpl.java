package com.foxconn.gds.sce.melp.roomRecord_b.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.roomRecord_b.dao.examineesRecord_bDao;
import com.foxconn.gds.sce.melp.roomRecord_b.service.examineesRecord_bService;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "examineesRecord_bService")
@Transactional
public class examineesRecord_bServiceImpl extends
		CrudServiceImpl<Examinees, examineesRecord_bDao> implements
		examineesRecord_bService {

	@Autowired
	public void setexamineesRecord_bDao(examineesRecord_bDao dao) {
		this.daoSupport = dao;
	}

	public void create(Examinees entity) {
		// TODO Auto-generated method stub

	}

	public void update(Examinees entity) {
		// TODO Auto-generated method stub

	}

	public void delete(Examinees entity) {
		// TODO Auto-generated method stub

	}

	public Examinees read(String entityId) {
		// TODO Auto-generated method stub
		return null;
	}

	public DataTableReturn listForDT(DataTable dt, String strRoomID) {
		DataTableReturn dtr = new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		params.put("examRoomId", strRoomID);
		params.put(DataTable.SEARCH, dt.getSearch());
		for (SortInfo sInfo : dt.getSortInfo()) {
			params.put(DataTable.ORDER_COLUMN_SORT, sInfo.getColumnId() + " "
					+ sInfo.getSortOrder());
		}

		PaginatedResult<Examinees> examinees = daoSupport.listExaminees(params,
				skipResults, maxResults);

		dtr.setAaData(examinees.getResult());
		dtr.setiTotalDisplayRecords(examinees.getTotalResults());
		dtr.setiTotalRecords(examinees.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

}
