package com.foxconn.gds.sce.melp.fMyExam.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.fMyExam.dao.MyExamDao;
import com.foxconn.gds.sce.melp.fMyExam.dao.ibatis.IbMyExamDao;
import com.foxconn.gds.sce.melp.fMyExam.service.MyExamService;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionAndOption;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "myExamServer")
public class MyExamServiceImpl extends CrudServiceImpl<VO_ExamRoom, MyExamDao>
		implements MyExamService {

	@Autowired
	public void setIbMyExamDao(IbMyExamDao ibMyExamDao) {
		this.daoSupport = ibMyExamDao;
	}

	public List<VO_ExamRoom> listMyExam(String empNo) {
		return daoSupport.listMyExam(empNo);
	}

	public boolean updateExamInfo(ExamInfo examInfo) {
		return daoSupport.updateExamInfo(examInfo);
	}

	public PaperInfo getPaperInfo(String paperId) {
		return daoSupport.getPaperInfo(paperId);
	}

	public List<QuestionAndOption> getQuestionAndOptions(String paperId,
			int tfNum, int sNum, int mNum) {
		Map parameterMap = new HashMap();
		parameterMap.put("paperId", paperId);
		parameterMap.put("tf_num", tfNum);
		parameterMap.put("s_num", sNum);
		parameterMap.put("m_num", mNum);
		// parameterMap.put("MY_CUR", value);
		return daoSupport.getQuestionAndOptions(parameterMap);
	}

	public Map checkAnswer(String empNo, String paperId,String examResultId, String examRoomId,
			String[] questionIds, String[] myAnswers,
			List<QuestionAndOption> questionList) {
		float score = 0;
		PaperInfo paperInfo = this.getPaperInfo(paperId);
		for (int i = 0; i < questionIds.length; i++) {
			String[] myAnswer = myAnswers[i].split(",");
			List<QuestionAndOption> rightAnswer = new ArrayList<QuestionAndOption>();
			for (QuestionAndOption questionAndOption : questionList) {
				if ((questionAndOption.getQuestionId().equals(questionIds[i]))
						&& (questionAndOption.getIsRightAnswer().equals("Y"))) {
					rightAnswer.add(questionAndOption);
				}
			}
			if (myAnswer.length == rightAnswer.size()) {
				boolean flag = true;
				int count=0;
				for (int j = 0; flag && (j < myAnswer.length); j++) {
					if(count!=j){
						break;
					}
					for (int k = 0; k < rightAnswer.size(); k++) {
						if (myAnswer[j].equals(rightAnswer.get(k).getId())) {
							count++;
							if (j == myAnswer.length - 1) {
								// 計算分數
								if (rightAnswer.get(k).getQuestionType()
										.equals("0")) {
									score += paperInfo.getScoreTf()
											.floatValue();
								} else if (rightAnswer.get(k).getQuestionType()
										.equals("1")) {
									score += paperInfo.getScoreS().floatValue();
								} else if (rightAnswer.get(k).getQuestionType()
										.equals("2")) {
									score += paperInfo.getScoreM().floatValue();
								}
								flag = false;
								break;
							}
							break;
						}
					}
				}
			} else {
				continue;
			}
		}
		Map resultMap = new HashMap();
		resultMap.put("getScore", score);
		if (score >= paperInfo.getPassScore().floatValue()) {
			resultMap.put("isPassed", true);
		} else {
			resultMap.put("isPassed", false);
		}
		// 寫考試結果到數據庫。。。。
		ExamResults examResult = new ExamResults();
		examResult.setId(examResultId);
		examResult.setPaperId(paperId);
		examResult.setEmpNo(empNo);
		examResult.setExamRoomId(examRoomId);
		examResult.setGetScore(new BigDecimal(score));
		examResult.setCreator(empNo);
		insertExamResult(examResult);// 插入考試結果
		return resultMap;
	}

	/*
	 * 保存已考過的考卷信息
	 * 
	 * @see
	 * com.foxconn.gds.sce.melp.fMyExam.service.MyExamService#insertExamPaper
	 * (com.foxconn.gds.sce.melp.model.PaperDetail,
	 * com.foxconn.gds.sce.melp.model.QuestionAndOption, java.lang.String[])
	 */
	public boolean insertExamPaper(PaperDetail paperDetail,
			List<QuestionAndOption> questionList, String[] userAnswer) {
		
		List<String> userAnswers = new ArrayList<String>();
		for (String answer : userAnswer) {
			if (!answer.isEmpty()) {
				userAnswers.addAll(Arrays.asList(answer.split(",")));
			}
		}

		List<QuestionDetail> questionDetails = new ArrayList<QuestionDetail>();
		List<OptionDetail> optionDetails = new ArrayList<OptionDetail>();
		String preQuesId = "";
		int i = 1;
		int j = 1;
		QuestionDetail questionDetail;
		OptionDetail optionDetail;
		for (QuestionAndOption tempQues : questionList) {
			if (tempQues.getQuestionId().equals(preQuesId)) {
				j++;
				optionDetail = new OptionDetail();
				optionDetail.setPaperDetailId(paperDetail.getId());
				optionDetail.setOptionId(tempQues.getId());
				optionDetail.setOptionOrder(new BigDecimal(j));
				optionDetail.setCreator(paperDetail.getEmpNo());
				int index = userAnswers.indexOf(tempQues.getId());
				if (index != -1) {
					optionDetail.setIsUserAnswer("Y");
				} else {
					optionDetail.setIsUserAnswer("N");
				}
				optionDetails.add(optionDetail);
			} else {
//				if(!preQuesId.isEmpty()){
					j = 1;
//				}
				questionDetail = new QuestionDetail();
				questionDetail.setPaperDetailId(paperDetail.getId());
				questionDetail.setQuestionId(tempQues.getQuestionId());
				questionDetail.setQuestionOrder(new BigDecimal(i));
				questionDetail.setCreator(paperDetail.getEmpNo());
				questionDetails.add(questionDetail);
				i++;

				optionDetail = new OptionDetail();
				optionDetail.setPaperDetailId(paperDetail.getId());
				optionDetail.setOptionId(tempQues.getId());
				optionDetail.setOptionOrder(new BigDecimal(j));
				optionDetail.setCreator(paperDetail.getEmpNo());
				int index = userAnswers.indexOf(tempQues.getId());
				if (index != -1) {
					optionDetail.setIsUserAnswer("Y");
				} else {
					optionDetail.setIsUserAnswer("N");
				}
				optionDetails.add(optionDetail);
				preQuesId=tempQues.getQuestionId();
			}
		}
		daoSupport.insertPaperDetail(paperDetail);
		for (OptionDetail option : optionDetails) {
			daoSupport.insertOptionDetail(option);
		}
		for (QuestionDetail question: questionDetails) {
			daoSupport.insertQuestionDetail(question);
		}
		return true;
	}

	/*
	 * 保存考試結果信息
	 * 
	 * @see
	 * com.foxconn.gds.sce.melp.fMyExam.service.MyExamService#insertExamResult
	 * (com.foxconn.gds.sce.melp.model.ExamResult)
	 */
	public boolean insertExamResult(ExamResults examResult) {
		daoSupport.insertExamResult(examResult);
		return true;
	}

}
