package com.foxconn.gds.sce.melp.makeup.service;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface MakeupService extends CrudService<ExamInfo> {

	public DataTableReturn getListForDataTable(DataTable dataTable);

	public DataTableReturn getMakeupInfoForDataTable(DataTable dataTable, String showtimesNo);

	public boolean addMakeupTimes(String id);

	public boolean reduceMakeupTimes(String id);
	

}
