package com.foxconn.gds.sce.melp.security;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.GrantedAuthorityImpl;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.foxconn.gds.sce.melp.model.AccessLevel;
import com.foxconn.gds.sce.melp.model.PermissionType;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.User;

/**
 * This is the user Session De
 * @author: Andres Vega
 */
public class UserSessionDetails implements UserDetails {

    private static final String ROLE_PERMISSION_PREFIX = "P_";
    
	final private User user;
    private Collection<GrantedAuthority>  grantedAuthorities;
    
    public UserSessionDetails(User user){

        this.user=user;

        setAuthorities(user.getRoles());
    }

    private void setAuthorities(Set<Role> roles) {
    	Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
    	for (Role role : roles) {
			authorities.addAll(getGrantedAuthorities(role));
		}
    
		this.grantedAuthorities = authorities;//.toArray(new GrantedAuthority[authorities.size()]);
	}

	private Set<GrantedAuthority> getGrantedAuthorities(Role role){
    	Set<GrantedAuthority> authorities = new HashSet<GrantedAuthority>();
    	Set<RolePermission> permissions = role.getPermissions();
    	for (RolePermission rolePermission : permissions) {
    		if (rolePermission.isEnabled()){
	    		String authority = buildRolePermissionAuthority(rolePermission);
	    		authorities.add(new GrantedAuthorityImpl(authority));
    		}
		}
    	return authorities;
    }

	/**
	 * An authority is a string value that represent the spring framework config attribute
	 * The format is {PREFIX}_{PERMISSION_TYPE_CODE}_{ACCESS_LEVEL}
	 * Examples:
	 *     P_CLA_ACCESS 
	 *     P_CLA-ENROLL_ACCESS
	 * @param rolePermission role permission
	 * @return Authority
	 * @see PermissionType
	 * @see AccessLevel
	 */
    private String buildRolePermissionAuthority(RolePermission rolePermission){
        PermissionType permissionType = rolePermission.getPermissionType();
        AccessLevel accessLevel = rolePermission.getAccessLevel();
        
		return String.format("%s%s_%s", 
				ROLE_PERMISSION_PREFIX, 
				permissionType.getCode(), 
				accessLevel.getCode());
    }

    public Collection<GrantedAuthority>  getAuthorities() {
        return  grantedAuthorities; 
    }

    public String getPassword() {
        return user.getPassword();
    }

    public String getUsername() {
        return user.getUsername();
    }

    public boolean isAccountNonExpired() {
        return !user.isExpired();
    }

    public boolean isAccountNonLocked() {
        return !user.isLocked();
    }

    public boolean isCredentialsNonExpired() {
        return !user.isExpired();
    }

    public boolean isEnabled() {
        return user.isActive();
    }
    
    public User getUser() {
    	return user;
    }
}
