package com.foxconn.gds.sce.melp.evaluateCourse.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.evaluateCourse.dao.EvaluateCourseDao;
import com.foxconn.gds.sce.melp.evaluateCourse.service.EvaluateCourseService;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.questionnaires.dao.QuestionnairesDao;
import com.foxconn.gds.sce.melp.questionnaires.service.QuestionnairesService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
@Service(value = "evaluateCourseService")
public class EvaluateCourseServiceImpl extends CrudServiceImpl<Questionnaires, EvaluateCourseDao> implements EvaluateCourseService{
	@Autowired
	public void setIbEvaluateCourseDao(EvaluateCourseDao evaluateCourseDao){
		this.daoSupport=evaluateCourseDao;
	}
	public List<Questionnaires> showQuestionnaires_P(String courseID,String courseCreator)
	    {
	    	return (List<Questionnaires>) daoSupport.showQuestionnaires_P(courseID,courseCreator);	
		};
	@Transactional(readOnly=false)
	public Boolean updateEvRecord(String questionId,String option,String classID,String courseID,String empNo)
	{
		return daoSupport.updateEvRecord(questionId, option,classID,courseID,empNo);
	}
	@Transactional(readOnly=false)
	public Boolean insertEvRecord(String classID,String courseID,String empNo)
	{
		return daoSupport.insertEvRecord(classID,courseID,empNo);
	}
	@Override
	public int getEvType(String courseID) {
		
		return daoSupport.getEvType(courseID);
	}
public String getCourseCreator(String courseID) {
		
		return daoSupport.getCourseCreator(courseID);
	}
}
