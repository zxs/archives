package com.foxconn.gds.sce.melp.model;
import org.apache.commons.lang.builder.ReflectionToStringBuilder;


public class Questionnaires extends BasicEntity{
	
	/**
	 * Column:PART_NAME
	 * 默認評估項目部份
	 */
	public String itemID;
	
	public String getItemID() {
		return itemID;
	}

	public void setItemID(String itemID) {
		this.itemID = itemID;
	}

	public String partName;
	/**
	 * Column:CONTENT
	 * 評估項目內容
	 */
	public String evContent;
	
	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}

	public String getEvContent() {
		return evContent;
	}

	public void setEvContent(String evContent) {
		this.evContent = evContent;
	}
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String toString(){
		return ReflectionToStringBuilder.toString(this);
	}
}
