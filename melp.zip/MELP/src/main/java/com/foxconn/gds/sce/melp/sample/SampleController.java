package com.foxconn.gds.sce.melp.sample;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.sample.service.SampleService;

@Controller
@RequestMapping(value="/sample/**")
public class SampleController {
	
	private SampleService sampleSrv;
	
	@Autowired
	public void setSampleService(SampleService sampleSrv) {
		this.sampleSrv = sampleSrv;
	}

	@RequestMapping(method=RequestMethod.GET, value="listAllUsers.spr")
	public ModelAndView listAllUsers() {
		List<User> users = sampleSrv.listAllUser();
		return new ModelAndView();
	}
	
	@RequestMapping(method={RequestMethod.GET}, value="addUser.spr")
	public ModelAndView addUser() {
		
		return new ModelAndView();
	}	
	
	@RequestMapping(method=RequestMethod.GET, value="deleteUser.spr")
	public ModelAndView deleteUser() {
		
		return new ModelAndView();
	}		
	
	// Spring MVC will auto converter Object to JSON format... 
	// <mvc:annotation-driven />
	
	@RequestMapping(method=RequestMethod.POST)
	public @ResponseBody Map<String, ? extends Object> fooo(HttpServletRequest req, HttpServletResponse response) {
		
		return new HashMap<String, Object>();
	}
		
	//REF. http://stackoverflow.com/questions/248562/when-using-spring-security-what-is-the-proper-way-to-obtain-current-username-i
	//Get Current Logined User
	 @RequestMapping(method = RequestMethod.GET)   
	 public ModelAndView showResults(final HttpServletRequest request, Principal principal) {
	        final String currentUser = principal.getName();
//	        ...
	        return new ModelAndView();
	 }
		
	
}
