package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.ForeignKey;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Person contains the personal information of any Person (users and contacts)  in the application.
 * This class extends Party.
 * 
 * User: ronvargas
 * Date: Feb 3, 2009
 */
@Entity
@Table(name = "melp_person")
public class Person extends Party{

	//First name
    @Column(name = "first_name", nullable = false)
    private String firstName;

    //Last name
    @Column(name = "last_name", nullable = false)
    private String lastName;

    //Birth day
    @Column(name = "birthday")
    private Date birthday;

    //Salutation (Mr. Ms. Miss)
    @Column(name = "salutation")
    private String salutation;

    //Gender {Male/Female}
    @Column(name = "gender")
    private String gender;

    //Whether or not the person has been marked as deleted
    @Column(name = "deleted")
    private boolean deleted;

    //List of contacts of the person
//    @OneToMany(cascade = CascadeType.ALL)
//    @ForeignKey(name = "fk_person_contact_id")
//    @JoinColumn(name="dependent_id" )
//    private List<Contact> contacts;
//
//    public List<Contact> getContacts() {
//        if (contacts == null){
//            contacts = new ArrayList<Contact>();
//        }
//        return contacts;
//    }
//
//    public void setContacts(List<Contact> contacts) {
//        this.contacts = contacts;
//    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getSalutation() {
        return salutation;
    }

    public void setSalutation(String salutation) {
        this.salutation = salutation;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

//    public Contact getContactByPersonId(Long personId){
//        contacts = getContacts();
//        for (Contact contact : contacts) {
//            if (contact.getPerson().getId().equals(personId)){
//                return contact;
//            }
//        }
//        return null;
//    }

    public boolean onEquals(Object o) {
        return new EqualsBuilder()
                .append(getFirstName(), ((Person) o).getFirstName()).
                        append(getLastName(), ((Person) o).getLastName()).
                        append(getBirthday(), ((Person) o).getBirthday()).
                        append(getSalutation(), ((Person) o).getSalutation()).
                        append(getGender(), ((Person) o).getGender())
                .isEquals();
    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getFirstName())
                .append(getLastName())
                .append(getBirthday())
                .append(getSalutation())
                .append(isDeleted())
                .append(getGender()).
                        toHashCode();
    }

    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    public Object clone() {
        Person cloneEntity = (Person) super.clone();
        cloneEntity.setFirstName(this.getFirstName());
        cloneEntity.setLastName(this.getLastName());
        cloneEntity.setBirthday(this.getBirthday());
        cloneEntity.setDeleted(this.isDeleted());
        cloneEntity.setSalutation(this.getSalutation());
        cloneEntity.setGender(this.getGender());
//        cloneEntity.setContacts(this.getContacts());
        return cloneEntity;
    }

}
