package com.foxconn.gds.sce.melp.role.service;

import com.foxconn.gds.sce.melp.model.PermissionType;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface RolePermissionService extends CrudService<RolePermission>{
	
	/**
	 * Returns a role permission for a specific role
	 * @param roleId
	 * @param permissionType
	 * @return
	 */
	RolePermission getRolePermission(String roleId, PermissionType permissionType);
}
