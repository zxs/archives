package com.foxconn.gds.sce.melp.uploadScore;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.roomRecord.service.RoomRecordService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.uploadScore.service.UploadScoreService;

@Controller
@RequestMapping(value="/uploadScore/**")
public class UploadScoreController {
	private UploadScoreService service;
	@Autowired
	public void setAllService(UploadScoreService uploadService)
	{
		this.service=uploadService;
	}
	//考場記錄頁面
		@RequestMapping(method={RequestMethod.GET}, value="scoreOffLineList.spr")
		public ModelAndView ShowRoomRecordSearchView()
		{
			String loger=SecurityUtils.getCurrentUser().getUserId();
			int userType=-1;
			if(SecurityUtils.administratorPlayedbyCurrentUser()){
				userType=0;
			}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
				userType=1;
			}else{
				userType=2;
			}
			ModelAndView mv=new ModelAndView();
			mv.addObject("userId", loger);//ClientUtil.getCurrentUser().getUserId()
			mv.addObject("userType", userType);
			return mv;
		}
		
		@ResponseBody
		@RequestMapping(method={RequestMethod.POST}, value="updateInfo.spr")
		public HashMap<String,String> UpdateInfoToDb(HttpServletRequest  request)
		{
			String json=request.getParameter("infos");
			boolean flag=this.service.updateAllInfos(json,ClientUtil.getCurrentUser().getUserId());
			HashMap<String,String> resultMap=new HashMap<String,String>();
			if(flag){
				resultMap.put("success", "true");
				resultMap.put("message", "數據上傳成功");
			}else{
				resultMap.put("success", "false");
				resultMap.put("message", "數據上傳失敗");
			}
			return resultMap;
		}
}


