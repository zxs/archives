package com.foxconn.gds.sce.melp.roomRecord.service;


import java.util.List;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface ExamineesRecordService extends CrudService<Examinees>{
	List<Examinees> Query_ExamineesByRoomid(Examinees examinees);
	int UpdateExaminees(List<Examinees> examinees);
}
