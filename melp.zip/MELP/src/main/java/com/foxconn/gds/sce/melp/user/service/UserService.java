package com.foxconn.gds.sce.melp.user.service;

import java.io.IOException;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

/**
  * User: ronvargas
 * Date: Feb 10, 2009
 */
public interface UserService extends CrudService<User> {

    /**
     * get user object by user ID, equivalent to Read function
     *
     * @param userId
     * @return
     */
    User getUser(final String userId);

    /**
     * creates User entity
     *
     * @param user
     */
    void create(final User user);

    /**
     * Retrieves a user identified by the specified username
     *
     * @param username username
     * @return A user
     */
    //TODO: by  organization? return colection 'cause username is not uniq ?? 
    User getUserByUsername(final String username);

    /**
     * Retrieves a user identified by the specified id from sif
     *
     * @param sifRefId username
     * @return A user
     */
    User getUserBySifRefId(final String sifRefId);

    /**
     * * Returns true if the user is deleted
     *
     * @param userId id from the user
     * @return deleted status
     */
    boolean isUserDeleted(String userId);

    /**
     * This is to set the delete field to true or false.
     *
     * @param userId id from the user to modify
     * @param delete deleted status
     * @return true if successful
     */
    boolean changeDeletedFlag(String userId, boolean delete);
    

    /**
     * * Returns true if the user is deleted
     *
     * @param userId id from the user
     * @param old Password from the user
     * @param new Password from the user
     * @return change status
     */
/*    boolean updatePassword(String userId,String oldPassword,String newPassword);*/
    
    
    DataTableReturn listForDT(DataTable dataTable,String roomid,String classId);
    
    boolean importUsers(MultipartFile userFile) throws IOException;

    /**
     * Reset User Password
     * @param uid
     * @return
     */
	boolean resetPwd(Map<String, String> params);

	boolean markDeleted(String[] ids);

	boolean hasUserExist(String userId);

	boolean saveOrUpdate(Map<String, String> params);

	
	/*判斷用戶工號是否已存在*/
	boolean isUserExist(String p_id);
}
