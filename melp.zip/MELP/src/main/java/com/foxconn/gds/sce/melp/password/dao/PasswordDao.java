package com.foxconn.gds.sce.melp.password.dao;

//import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface PasswordDao extends GenericDao<User, String> {

	
	 
	public String getUserPasswordByUserName(String userName);
	
//	public bool getUpdataUserPassword(String userName,String password);


	public String getUserIdByUserName(String userName);

	public boolean getUpdatePassword(String id, String newPassword);

	

}
