package com.foxconn.gds.sce.melp.role.service.impl;

import com.foxconn.gds.sce.melp.model.PermissionType;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.role.dao.RolePermissionDao;
import com.foxconn.gds.sce.melp.role.service.RolePermissionService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Service(value = "rolePermissionService")
public class RolePermissionServiceImpl extends
		CrudServiceImpl<RolePermission, RolePermissionDao> implements
		RolePermissionService {

	@Autowired
	public void setRolePermissionDao(RolePermissionDao rolePermissionDao) {
		this.daoSupport = rolePermissionDao;
	}

	public void init() {
		if (this.daoSupport == null) {
			String msg = "%s property must be set";
			throw new IllegalStateException(String.format(msg,
					"rolePermissionDao"));
		}
	}

	/**
	 * Returns a role permission for a specific role
	 * 
	 * @param roleId
	 * @param permissionType
	 * @return
	 */
	@Transactional(readOnly = true)
	public RolePermission getRolePermission(String roleId,
			PermissionType permissionType) {
		return daoSupport.getRolePermission(roleId, permissionType);
	}
	
	
	
	

}
