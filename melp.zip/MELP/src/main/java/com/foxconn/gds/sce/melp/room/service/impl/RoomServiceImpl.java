package com.foxconn.gds.sce.melp.room.service.impl;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import net.sf.ehcache.constructs.web.ResponseUtil;


import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.room.dao.RoomDao;
import com.foxconn.gds.sce.melp.room.service.RoomService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import freemarker.core.ReturnInstruction.Return;

@Service(value = "roomService")
public class RoomServiceImpl extends CrudServiceImpl<ExamRoom, RoomDao> implements RoomService {

	@Autowired
	public void setIbRoomDao (RoomDao ibroomDao) {
		this.daoSupport=ibroomDao;
	}

	@Transactional
	public void InsertRoom(ExamRoom roominfo){
	    this.daoSupport.InsertRoom(roominfo);
	} 
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")	
    public DataTableReturn ListAllRoom(DataTable dt,int roletype)
    {
		DataTableReturn dtr = new DataTableReturn();
	    int skipResults = dt.getDisplayStart();
	    int maxResults = dt.getDisplayLength();
	    Map params = new HashMap();
	    String username = SecurityUtils.getCurrentUser().getUserId();
	    params.put(DataTable.SEARCH, dt.getSearch());
	    if(roletype!=0)
	        params.put("DT_USER",username.toUpperCase());
	    else
	    	params.put("DT_USER","");
	    for( SortInfo sInfo : dt.getSortInfo() ) {
		params.put( DataTable.ORDER_COLUMN_SORT, 
				sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
	    }
	    PaginatedResult<ExamRoom> _listRoom=daoSupport.ListAllRoom(params, skipResults, maxResults);
	    dtr.setAaData(_listRoom.getResult());
		dtr.setiTotalDisplayRecords(_listRoom.getTotalResults());
		dtr.setiTotalRecords(_listRoom.getTotalResults());
		dtr.setsEcho(dt.getEcho());
	    return dtr;
    }
	
	@Transactional
	public Boolean UpdateRoom(ExamRoom examRoom)
	{
		return daoSupport.UpdateRoom(examRoom)==1?true:false;
	}
	
	@Transactional(readOnly = true)
	public ExamRoom QueryRoomByPara(ExamRoom examRoom)
	{
		return daoSupport.QueryRoomByPara(examRoom);
	}
	
	@Transactional
	public void DeleteRoom(List<ExamRoom> listexamRoom) {
	    daoSupport.DeleteRoom(listexamRoom);
	} 
	
	@Transactional(readOnly = true)
	public String GetMaxRoomID() throws Exception {
		String _reStr="";
		try {
			_reStr=daoSupport.GetMaxRoomID();
		} catch (Exception e) {
			throw e;
		}
		return _reStr;
	}
	
	@Transactional
	public void UpdateSync(List<ExamRoom> listexamRoom)
	{
		 daoSupport.UpdateSync(listexamRoom);
	}
	
	@Transactional
	public void InsertExaminees(List<Examinees> examinees)
	{
		this.daoSupport.InsertExaminees(examinees);
	}
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")	
    public DataTableReturn ListAllExaminees(DataTable dt,String roomid)
    {
		DataTableReturn dtr = new DataTableReturn();
	    int skipResults = dt.getDisplayStart();
	    int maxResults = dt.getDisplayLength();
	    Map params = new HashMap();
	    params.put(DataTable.SEARCH, dt.getSearch());
	    params.put("DT_ROOMID",roomid);
	    for( SortInfo sInfo : dt.getSortInfo() ) {
		params.put( DataTable.ORDER_COLUMN_SORT, 
				sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
	    }
	    PaginatedResult<Examinees> _list=daoSupport.ListExamineesByRoom(params, skipResults, maxResults);
	    dtr.setAaData(_list.getResult());
		dtr.setiTotalDisplayRecords(_list.getTotalResults());
		dtr.setiTotalRecords(_list.getTotalResults());
		dtr.setsEcho(dt.getEcho());
	    return dtr;
    }
	
	@Transactional
	public void DelPerFromRoom(List<Examinees> listExaminees) {
	    daoSupport.DelPerFromRoom(listExaminees);
	} 
	
	@Transactional(readOnly = true)
    public List<Examinees> exportRoomPerson(String roomid)
    {  
	 List<Examinees> _list=new LinkedList<Examinees>();
	  try {
			_list= daoSupport.GetExamineeForExp(roomid);
        } catch (Exception e) {
            e.printStackTrace();
        }
	    return _list;
    }
}
