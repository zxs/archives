package com.foxconn.gds.sce.melp.fMyExam.dao.ibatis;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.fMyExam.dao.MyExamDao;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionAndOption;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value = "ibMyExamDao")
public class IbMyExamDao extends GenericDaoIbatisImpl<VO_ExamRoom, String>
		implements MyExamDao {

	@Autowired
	public IbMyExamDao(SqlMapClient sqlMapClient) {
		super(VO_ExamRoom.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<VO_ExamRoom> listMyExam(String empNo) {
		return (List<VO_ExamRoom>) getSqlMapClientTemplate().queryForList(
				"listMyExamByEmpNo", empNo);
	}

	public boolean updateExamInfo(ExamInfo examInfo) {
		try {
			getSqlMapClientTemplate().update("updateUserExamInfo", examInfo);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public PaperInfo getPaperInfo(String paperId) {
		return (PaperInfo) getSqlMapClientTemplate().queryForObject(
				"fMyExam.getPaperInfo", paperId);
	}

	public List<QuestionAndOption> getQuestionAndOptions(Map paperParameter) {
		return (List<QuestionAndOption>) getSqlMapClientTemplate()
				.queryForList("fMyExam.getPaperQues", paperParameter);
	}

	public boolean insertPaperDetail(PaperDetail paperDetail) {
		try {
			getSqlMapClientTemplate().insert("fMyExam.insPaperDetail",
					paperDetail);
			return true;
		} catch (Exception e) {
			return false;
		}

	}

	public boolean insertQuestionDetail(QuestionDetail questionDetail) {
		try {
			getSqlMapClientTemplate().insert("fMyExam.insQuestionDetail",
					questionDetail);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean insertOptionDetail(OptionDetail optionDetail) {
		try {
			getSqlMapClientTemplate().insert("fMyExam.insOptionDetail",
					optionDetail);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public boolean insertExamResult(ExamResults examResult) {
		
		try {
			getSqlMapClientTemplate().insert("fMyExam.insExamResult",examResult);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public void insertAllQuestionDetail(final List<QuestionDetail> questionDetail) {
		this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();
				for (int i = 0; i < questionDetail.size(); i++) {
					executor.insert("insertVarMailTabData",
							questionDetail.get(i));
				}
				executor.executeBatch();
				return null;
			}
		});
	}

}