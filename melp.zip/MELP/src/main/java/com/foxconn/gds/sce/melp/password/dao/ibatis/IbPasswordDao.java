package com.foxconn.gds.sce.melp.password.dao.ibatis;

import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.password.dao.PasswordDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
//import com.foxconn.gds.sce.melp.user.*;

@Repository(value="ibPasswordDao")
public class IbPasswordDao extends GenericDaoIbatisImpl<User, String> implements PasswordDao{
//	public IbPasswordDao(Class<User> type) {
//		super(type);
//		// TODO Auto-generated constructor stub
//	}
	@Autowired
    public IbPasswordDao(SqlMapClient sqlMapClient) {
		super(User.class);
		setSqlMapClient(sqlMapClient);
	}
	public String getUserPasswordByUserName(String username){
		String userPsd;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("username", username);		
			userPsd = (String) getSqlMapClientTemplate().queryForObject("query_user_username",username);
			
			 
		}catch(Exception e){
		//	System.out.println("query_user_username error!");
			System.out.println(e.toString());
			return null;
		}		
		//System.out.println(userPsd);
		return userPsd;
	}
	
	public String getUserIdByUserName(String username){
		String userId;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("username", username);		
			userId = (String) getSqlMapClientTemplate().queryForObject("query_user_userid",username);
			
			 
		}catch(Exception e){
		//	System.out.println("query_user_username error!");
			System.out.println(e.toString());
			return null;
		}		
		//System.out.println(userPsd);
		return userId;
	}
	
	public boolean getUpdatePassword(String id,String newPassword){
		boolean flag=false;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("id", id);
			hs.put("newPassword", newPassword);	
			getSqlMapClientTemplate().update("updateUserPassword",hs);
			flag=true;
		}catch(Exception e){
			System.out.println(e.toString());
			flag=false;
		}		
		return flag;
	}
	 
}
