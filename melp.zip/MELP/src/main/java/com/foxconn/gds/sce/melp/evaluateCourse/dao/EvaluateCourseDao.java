package com.foxconn.gds.sce.melp.evaluateCourse.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface EvaluateCourseDao extends GenericDao<Questionnaires, String>{
	public List<Questionnaires> showQuestionnaires_P(String courseID,String courseCreator);
	public Boolean updateEvRecord(String questionId,String option,String classID,String courseID,String empNo);
	public int getEvType(String courseID);
	public String getCourseCreator(String courseID);
	public Boolean insertEvRecord(String classID,String courseID,String empNo);
}
