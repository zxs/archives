package com.foxconn.gds.sce.melp.QuestionnaireStatistics.service.impl;



import java.util.HashMap;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import com.foxconn.gds.sce.melp.QuestionnaireStatistics.dao.QuestionnaireStatisticsDao;
import com.foxconn.gds.sce.melp.QuestionnaireStatistics.service.QuestionnaireStatisticsService;

import com.foxconn.gds.sce.melp.model.QuestionnaireStatistics;
@Service(value = "QuestionnaireStatisticsService")
public class QuestionnaireStatisticsServiceImpl extends CrudServiceImpl<QuestionnaireStatistics, QuestionnaireStatisticsDao> implements QuestionnaireStatisticsService{
	@Autowired
	public void setIbQuestionnaireStatisticsDao(QuestionnaireStatisticsDao questionnaireStatisticsDao) {
		this.daoSupport = questionnaireStatisticsDao;
	}
public List<QuestionnaireStatistics> showQuestionnaireStatistics_S(HashMap hashMap){

		return (List<QuestionnaireStatistics>) daoSupport.showQuestionnaireStatistics_S(hashMap);
		
	}
public List<QuestionnaireStatistics> showQuestionnaireStatistics_P(HashMap hashMap){

	return (List<QuestionnaireStatistics>) daoSupport.showQuestionnaireStatistics_P(hashMap);
	
}

	
}


