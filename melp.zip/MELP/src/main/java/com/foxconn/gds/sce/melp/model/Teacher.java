package com.foxconn.gds.sce.melp.model;
import java.util.Date;

public class Teacher extends BasicEntity {
	private  Integer TEACHER_TYPE;
	private  Integer TEACHER_LEVEL;
	private  String EMP_NO;
	private  String EMP_NAME;
	private  String DEPT_NAME;
	private  String PHONE_NO;
	private  String TEL_NO;
	private  String E_MAIL;
	private  String INTRODUCTION;
	private  Date CREATE_DATE;
	private  String CREATE_USER;
	private  Date MODIFY_DATE;
	private  String MODIFY_USER;
	private  String IS_ENABLE;
	private  String TEACHER_TYPE_NAME;
	private  String TEACHER_LEVEL_NAME;
	
	public Integer getTEACHER_TYPE() {
		return TEACHER_TYPE;
	}
	public void setTEACHER_TYPE(Integer TEACHER_TYPE) {
		this.TEACHER_TYPE = TEACHER_TYPE;
	}
	
	
	public Integer getTEACHER_LEVEL() {
		return TEACHER_LEVEL;
	}
	public void setTEACHER_LEVEL(Integer TEACHER_LEVEL) {
		this.TEACHER_LEVEL = TEACHER_LEVEL;
	}
	
	public String getEMP_NO() {
		return EMP_NO;
	}
	public void setEMP_NO(String EMP_NO) {
		this.EMP_NO = EMP_NO;
	}
	
	
	public String getEMP_NAME() {
		return EMP_NAME;
	}
	public void setEMP_NAME(String EMP_NAME) {
		this.EMP_NAME = EMP_NAME;
	}
	
	
	
	public String getDEPT_NAME() {
		return DEPT_NAME;
	}
	public void setDEPT_NAME(String DEPT_NAME) {
		this.DEPT_NAME = DEPT_NAME;
	}
	
	public String getPHONE_NO() {
		return PHONE_NO;
	}
	public void setPHONE_NO(String PHONE_NO) {
		this.PHONE_NO = PHONE_NO;
	}
	
	
	public String getTEL_NO() {
		return TEL_NO;
	}
	public void setTEL_NO(String TEL_NO) {
		this.TEL_NO = TEL_NO;
	}
	
	
	public String getE_MAIL() {
		return E_MAIL;
	}
	public void setE_MAIL(String E_MAIL) {
		this.E_MAIL = E_MAIL;
	}
	
	public String getINTRODUCTION() {
		return INTRODUCTION;
	}
	public void setINTRODUCTION(String INTRODUCTION) {
		this.INTRODUCTION = INTRODUCTION;
	}
	
	
	public Date getCREATE_DATE() {
		return CREATE_DATE;
	}
	public void setCREATE_DATE(Date CREATE_DATE) {
		this.CREATE_DATE = CREATE_DATE;
	}
	
	
	public String getCREATE_USER() {
		return CREATE_USER;
	}
	public void setCREATE_USER(String CREATE_USER) {
		this.CREATE_USER = CREATE_USER;
	}
	
	public Date getMODIFY_DATE() {
		return MODIFY_DATE;
	}
	public void setMODIFY_DATE(Date MODIFY_DATE) {
		this.MODIFY_DATE = MODIFY_DATE;
	}
	
	
	public String getMODIFY_USER() {
		return MODIFY_USER;
	}
	public void setMODIFY_USER(String MODIFY_USER) {
		this.MODIFY_USER = MODIFY_USER;
	}
	
	
	public String getIS_ENABLE() {
		return IS_ENABLE;
	}
	public void setIS_ENABLE(String IS_ENABLE) {
		this.IS_ENABLE = IS_ENABLE;
	}
	
	public String getTEACHER_TYPE_NAME() {
		return TEACHER_TYPE_NAME;
	}
	public void setTEACHER_TYPE_NAME(String TEACHER_TYPE_NAME) {
		this.TEACHER_TYPE_NAME = TEACHER_TYPE_NAME;
	}
	
	public String getTEACHER_LEVEL_NAME() {
		return TEACHER_LEVEL_NAME;
	}
	public void setTEACHER_LEVEL_NAME(String TEACHER_LEVEL_NAME) {
		this.TEACHER_LEVEL_NAME = TEACHER_LEVEL_NAME;
	}
	
	
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
