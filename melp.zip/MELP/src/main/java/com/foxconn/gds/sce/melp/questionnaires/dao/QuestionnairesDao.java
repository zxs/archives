package com.foxconn.gds.sce.melp.questionnaires.dao;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface QuestionnairesDao extends GenericDao<Questionnaires, String>  {

	public List<Questionnaires> showQuestionnaires_P();
	/*public List<Questionnaires> showQuestionnaires_I();*/
	/**
	 * 批量新增評估項
	 *@author F3226075
	 *@date 2012-3-5 上午10:19:08
	 *@param evaluationItems
	 */
	/*public void deleteQuestionnaires();*/
	public void insertQuestionnaires(final List<Map> successList );
}
