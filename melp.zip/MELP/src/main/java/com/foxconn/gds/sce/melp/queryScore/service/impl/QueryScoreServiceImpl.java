package com.foxconn.gds.sce.melp.queryScore.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.model.VO_Front_ViewExam;
import com.foxconn.gds.sce.melp.queryScore.dao.QueryScoreDao;
import com.foxconn.gds.sce.melp.queryScore.service.QueryScoreService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value="queryScoreService")
public class QueryScoreServiceImpl extends CrudServiceImpl<VO_Front_ViewExam, QueryScoreDao> implements QueryScoreService{

	@Autowired
	public void setIbQueryScoreDao(QueryScoreDao queryScoreDao){
		this.daoSupport=queryScoreDao;
	}
		

	public List<VO_Front_ViewExam> QueryScoreRecoredServcie(VO_Front_ViewExam score,int userType) {
		// TODO Auto-generated method stub		
		return this.daoSupport.QueryScoreRecords(score,userType);
	}

	public VO_Front_ViewExam QueryScoreTitle(VO_Front_ViewExam score) {
		// TODO Auto-generated method stub 
		VO_Front_ViewExam exam=this.daoSupport.QueryScoreTitle(score);
//		exam.setStartTime(formateDate(exam.getStartTime()));
//		exam.setEndTime(formateDate(exam.getEndTime()));
		return exam;
	}
	
	
//	private Date formateDate(Date d)
//	{
//		  if(d==null){
//				return new Date();
//		  }
//		  SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd hh:mm");
//		  String dateStr = format.format(d);
//		  System.out.println("str Date:"+dateStr);
//		  Date date = null;
//		  try {
//			  date = format.parse(dateStr);
//		  } catch (ParseException e) {
//			  e.printStackTrace();
//		  }
//		  System.out.println("Date:"+date);
//		  return date;
//	}

	public List<VO_Front_ViewExam> QueryScoreContent(VO_Front_ViewExam exam) {
		// TODO Auto-generated method stub
		return this.daoSupport.QueryScoreContent(exam);
	}

}
