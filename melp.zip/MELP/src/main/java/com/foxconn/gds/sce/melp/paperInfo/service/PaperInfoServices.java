package com.foxconn.gds.sce.melp.paperInfo.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.PaperInfo;

/**
 * User: Jyl
* Date: 20111215
*/

public interface PaperInfoServices {
	
	// 查询考场信息(根据id 权限、考卷名称)
		public List<PaperInfo> queryPaperInfo(String papeName, String userId)  ;

		// 页面初始化 查询所有考场信息(根据id 权限)
		public List<PaperInfo> queryAllPaperInfo(String userId) ;

}
