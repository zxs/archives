package com.foxconn.gds.sce.melp.roomRecord_b.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.roomRecord_b.dao.roomRecord_bDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value = "ibroomRecord_bDao")
public class IbroomRecord_bDao extends GenericDaoIbatisImpl<ExamRoom, String>
		implements roomRecord_bDao {

	@Autowired
	public IbroomRecord_bDao(SqlMapClient sqlMapClient) {
		super(ExamRoom.class);
		setSqlMapClient(sqlMapClient);
	}

	public String create(ExamRoom newInstance) {
		// TODO Auto-generated method stub
		return null;
	}

	public ExamRoom read(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(ExamRoom transientObject) {
		// TODO Auto-generated method stub

	}

	public void delete(ExamRoom persistentObject) {
		// TODO Auto-generated method stub

	}

	public PaginatedResult<ExamRoom> listWithRole(Map parameters,
			int skipResults, int maxResults) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unchecked")
	public PaginatedResult<ExamRoom> list(Map parameters, int skipResults,
			int maxResults) {
		int page = skipResults / maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<ExamRoom> prExamRooms = new PaginatedResult<ExamRoom>(
				page, pageSize);
		List<ExamRoom> result = null;
		if (maxResults < 0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList(
					"roomRecord_b.list", parameters);
		} else {
			result = getSqlMapClientTemplate().queryForList(
					"roomRecord_b.list", parameters, skipResults, maxResults);
		}
		Integer count = (Integer) getSqlMapClientTemplate().queryForObject(
				"roomRecord_b.list_count", parameters);

		prExamRooms.setResult(result);
		prExamRooms.setTotalResults(count);

		return prExamRooms;

	}

}
