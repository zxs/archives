package com.foxconn.gds.sce.melp.roomRecord.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface RoomRecordService extends CrudService<ExamRoom> {
	List<ExamRoom> QueryAllBy(ExamRoom exRoom,int userType);
}
