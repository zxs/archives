package com.foxconn.gds.sce.melp.studyRecord_bk;

import java.awt.List;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.studyRecord_bk.service.StudyRecordService;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;

import com.foxconn.gds.sce.melp.user.UserController;

@Controller
@RequestMapping("/studyrecord_bk/**")
public class StudyRecordController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
    private StudyRecordService studyRecordSer;
    
    @Autowired
	public void setstudyRecordSer(StudyRecordService studyRecordSer) 
	{
		this.studyRecordSer = studyRecordSer;
	}
    
    
    
  //打開頁面
  	@RequestMapping(method=RequestMethod.GET, value="showList.spr")
      public ModelAndView showList(@RequestParam("iframe") String iframe) 
      {
  		return new ModelAndView("/studyRecord_bk/studyRecordList", "iframe", "true".equals(iframe)?"true":"false");
  	}
  	
  //查詢學習記錄列表
    @RequestMapping(method=RequestMethod.POST, value="findAllStudyRecord.spr")
	public @ResponseBody Object findAllStudyRecord(@RequestParam("_dt_json") String dtjson)
	{
		
		logger.info("String dtjson=" + dtjson);
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		
		String userid="";
		if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userid="";
		}
		else
		{
			userid=SecurityUtils.getCurrentUser().getUserId();
		}
		
		DataTableReturn tableReturn = this.studyRecordSer.selStudyRecord(dataTable, userid);
		return tableReturn;
		
	}
    
    /*導出*/
    @RequestMapping(method=RequestMethod.GET,value="exports.spr")
    public ModelAndView exports(HttpServletRequest request,HttpServletResponse response) throws IOException
	{
    	String searchString=java.net.URLDecoder.decode(request.getParameter("search"), "utf-8");
    	String userid="";
    	if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userid="";
		}
		else
		{
			userid=SecurityUtils.getCurrentUser().getUserId();
		}
    	
    	java.util.List<Map>  results=studyRecordSer.exports(userid, searchString);
    	try
    	{
    	switch (results.size()) {
		case 0:
			
			break;

		default:
			OutputStream os=response.getOutputStream();
			response.reset();
			String filename="studyRecord.xls";
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-Disposition", "attachment;filename="+ new String(filename.getBytes(), "ISO8859-1"));
            HSSFWorkbook wb = new HSSFWorkbook();
		    HSSFSheet sheet = wb.createSheet("學習記錄列表");
		    HSSFRow  row=sheet.createRow((int)0);
		    HSSFCellStyle cellStyle=wb.createCellStyle();
		    sheet.setColumnWidth(0, (short)2);
		    cellStyle.setVerticalAlignment(HSSFCellStyle.ALIGN_CENTER);
		    cellStyle.setAlignment(HSSFCellStyle.ALIGN_CENTER);
		    
		    HSSFFont font=wb.createFont();
		    font.setColor(HSSFFont.COLOR_RED);
		    font.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
		    cellStyle.setFont(font);
		    
		    HSSFCell cell=row.createCell((int)1);
		    cell.setCellValue("課程編號");cell.setCellStyle(cellStyle);
		    cell=row.createCell(2);
		    cell.setCellValue("班級名稱");cell.setCellStyle(cellStyle);
		    cell=row.createCell(3);
		    cell.setCellValue("課程名稱");cell.setCellStyle(cellStyle);
		    cell=row.createCell(4);
		    cell.setCellValue("課程時長(分鐘)");cell.setCellStyle(cellStyle);
		    cell=row.createCell(5);
		    cell.setCellValue("工號");cell.setCellStyle(cellStyle);
		    cell=row.createCell(6);
		    cell.setCellValue("姓名");cell.setCellStyle(cellStyle);
		    cell=row.createCell(7);
		    cell.setCellValue("學習開始時間");cell.setCellStyle(cellStyle);
		    cell=row.createCell(8);
		    cell.setCellValue("學習結束時間");cell.setCellStyle(cellStyle);
		    cell=row.createCell(9);
		    cell.setCellValue("學習時長(分鐘)");cell.setCellStyle(cellStyle);
		    for(int i=1;i<=results.size();i++)
		    {
		    	HSSFRow _row=sheet.createRow((int)i);
		    	_row.createCell(1).setCellValue(results.get(i-1).get("CLASS_NO").toString());
		    	_row.createCell(2).setCellValue(results.get(i-1).get("CLASS_NAME").toString());
		    	_row.createCell(3).setCellValue(results.get(i-1).get("COURSE_NAME").toString());
		    	_row.createCell(4).setCellValue(results.get(i-1).get("COURSE_HOUR").toString());
		    	_row.createCell(5).setCellValue(results.get(i-1).get("EMP_NO").toString());
		    	_row.createCell(6).setCellValue(results.get(i-1).get("USERNAME").toString());
		    	_row.createCell(7).setCellValue(results.get(i-1).get("STUDY_START_TIME").toString());
		    	_row.createCell(8).setCellValue(results.get(i-1).get("STUDY_END_TIME").toString());
		    	_row.createCell(9).setCellValue(results.get(i-1).get("STUDY_HOUR").toString());
		    }
		    wb.write(os);
			os.close();
			break;
		}
    	}
    	catch (Exception e) {
			// TODO: handle exception
    		
		}
    	//return new ModelAndView();
    	return new ModelAndView("/studyRecord_bk/teacherExports");
    			
	}
    
}
