package com.foxconn.gds.sce.melp.roomRecord_b.service;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface roomRecord_bService extends CrudService<ExamRoom> {
	DataTableReturn listForDT(DataTable dataTable,int userType);
}
