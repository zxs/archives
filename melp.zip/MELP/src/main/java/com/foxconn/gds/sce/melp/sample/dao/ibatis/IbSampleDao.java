package com.foxconn.gds.sce.melp.sample.dao.ibatis;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.sample.dao.SampleDao;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value="ibSampleDao")
@Qualifier("ib")
public class IbSampleDao
extends GenericDaoIbatisImpl<User, String> 
implements SampleDao {

    private static Log log = LogFactory.getLog(ClientUtil.class);
	
	@Autowired
    public IbSampleDao(SqlMapClient sqlMapClient) {
		super(User.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<User> listByNull() {
		
		return null;
	}

	public User listBySifRefId(String sifRefId) {
		// TODO Auto-generated method stub
		return null;
	}
	
    @SuppressWarnings("unchecked")
	public void batchUpdate(final String statementName, final List list) {
	       try {
	           if (list != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = list.size(); i < n; i++) {
	                         executor.update(statementName, list.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
	       } catch (Exception e) {
	           if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchUpdate error: id [" + statementName + "], parameterObject ["+ list + "].  Cause: "+ e.getMessage());
	           }
	       }
	 
	    }
    	@SuppressWarnings("unchecked")
	    public void batchInsert(final String statementName, final List list) {
	       try {
	           if (list != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = list.size(); i < n; i++) {
	                         executor.insert(statementName, list.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
	       } catch (Exception e) {
	           if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchInsert error: id [" + statementName + "], parameterObject ["+ list + "].  Cause: "+ e.getMessage());
	           }
	       }
	 
	    }
	    @SuppressWarnings("unchecked")
		public void batchDelete(final String statementName, final List list) {
	       try {
	           if (list != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = list.size(); i < n; i++) {
	                         executor.delete(statementName, list.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
	       } catch (Exception e) {
	           if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [" + statementName + "], parameterObject ["+ list + "].  Cause: "+ e.getMessage());
	           }
	       }
	 
	    }
}
