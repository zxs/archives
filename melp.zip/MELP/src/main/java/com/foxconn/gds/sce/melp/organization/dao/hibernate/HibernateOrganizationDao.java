package com.foxconn.gds.sce.melp.organization.dao.hibernate;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.organization.dao.OrganizationDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;

/**
 * @author: franco
 * Date: 30/01/2009
 * Time: 07:31:07 AM
 */
@Repository(value = "registerDao")
public class HibernateOrganizationDao extends GenericDaoHibernateImpl<Organization, String> implements OrganizationDao {

	@Autowired
    public HibernateOrganizationDao(SessionFactory sessionFactory) {
		super(Organization.class);
		setSessionFactory(sessionFactory);
	}
    

    @SuppressWarnings(value = "unchecked")
    public List<Organization> getRootOrganizations() {
        final Boolean isParentOrganization = false;
        String query = "from Organization o where o.isParentOrganization = ?";
        return getHibernateTemplate().find(query, isParentOrganization);
    }

    public Organization getUserOrganization(final String userId) {
        List<Organization> organizationList = (List<Organization>) 
        		getHibernateTemplate().find("select u.organization from User u where u.id = ?", userId);
        return uniqueResult(organizationList);
    }

//TODO: Review this method to see if it makes sense and is required. If not, remove it
//    public boolean isCustomUserIdAvailable(final String customUserId, final String organizationId) {
//        final String query = "select count(u) from User u where u.organization.id = :orgId and " +
//                "u.customUserId = :custId";
//        String count = (String )getHibernateTemplate().execute(new HibernateCallback() {
//            public Object doInHibernate(Session session) throws HibernateException, SQLException {
//                Query query = session.createQuery(query);
//                queryString.setParameter("orgId", organizationId);
//                queryString.setParameter("custId", customUserId);
//                return queryString.uniqueResult();
//            }
//        });
//        return (count == null || count <=0);
//    }

//TODO: Review this method to see if it makes sense and is required. If not, remove it (Organization name should be a
//TODO: required field

//    public boolean isOrganizationNameAvailable(final String organizationName, final String parentId) {
//        final String query = "select count(o) from Organization o where o.name = :orgaName and %s";
//        String count = (String )getHibernateTemplate().execute(new HibernateCallback() {
//            public Object doInHibernate(Session session) throws HibernateException, SQLException {
//                Object[] params;
//                Query queryString = session.createQuery(query);
//                if (parentId != null) {
//                    String.format( query, "o.parent.id = :parId" );
//                    queryString.setParameter("orgaName", organizationName);
//                    queryString.setParameter("parId", parentId.toString());
//                }
//                else {
//                    String.format( query,  "o.parent.id = null" );
//                    queryString.setParameter("orgaName", organizationName);
//                }
//                return query.uniqueResult();
//            }
//        });
//
//        return (count == null || count <= 0);
//
//    }

    /**
     * Returns a list containing all of the organizations
     * @return a list of Organization objects
     */
    @SuppressWarnings("unchecked")
     public List<Organization> getOrganizations(){
        String queryStr = "from Organization";
        return getHibernateTemplate().find(queryStr);
    }

    /**
     * Returns a list of organizations with the specified IDs
     * @param organizationIds a set of long IDs of the organizations to retrieve
     * @return a list of Organization objects
     */
    @SuppressWarnings("unchecked")
     public List<Organization> getOrganizations( Set<String> organizationIds ){
        final List<String> stringIds = new ArrayList<String>();
        for ( String uuid : organizationIds ) {
            stringIds.add( uuid.toString() );
        }
        if( stringIds.isEmpty() ){
            return new ArrayList<Organization>();
        }

        final String queryStr = "from Organization o where o.id in (:orgIds)";
        
        return getHibernateTemplate().executeFind( new HibernateCallback() {
            public Object doInHibernate( Session session ) throws HibernateException {
                Query queryString = session.createQuery( queryStr );
                queryString.setParameterList( "orgIds", stringIds );
                return queryString.list();
            }
        });
    }

    //TODO: Review this method to see if it makes sense and is required.
//    @SuppressWarnings(value = "unchecked")
//    public List<Organization> getOrganizationsWithLogo(){
//        String query = "from Organization o where o.logo is not null";
//        return getHibernateTemplate().find(query);
//    }

}
