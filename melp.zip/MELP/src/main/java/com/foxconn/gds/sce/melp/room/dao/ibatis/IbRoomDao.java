package com.foxconn.gds.sce.melp.room.dao.ibatis;

import java.sql.SQLException;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.room.dao.RoomDao;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value = "ibRoomDao")
public class IbRoomDao extends GenericDaoIbatisImpl<ExamRoom, String> implements RoomDao {
	private static Log log = LogFactory.getLog(ClientUtil.class);
	@Autowired
    public IbRoomDao(SqlMapClient sqlMapClient) {
		super(ExamRoom.class);
		setSqlMapClient(sqlMapClient);
	}
	
	public void InsertRoom(ExamRoom roominfo) {
		getSqlMapClientTemplate().insert("sql_insertroom",roominfo);
	} 
	
	@SuppressWarnings("unchecked")
	public PaginatedResult<ExamRoom> ListAllRoom(Map parameters, int skipResults, int maxResults)
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<ExamRoom> prPapers = new PaginatedResult<ExamRoom>(page, pageSize);
		List<ExamRoom> result=null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("select_all", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("select_all", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("select_count", parameters);
		prPapers.setResult(result);
		prPapers.setTotalResults(count);
		return prPapers;
	}
	
	public Integer UpdateRoom(ExamRoom examRoom) {
		Integer flag=1;
		try {
			flag=(Integer)getSqlMapClientTemplate().update("sql_updateroom", examRoom);
		} catch (Exception e) {
			flag=0;
		}
		return flag;
	}
	
	public ExamRoom QueryRoomByPara(ExamRoom examRoom) {
		return (ExamRoom)getSqlMapClientTemplate().queryForObject("sql_selByRoomID", examRoom);
	}
	
	@SuppressWarnings("unchecked")
	public void DeleteRoom(final List<ExamRoom> listexamRoom) 
	{
		try {
			if (listexamRoom != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = listexamRoom.size(); i < n; i++) {
	                         executor.update("sql_deleteroom", listexamRoom.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [sql_deleteroom], parameterObject ["+ listexamRoom + "].  Cause: "+ e.getMessage());
	           }
		}
	}
	
	public String GetMaxRoomID() throws Exception{
		String _reStr="";
		try {
			Map<String, Object> paramMap=new HashMap<String, Object>();
			paramMap.put("inroom", "");
			getSqlMapClientTemplate().queryForObject("pro_getMaxRoomID",paramMap);
			_reStr = paramMap.get("roomid").toString();
		} catch (Exception e) {
			throw e;
		}
		return _reStr;
	}  
	
	@SuppressWarnings("unchecked")
	public void UpdateSync(final List<ExamRoom> examRoom) {
	
		try {
			if (examRoom != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = examRoom.size(); i < n; i++) {
	                         executor.update("sql_updateSync", examRoom.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
			//.update("sql_updateSync", examRoom);
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [" + "sql_updateSync" + "], parameterObject ["+ examRoom + "].  Cause: "+ e.getMessage());
	           }
		}
		
	}
	
	@SuppressWarnings("unchecked")
	public void InsertExaminees(final List<Examinees> examinees) {
		try {
			if (examinees != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(final SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = examinees.size(); i < n; i++) {
	                         executor.insert("insert_examinees", examinees.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [insert_examinees], parameterObject ["+ examinees + "].  Cause: "+ e.getMessage());
	           }
		}
	}
	
	@SuppressWarnings("unchecked")
	public PaginatedResult<Examinees> ListExamineesByRoom(Map parameters, int skipResults, int maxResults)
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<Examinees> prlist= new PaginatedResult<Examinees>(page, pageSize);
		List<Examinees> result=null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("select_examineesBy", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("select_examineesBy", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("count_examineesBy", parameters);
		prlist.setResult(result);
		prlist.setTotalResults(count);
		return prlist;
	}
	
	@SuppressWarnings("unchecked")
	public void DelPerFromRoom(final List<Examinees> listExaminees) 
	{
		try {
			if (listExaminees != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = listExaminees.size(); i < n; i++) {
	                         executor.update("delete_examineesBy", listExaminees.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [delete_examineesBy], parameterObject ["+ listExaminees + "].  Cause: "+ e.getMessage());
	           }
		}
	}
	
	public List<Examinees> GetExamineeForExp(String roomid) {
		Map<String, String> _map=new HashMap<String, String>();
		_map.put("DT_ROOMID", roomid);
		List<Examinees> _list= (List<Examinees>)getSqlMapClientTemplate().queryForList("select_examineesBy",_map);
	    return _list;
	}
}
