package com.foxconn.gds.sce.melp.user.service.impl;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.user.dao.UserDao;
import com.foxconn.gds.sce.melp.user.service.UserService;

/**
 * @author ronvargas Date: Feb 10, 2009
 */
@Service(value = "userService")
@Transactional
public class UserServiceImpl extends CrudServiceImpl<User, UserDao> implements
		UserService {

	private final static Logger logger = LoggerFactory
			.getLogger(UserServiceImpl.class);

	@Autowired
	@Qualifier("hi")
	public void setUserDao(UserDao userDao) {
		this.daoSupport = userDao;
	}

	public void init() {
		if (this.daoSupport == null) {
			String msg = "%s property must be set";
			throw new IllegalStateException(String.format(msg, "userDao"));
		}
	}

	/**
	 * Retrieves a user identified by the specified user Id
	 * 
	 * @param userId
	 *            userId
	 * @return A user
	 */
	@Transactional(readOnly = true)
	public User getUser(final String userId) {
		return daoSupport.getUser(userId);
	}

	/**
	 * Set the timestamp on the new user
	 * 
	 * @param user
	 *            user
	 * @return A user
	 */

	public void create(User user) {
		user.setEntityCreationTimestamp(new Date());
		user.setEntityVersion(1);
		daoSupport.create(user);
	}

	/**
	 * Retrieves a user identified by the specified username
	 * 
	 * @param username
	 *            username
	 * @return A user
	 */
	@Transactional(readOnly = true)
	public User getUserByUsername(final String username) {
		return daoSupport.getUserByUsername(username);
	}

	/**
	 * Retrieves a user identified by the specified id from sif
	 * 
	 * @param sifRefId
	 *            username
	 * @return A user
	 */
	@Transactional(readOnly = true)
	public User getUserBySifRefId(final String sifRefId) {
		return daoSupport.getUserBySifRefId(sifRefId);
	}

	/**
	 * Returns true if the user is deleted
	 */
	@Transactional(readOnly = true)
	public boolean isUserDeleted(String userId) {
		User user = daoSupport.read(userId);
		return user.isDeleted();
	}

	/**
	 * This is to set the delete field to true or false.
	 */
	public boolean changeDeletedFlag(String userId, boolean delete) {
		User user = daoSupport.read(userId);
		user.setDeleted(delete);
		daoSupport.update(user);
		logger.debug("Deleted Flag Changed. Id: {}, Username: {}",
				user.getId(), user.getUsername());
		return true;
	}

	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")	
	public DataTableReturn listForDT(DataTable dt,String roomid,String classId) {
		DataTableReturn dtr = new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		params.put("DT_RoomID", roomid);
		params.put(DataTable.SEARCH, dt.getSearch());
		//added by Cube @120829
		params.put("DT_classId", classId);
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		PaginatedResult<User> users = ibUserDao.listWithRole( params, skipResults, maxResults);
		
		dtr.setAaData(users.getResult());
		dtr.setiTotalDisplayRecords(users.getTotalResults());
		dtr.setiTotalRecords(users.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

	private UserDao ibUserDao;

	@Autowired
	@Qualifier("ib")
	public void setIbUserDao(UserDao ibUserDao) {
		this.ibUserDao = ibUserDao;
	}

	@Transactional(readOnly=false)
	public boolean importUsers(MultipartFile userFile) throws IOException {
		List<Map> udrList = new ArrayList<Map>();
		/**
		 * Create a new instance for POIFSFileSystem class
		 */
		POIFSFileSystem fsFileSystem = new POIFSFileSystem(
				userFile.getInputStream());
		/*
		 * Create a new instance for HSSFWorkBook Class
		 */
		HSSFWorkbook workBook = new HSSFWorkbook(fsFileSystem);
		//如下取得第1個標籤頁中的內容
		HSSFSheet hssfSheet = workBook.getSheetAt(0);
		/**
		 * Iterate the rows and cells of the spreadsheet to get all the datas.
		 */
		Iterator rowIterator = hssfSheet.rowIterator();

		while (rowIterator.hasNext()) {
			HSSFRow hssfRow = (HSSFRow) rowIterator.next();
			Map udr = new HashMap();
			//略過表頭
			//===工號***姓名***部門名稱***角色ID(1=Administrator, 2=Examineer, 3=Examinee)===
			if( hssfRow.getRowNum() == 0 ) continue;
			
			//取表裡的內容
			Iterator iterator = hssfRow.cellIterator();
			List cellTempList = new ArrayList();
			while (iterator.hasNext()) {
				
				HSSFCell hssfCell = (HSSFCell) iterator.next();
				switch( hssfCell.getColumnIndex() ) {
				case 0:
					udr.put("USER_ID", hssfCell.getStringCellValue()); 
					udr.put("PASSWORD", SecurityUtils.EncryptMD5(hssfCell.getStringCellValue()));
					break;
				case 1:
					udr.put("USERNAME", hssfCell.getStringCellValue()); 
					break;
				case 2:
					udr.put("DEPT_NAME", hssfCell.getStringCellValue()); 
					break;
				case 3:
					HSSFDataFormatter fter = new HSSFDataFormatter();
					String roleCode = fter.formatCellValue(hssfCell);
					udr.put("ROLE_NAME", Role.Name.getByCode(roleCode));
					break;
				}
			}// end column
			udrList.add(udr);
		} // end row
		ibUserDao.importUserWithDept(udrList);
		ibUserDao.importUserWithRole(udrList);
		
		return true;

	}



//	// 注入password
//	private PasswordDao _passwordDao;


//
//	
//// jyl 20111213 update password
//	/**
//	 * This is to change the user password to true or false.
//	 */
//	public boolean updatePassword(String userName, String oldPassword,
//			String newPassword) {
//		System.out.println(userName + "-" + oldPassword + "-" + newPassword);
//		boolean flag = false;
//		if (validatePassword(userName, oldPassword)) {
//			User user = new User();
//			user.setUsername(userName);
//			user.setPassword(newPassword);
//
//			String Id = this._passwordDao.getUserIdByUserName(userName);
//			user.setId(Id);
//
//			// System.out.println("id:"+user.getId());
//			// System.out.println("new Password"+user.getPassword());
//			// daoSupport.update(user);//更新密碼
//
//			if (this._passwordDao.getUpdatePassword(Id, newPassword)) {
//
//				logger.debug("Update Flag Changed. Id: {}, Username: {}",
//						user.getId(), user.getUsername());
//				// logger.debug 更新密碼日誌
//				System.out.println("更新密碼成功");
//				flag = true;
//			}else{
//				flag = false;
//			}
//
//		} else {
//			System.out.println("旧密碼Error!");
//			flag = false;
//		}
//		return flag;
//	}
//
//	// jyl 20111214 判斷輸入密碼是否正確
//	public boolean validatePassword(String username, String oldPassword) {
//		String userPsd = this._passwordDao.getUserPasswordByUserName(username);
//
//		// 判斷輸入密碼是否正確
//		if (userPsd.equalsIgnoreCase(oldPassword)) {
//			return true;
//		} else {
//			return false;
//		}
//	}
//
	@Transactional(readOnly=false)
	public boolean resetPwd(Map<String, String> params) {
		return ibUserDao.resetPwd(params);
	}

	@Transactional(readOnly=false)
	public boolean markDeleted(String[] ids) {
		List<String> lids = new ArrayList<String>();
		for(String id : ids){
			lids.add(id.split("_")[0]);// USERID_ROLEID
		}
		return ibUserDao.batchDeleted(lids);
		
	}	
//
//	
//	
	@Transactional(readOnly=true)
	public boolean hasUserExist(String userId) {
		User user = daoSupport.getUserByUserId(userId);
		if(user==null) {
			return false;
		} else {
			return true;
		}
	}

	@Transactional(readOnly=false)
	public boolean saveOrUpdate(Map<String, String> params) {
		String id = params.get("ID");
		if( !(id!=null && id.length()!=0)) {
			// insert
			List<Map> udrList = new ArrayList<Map>();
			udrList.add(params);
			ibUserDao.importUserWithDept( udrList );
			ibUserDao.importUserWithRole( udrList );
			
		} else {
			// update
			ibUserDao.updateUserWithDept( params );
			ibUserDao.updateUserWithRole( params );
		}
		return true;
	}
	/*判斷用戶工號是否已存在*/
	public boolean isUserExist(String p_id)
	{
		return ibUserDao.isUserExist(p_id);
	}
}
