package com.foxconn.gds.sce.melp.studyRecord_bk.service;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.StudyRecord;

import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface StudyRecordService extends CrudService<StudyRecord> {

	public DataTableReturn selStudyRecord(DataTable dt,String userid);
	
	public List<Map> exports(String userid,String searchString);
}
