package com.foxconn.gds.sce.melp.queryScore;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.foxconn.gds.sce.melp.model.VO_Front_ViewExam;
import com.foxconn.gds.sce.melp.queryScore.service.QueryScoreService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;

@Controller
@RequestMapping(value="/queryScore/**")
public class QueryScoreController {
	
	//private queryScoreService
	private QueryScoreService scoreService;	
	@Autowired
	public void setQueryScoreService(QueryScoreService queryScoreRecordService)
	{
		this.scoreService=queryScoreRecordService;
	}
	
	@RequestMapping(method={RequestMethod.GET}, value="queryScoreResult.spr")
	public ModelAndView ShowQueryScoreView()
	{
		return new ModelAndView();
	}
	
	
	@RequestMapping(method={RequestMethod.POST}, value="queryScoreRecords.spr")
	@ResponseBody
	public List<VO_Front_ViewExam> QueryScroeRecord(HttpServletRequest  request) throws Exception
	{
		String loger=SecurityUtils.getCurrentUser().getUserId();
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}else if(SecurityUtils.examineePlayedbyCurrentUser()){
			userType=2;
		}
		request.setCharacterEncoding("UTF-8");
		String papar_name=request.getParameter("paperName");
		VO_Front_ViewExam score=new VO_Front_ViewExam();
		score.setPaperName(papar_name);
		score.setLoger(loger);
		List<VO_Front_ViewExam> scores =this.scoreService.QueryScoreRecoredServcie(score,userType);
		return scores;
	}
	
	@RequestMapping(method={RequestMethod.GET}, value="ViewExam.spr")
	public ModelAndView ShowViewExamView(HttpServletRequest  request)
	{
		String paperDetailId=request.getParameter("paperDetailId");
		ModelAndView mav=new ModelAndView();
		mav.addObject("paperDetailIdKey", paperDetailId);
		return mav;
	}
	
	@ResponseBody
	@RequestMapping(method={RequestMethod.POST}, value="ViewExamResult.spr")
	public Map<String,Object> QueryViewExam(HttpServletRequest  request)
	{
		String paperDetailId=request.getParameter("paperDetailId");
		Map<String,Object> m=new HashMap<String,Object>();
		VO_Front_ViewExam examTitle=new VO_Front_ViewExam();
		examTitle.setPaperDetailId(paperDetailId);
		examTitle=this.scoreService.QueryScoreTitle(examTitle);
		List<VO_Front_ViewExam> content=this.scoreService.QueryScoreContent(examTitle);
		m.put("title", examTitle);
		m.put("content", content);
		return m;
	}
}
