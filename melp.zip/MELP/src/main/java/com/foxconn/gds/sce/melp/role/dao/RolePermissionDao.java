package com.foxconn.gds.sce.melp.role.dao;

import com.foxconn.gds.sce.melp.model.PermissionType;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface RolePermissionDao extends GenericDao<RolePermission, String>{
	
	/**
	 * Returns a role permission for a specific role
	 * @param roleId
	 * @param permissionType
	 * @return
	 */
	RolePermission getRolePermission(String roleId, PermissionType permissionType);
	
	

}
