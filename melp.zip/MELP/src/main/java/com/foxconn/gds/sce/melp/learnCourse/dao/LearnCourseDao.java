package com.foxconn.gds.sce.melp.learnCourse.dao;

import java.util.List;
import java.util.UUID;


import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface LearnCourseDao extends GenericDao<MyClassInfo, String> {
	List<MyClassInfo> listCourse(String empNo);
	public Boolean insertRecord(String empNo,String coursewareUrl,String uuid,String classNo);
	public Boolean updateRecord(String empNo,String coursewareUrl,String uuid,String classNo);
}
