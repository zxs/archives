package com.foxconn.gds.sce.melp.paper.dao;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface PaperDao  extends GenericDao<PaperInfo, String>
{
    public void InsertPaper(PaperInfo paperinfo);
    public PaginatedResult<PaperInfo> ListAllPaper(Map parameters, int skipResults, int maxResults);
    public void DeletePaper(List<PaperInfo>  paperInfo);
    public Integer UpdatePaper(PaperInfo paperinfo);
    public PaperInfo QueryPaperByPara(PaperInfo paperinfo);
    public PaperInfo QueryLibNumByID(PaperInfo paperinfo); 
    public Integer IsPaperExist(PaperInfo paperinfo);
    public PaperInfo QueryPaperExist(PaperInfo paperinfo);
    public List<PaperInfo> QueryPaperNameID(PaperInfo paperinfo); 
}
