package com.foxconn.gds.sce.melp.uploadScore.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
import com.foxconn.gds.sce.melp.uploadScore.dao.UploadScoreDao;
import com.foxconn.gds.sce.melp.uploadScore.service.UploadScoreService;

@Service(value="allService")
public class UploadScoreServiceImpl extends CrudServiceImpl<Examinees, UploadScoreDao> implements UploadScoreService {
	@Autowired
	public void setIbDao(UploadScoreDao uploadDao){
		this.daoSupport=uploadDao;
	}
	
	@Transactional
	public boolean updateAllInfos(String json,String loger){
		ObjectMapper mapper = new ObjectMapper();
		try{
			List<List<Map<String,Object>>> list = mapper.readValue(json,List.class);
			List<Examinees> inees = jsonStrToExaminees(list,loger);
			List<ExamResults> results = jsonStrToExamResults(list,loger);
			List<ExamInfo> infos = jsonStrToExamInfo(list,loger); //無SQL
			List<PaperDetail> paperDetail = jsonStrToPaperDetail(list,loger); //日期格式化
			List<QuestionDetail> quesDetail= jsonStrToQuestionDetail(list,loger);
			List<OptionDetail> optionDetail= jsonStrToOptionDetail(list,loger);
			return this.daoSupport.updateOrInsertInfos(inees, results, infos, paperDetail, quesDetail, optionDetail);
		}catch(Exception e){
			return false;
		}
	}
			
	//json轉化為Examinees實體
	private List<Examinees> jsonStrToExaminees(List<List<Map<String,Object>>> list,String loger) {
		List<Examinees> inees=new LinkedList<Examinees>();
		List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(0);
		for(int j=0;j<l.size();j++){
			Map<String,Object> m=(Map<String,Object>)l.get(j);
			Examinees nees=new Examinees();
			nees.setExamRoomId(m.get("examRoomId").toString());
			nees.setEmpNo(m.get("empNo").toString());
			nees.setStatus(m.get("status").toString());
			nees.setModifier(loger);
			inees.add(nees);
		}		
//		for(Examinees n:inees)
//		{
//			System.out.println("getExamRoomId:"+n.getExamRoomId());
//			System.out.println("getEmpNo:"+n.getEmpNo());
//			System.out.println("getStatus:"+n.getStatus());
//		}
		return inees;
		}
		
		//json轉化為ExamResults實體
	private List<ExamResults> jsonStrToExamResults(List<List<Map<String,Object>>> list,String loger)
		{			
			List<ExamResults> results=new LinkedList<ExamResults>();				
			List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(1);
			System.out.println(l);
			for(int j=0;j<l.size();j++){
				Map<String,Object> m=(Map<String,Object>)l.get(j);
				ExamResults res=new ExamResults();
				res.setId(m.get("Id").toString());
				res.setPaperId(m.get("paperId").toString());
				res.setExamRoomId(m.get("examRoomId").toString());
				res.setEmpNo(m.get("empNo").toString());
				res.setGetScore(strToBigDecimal(m.get("getScore").toString()));
				res.setCreator(m.get("creator").toString());
				results.add(res);
			}
					
//			for(ExamResults n:results)
//			{
//				System.out.println("Id:"+n.getId());
//				System.out.println("getPaperId:"+n.getPaperId());
//				System.out.println("getExamRoomId:"+n.getExamRoomId());
//				System.out.println("getEmpNo:"+n.getEmpNo());
//				System.out.println("getGetScore:"+n.getGetScore());
//			}
			return results;
		}
		
		
		//json轉化為ExamInfo實體
	private List<ExamInfo> jsonStrToExamInfo(List<List<Map<String,Object>>> list,String loger)
	{
		List<ExamInfo> infos=new LinkedList<ExamInfo>();				
		List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(2);
		for(int j=0;j<l.size();j++){
			Map<String,Object> m=(Map<String,Object>)l.get(j);
			ExamInfo info=new ExamInfo();
			info.setPaperId(m.get("paperId").toString());
			info.setExamRoomId(m.get("examRoomId").toString());
			info.setEmpNo(m.get("empNo").toString());
			info.setExamTimes(strToBigDecimal(m.get("examTimes").toString()));
			info.setAddTimes(strToBigDecimal(m.get("addTimes").toString()));
			info.setCreator(m.get("creator").toString());
			infos.add(info);
		}
				
//		for(ExamInfo n:infos)
//		{
//			System.out.println("getPaperId:"+n.getPaperId());
//			System.out.println("getExamRoomId:"+n.getExamRoomId());
//			System.out.println("getEmpNo:"+n.getEmpNo());
//			System.out.println("getEmamTimes:"+n.getExamTimes());
//			System.out.println("getAddTimes:"+n.getAddTimes());
//		}
		return infos;
	}
		
		//json轉化為PaperDetail實體
	private List<PaperDetail> jsonStrToPaperDetail(List<List<Map<String,Object>>> list,String loger)
	{
		System.out.println("paper detail here");
		List<PaperDetail> infos=new LinkedList<PaperDetail>();				
		List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(3);
		for(int j=0;j<l.size();j++){
			Map<String,Object> m=(Map<String,Object>)l.get(j);
			System.out.println("m here"+m);
			PaperDetail info=new PaperDetail();
			System.out.println("id "+m.get("Id").toString());
			info.setId(m.get("Id").toString());
			info.setExamRoomId(m.get("examRoomId").toString());
			info.setPaperId(m.get("paperId").toString());
			info.setEmpNo(m.get("empNo").toString());
			info.setStartTime(stringToDate(m.get("startTime").toString())); //stringToDate(m.get("startTime").toString())
			info.setEndTime(stringToDate(m.get("endTime").toString())); //stringToDate(m.get("endTime").toString())
			info.setCreator(m.get("creator").toString());
			infos.add(info);
		}
				
//		for(PaperDetail n:infos)
//		{
//			System.out.println("getExamRoomId:"+n.getExamRoomId());
//			System.out.println("getEmpNo:"+n.getEmpNo());
//			System.out.println("getId:"+n.getId());
//			System.out.println("getPaperId:"+n.getPaperId());
//			System.out.println("getStartTime:"+n.getStartTime());
//			System.out.println("getEndTime:"+n.getEndTime());
//		}
		return infos;
	}
	
	public  Date stringToDate(String str) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = null;
		try {
			date = formatter.parse(str); 
		} catch (ParseException e) {
			e.printStackTrace();
		}										
		return date;
	}
		//json轉化為QuestionDetail實體
	private List<QuestionDetail> jsonStrToQuestionDetail(List<List<Map<String,Object>>> list,String loger)
	{
		List<QuestionDetail> infos=new LinkedList<QuestionDetail>();				
		List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(4);
		for(int j=0;j<l.size();j++){
			Map<String,Object> m=(Map<String,Object>)l.get(j);
			QuestionDetail info=new QuestionDetail();
			info.setPaperDetailId(m.get("paperDetailId").toString());
			info.setQuestionId(m.get("questionId").toString());
			info.setQuestionOrder(strToBigDecimal(m.get("questionOrder").toString()));
			info.setCreator(m.get("creator").toString());
			infos.add(info);
		}
				
//		for(QuestionDetail n:infos)
//		{
//			System.out.println("getPaperDetailId:"+n.getPaperDetailId());
//			System.out.println("getQuestionId:"+n.getQuestionId());
//			System.out.println("getQuestionOrder:"+n.getQuestionOrder());	
//		}
		return infos;
	}
	
	//json轉化為OptionDetail實體
	private List<OptionDetail> jsonStrToOptionDetail(List<List<Map<String,Object>>> list,String loger)
	{
		List<OptionDetail> infos=new LinkedList<OptionDetail>();				
		List<Map<String,Object>> l=(List<Map<String,Object>>)list.get(5);
		for(int j=0;j<l.size();j++){
			Map<String,Object> m=(Map<String,Object>)l.get(j);
			OptionDetail info=new OptionDetail();
			info.setPaperDetailId(m.get("paperDetailId").toString());
			info.setOptionId(m.get("optionId").toString());
			info.setOptionOrder(strToBigDecimal(m.get("optionOrder").toString()));
			info.setIsUserAnswer(m.get("isUserAnswer").toString());
			info.setCreator(m.get("creator").toString());
			infos.add(info);
		}
				
//		for(OptionDetail n:infos)
//		{
//			System.out.println("getPaperDetailId:"+n.getPaperDetailId());
//			System.out.println("getOptionId:"+n.getOptionId());
//			System.out.println("getOptionOrder:"+n.getOptionOrder());
//			System.out.println("getIsUserAnswer:"+n.getIsUserAnswer());
//		}
		return infos;
	}
					
			
	private BigDecimal strToBigDecimal(String decimal){
			Long aa=Long.parseLong(decimal);
			BigDecimal b=BigDecimal.valueOf(aa); 
			return b;
		}


	}
