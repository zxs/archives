package com.foxconn.gds.sce.melp.queryScore.service;

import java.util.List;
import com.foxconn.gds.sce.melp.model.VO_Front_ViewExam;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface QueryScoreService extends CrudService<VO_Front_ViewExam>{
	List<VO_Front_ViewExam> QueryScoreRecoredServcie(VO_Front_ViewExam score,int userType);
	VO_Front_ViewExam QueryScoreTitle(VO_Front_ViewExam score);
	List<VO_Front_ViewExam> QueryScoreContent(VO_Front_ViewExam exam);
}
