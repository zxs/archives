package com.foxconn.gds.sce.melp.model;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * iCalendar (RFC 2445) representation of a Calendar in this LMS product.  All attribute names and constructs are
 * named according to the RFC specification.
 *
 * <p>This class contains all required RFC 2445 attributes and any optional attributes this LMS finds
 * useful.  More attributes may be added over time, but any new additions should completely adhere
 * to the RFC specification.
 *
 * @author Jeff Wysong
 * @author Les Hazlewood
 */
@Entity
@Table(name = "melp_calendar")
public class SimsCalendar extends BasicEntity{

    public boolean onEquals(Object obj) {
        return false;
    }

    public int onHashCode() {
        return 0;
    }

    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    public Object clone() {
        try {             
            return (SimsCalendar) super.clone();
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }

}
