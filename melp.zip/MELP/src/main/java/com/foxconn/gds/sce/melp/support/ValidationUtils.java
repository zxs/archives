package com.foxconn.gds.sce.melp.support;

/**
 * User: Anai
 * Date: Feb 16, 2009
 * Time: 8:27:16 AM
 */

public class ValidationUtils {

    public static boolean isEmpty( String value ) {
        return !org.springframework.util.StringUtils.hasText( value );
    }

}
