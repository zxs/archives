package com.foxconn.gds.sce.melp.model;

public class QuestionAndOption extends BasicEntity{
	private String questionType;
	private String questionTitle;
	private String id;
	private String questionId;
	private String isRightAnswer;
	private String optionContent;

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public String getQuestionTitle() {
		return questionTitle;
	}

	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getQuestionId() {
		return questionId;
	}

	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}

	public String getIsRightAnswer() {
		return isRightAnswer;
	}

	public void setIsRightAnswer(String isRightAnswer) {
		this.isRightAnswer = isRightAnswer;
	}

	public String getOptionContent() {
		return optionContent;
	}

	public void setOptionContent(String optionContent) {
		this.optionContent = optionContent;
	}

	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
