package com.foxconn.gds.sce.melp.examRoom.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.examRoom.dao.examRoomDao;
import com.foxconn.gds.sce.melp.examRoom.service.examRoomService;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

/**
 * @author River Date: 20121217
 */
@Service(value = "examRoomService")
@Transactional
public class ImplexamRoomService extends
	CrudServiceImpl<ExamRoom, examRoomDao> implements examRoomService{

		private examRoomDao _examRoomDao;

		@Autowired
		public void setexamRoom(examRoomDao examRoomDao) {
			this._examRoomDao = examRoomDao;
		}
		// 查询補考名單設置(根据id 权限、考卷名称)
		public List<ExamRoom> queryExamRoom(String paper_ID, String exam_Room_ID) {				
			List<ExamRoom> listExamRoom=this._examRoomDao.getqueryExamRoom(paper_ID,exam_Room_ID);			
			
			return listExamRoom;
		}
		
		//查詢補考設置的名單  <!-- by姓名、工号+考卷ID、场次编号  20111217  River -->
		public List<ExamRoom> queryEmpnoandName(String paper_ID, String exam_Room_ID,String emp_Name,String emp_No) {				
			List<ExamRoom> listExamRoom=this._examRoomDao.getqueryEmpnoandName(paper_ID,exam_Room_ID,emp_Name,emp_No);			
			
			return listExamRoom;
		}
		
		//補考增减設置  <!-- by工号+補考次數  20111220  River -->
		public List<ExamRoom> updateandquery(String paper_ID, String exam_Room_ID,String strExamAdd,String emp_No) {				
			List<ExamRoom> listExamRoom=this._examRoomDao.getUpdateAndQuery(paper_ID,exam_Room_ID,strExamAdd,emp_No);			
			
			return listExamRoom;
		}
		
		
}
