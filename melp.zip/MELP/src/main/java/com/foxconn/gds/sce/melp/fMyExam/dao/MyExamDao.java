package com.foxconn.gds.sce.melp.fMyExam.dao;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionAndOption;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface MyExamDao extends GenericDao<VO_ExamRoom, String> {
	List<VO_ExamRoom> listMyExam(String empNo);
	boolean updateExamInfo(ExamInfo examInfo);
	PaperInfo getPaperInfo(String paperId);
	List<QuestionAndOption> getQuestionAndOptions(Map paperParameter);
	boolean insertPaperDetail(PaperDetail paperDetail);
	boolean insertQuestionDetail(QuestionDetail questionDetail);
	boolean insertOptionDetail(OptionDetail optionDetail);
	boolean insertExamResult(ExamResults examResult);
}
