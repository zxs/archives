package com.foxconn.gds.sce.melp.roomRecord_b.dao;

import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface roomRecord_bDao extends GenericDao<ExamRoom, String> {
	PaginatedResult<ExamRoom> list(Map parameters, int skipResults, int maxResults);
}
