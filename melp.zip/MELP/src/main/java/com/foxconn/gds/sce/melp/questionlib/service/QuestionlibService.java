package com.foxconn.gds.sce.melp.questionlib.service;

import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;

import org.apache.poi.hssf.record.formula.functions.Value;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.VO_QuestonOption;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface QuestionlibService extends CrudService<QuestionLib> {

	public List<QuestionLib> findAllByCondition(QuestionLib questionLib);

	public DataTableReturn findAllQuestionLib(DataTable dt,String userid);
	
	//查詢所有試題
	public DataTableReturn findAllQuestion(DataTable dt,String libid);
	
	public boolean insertLib(QuestionLib questionLib);

	public boolean updateLib(QuestionLib questionLib);

	public List<Question> findAllQustionByLibID(Question question);

	// 新增試題
	public boolean insertQuestionAndOptions(Question question,
			QuestionOptions questionOptions);

	// /根據試題ID查出所有選項
	public List<VO_QuestonOption> findByQuestionID(
			VO_QuestonOption vo_QuestonOption);
	
	public boolean EditQuestion(Question question,QuestionOptions questionOptions,String questionID);
	
	
	public  boolean  delOptionByID(QuestionOptions questionOptions);
	
	public boolean delTitle(Question question);
	
	//刪除試題庫
	public  boolean delQuestionLib(QuestionLib questionLib);
	
	//導入試題
	public Map<String,Object> importQuestion(MultipartFile file,String user_id,String libID) throws Exception;
	
	//hssfSheet:傳入源sheet,返回新的HSSFWorkbook
	public HSSFWorkbook  createNewExcel(HSSFSheet  sourseSheet);
	
	//
	/* 給sheet新增一列
	 * sourseSheet:源sheet
	 * 返回：新的Sheet
	 * */
	public HSSFSheet createNewCol(HSSFSheet  sourseSheet);
	
	//驗證數據
	public Map validates(HSSFRow hssfRow);
	
	 //查詢試題庫是否有試卷
	public Object findPaperByLibid(String libid);
	
	//導出
	public  List<Map> exports(String libid,String searchString);
	
	//導出模板
	public void exportTemplet(FileOutputStream os);
}
