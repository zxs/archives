package com.foxconn.gds.sce.melp.sample.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.sample.dao.SampleDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;

@Repository(value="hiSampleDao")
@Qualifier("hi")
public class HiSampleDao 
extends GenericDaoHibernateImpl<User, String>
implements SampleDao {

	@Autowired
    public HiSampleDao(SessionFactory sessionFactory) {
		super(User.class);
		setSessionFactory(sessionFactory);
	}

	
	public List<User> listByNull() {
		// TODO Auto-generated method stub
		return null;
	}

	public User listBySifRefId(String sifRefId) {
		// TODO Auto-generated method stub
		return null;
	}

}
