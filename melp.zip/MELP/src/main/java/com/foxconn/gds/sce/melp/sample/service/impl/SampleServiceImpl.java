package com.foxconn.gds.sce.melp.sample.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.person.dao.PersonDao;
import com.foxconn.gds.sce.melp.sample.dao.SampleDao;
import com.foxconn.gds.sce.melp.sample.service.SampleService;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value="sampleService")
public class SampleServiceImpl extends CrudServiceImpl<User, SampleDao> implements SampleService {

    @Autowired
    public void setSampleDao(SampleDao sampleDao) {
        this.daoSupport = sampleDao;
    }
    
    private SampleDao hiSampleDao;
    private SampleDao ibSampleDao;
    
    @Autowired
    @Qualifier("hi")
    public void setHiSampleDao(SampleDao hiSampleDao) {
		this.hiSampleDao = hiSampleDao;
	}

    @Autowired
    @Qualifier("ib")    
	public void setIbSampleDao(SampleDao ibSampleDao) {
		this.ibSampleDao = ibSampleDao;
	}

	
    
    @Transactional
	public User addUser(User nUser) {
		// TODO Auto-generated method stub
		return null;
	}

    @Transactional(readOnly=true )    
	public List<User> listAllUser() {
		// TODO Auto-generated method stub
		return null;
	}
    

}
