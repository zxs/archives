package com.foxconn.gds.sce.melp.examRoom.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamRoom;

public interface examRoomService {

	List<ExamRoom> queryExamRoom(String paper_ID, String exam_Room_ID);

	List<ExamRoom> queryEmpnoandName(String paper_ID, String exam_Room_ID,
			String emp_Name, String emp_No);

	List<ExamRoom> updateandquery(String paper_ID, String exam_Room_ID,
			String strExamAdd, String emp_No);

}
