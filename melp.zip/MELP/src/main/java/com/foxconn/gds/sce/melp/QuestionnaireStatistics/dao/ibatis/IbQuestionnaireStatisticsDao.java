package com.foxconn.gds.sce.melp.QuestionnaireStatistics.dao.ibatis;


import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.QuestionnaireStatistics.dao.QuestionnaireStatisticsDao;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.QuestionnaireStatistics;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value = "IbQuestionnaireStatisticsDao")
public class IbQuestionnaireStatisticsDao extends GenericDaoIbatisImpl<QuestionnaireStatistics,String>implements QuestionnaireStatisticsDao{
	@Autowired
	public IbQuestionnaireStatisticsDao(SqlMapClient sqlMapClient) {
		super(QuestionnaireStatistics.class);
		setSqlMapClient(sqlMapClient);
	}
	public List<QuestionnaireStatistics> showQuestionnaireStatistics_S(HashMap hashMap){
		return (List<QuestionnaireStatistics>) getSqlMapClientTemplate().queryForList(
				"statisticscontent_S",hashMap);
	}
		public List<QuestionnaireStatistics> showQuestionnaireStatistics_P(HashMap hashMap){
			return (List<QuestionnaireStatistics>) getSqlMapClientTemplate().queryForList(
					"statisticscontent_P",hashMap);
		}
		
}
