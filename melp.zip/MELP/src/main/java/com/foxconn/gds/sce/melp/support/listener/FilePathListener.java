package com.foxconn.gds.sce.melp.support.listener;

import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FilePathListener implements ServletContextListener {
	
	private static Logger log = LoggerFactory.getLogger(FilePathListener.class);
	
	public static String templateFilePath; 
	public static String uploadFilePath;

	//@Override
	public void contextDestroyed(ServletContextEvent e) {
		// TODO Auto-generated method stub

	}

	//@Override
	public void contextInitialized(ServletContextEvent e) {
		ServletContext servletContext = e.getServletContext();
		templateFilePath = servletContext.getInitParameter("templateFilePath");
		uploadFilePath = servletContext.getInitParameter("uploadFilePath");
	
		log.debug("##　Config templateFilePath=" + templateFilePath);
		log.debug("## Config uploadFilePath=" + uploadFilePath);
		
		log.debug("##　System Properties:");
		for (Map.Entry<Object, Object> property : System.getProperties().entrySet()) {
			log.debug(property.getKey() + "\t:\t" + property.getValue());
		}
		log.debug("## System Environment:");
		for (Map.Entry<String, String> envar : System.getenv().entrySet()) {
			log.debug(envar.getKey() + "\t:\t" + envar.getValue());
		}

		log.debug("## Get Resource Path :");
		for(Object temvpath : servletContext.getResourcePaths("/files/")) {
			log.debug(temvpath  + "\t:\t" + servletContext.getRealPath((String)temvpath) );
		}
		
		if( !(templateFilePath!=null && templateFilePath.length()>0) ) {
			templateFilePath = servletContext.getRealPath("/files/");
		}
		
		if( !(uploadFilePath!=null && uploadFilePath.length()>0) ) {
			uploadFilePath = servletContext.getRealPath("/files/upload/");
		}
		
		log.debug("## Final templateFilePath=" + templateFilePath);
		log.debug("## Final uploadFilePath=" + uploadFilePath);		
	}

}
