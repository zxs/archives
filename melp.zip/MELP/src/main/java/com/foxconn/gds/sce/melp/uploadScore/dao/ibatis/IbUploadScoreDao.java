package com.foxconn.gds.sce.melp.uploadScore.dao.ibatis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.OptionDetail;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionDetail;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.uploadScore.dao.UploadScoreDao;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value="ibDao")
public class IbUploadScoreDao extends GenericDaoIbatisImpl<Examinees, String> implements UploadScoreDao {
	@Autowired
	public IbUploadScoreDao(SqlMapClient sqlMapClient) {
		super(Examinees.class);
		setSqlMapClient(sqlMapClient);
	}
		
	
	@SuppressWarnings("unchecked")
	public boolean updateOrInsertInfos(final List<Examinees> inees,
			final List<ExamResults> results,final List<ExamInfo> info,
			final List<PaperDetail> paperDetail,final List<QuestionDetail> quesDetail,
			final List<OptionDetail> optionDetail) 
		{
		try{
			this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	              public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	            	  try{
//	            	 List<HashMap<String,String>> existsMap=new LinkedList<HashMap<String,String>>();
//	            	 HashMap<String,String> map=new HashMap<String,String>();;
	                 executor.startBatch();
	                 for (int i = 0;i< info.size();  i++) {
//	                	 HashMap<String,String> inMap=new HashMap<String,String>();
//	                	 inMap.put("paperId", info.get(i).getPaperId());
//	                	 System.out.println("paperid:"+info.get(i).getPaperId());
//	                	 Integer maxTime = (Integer)executor.queryForObject("select_count_InLIne_examInfo",inMap);//("updateUserExamInfo",info.get(i));
//	                 	 System.out.println("maxTime:"+maxTime);
//	                 	inMap.put("paperId", info.get(i).getPaperId());
//	                 	 if(info.get(i).getExamTimes().intValue() > maxTime){
//	                		 System.out.println("excute:add");
//	                 		 map.put("examRoomId", info.get(i).getExamRoomId());
//	                 		 map.put("empNo", info.get(i).getEmpNo());
//	                 		 existsMap.add(map);
//	                 		 continue;
//	                 	 }else{
//	                 		 System.out.println("excute:updateOffLineExamInfo");
//	                 		 executor.queryForObject("updateOffLineExamInfo", info.get(i));
//	                 	 }
	                	 System.out.println("result: *******info here");
	                 	 executor.queryForObject("updateOffLineExamInfo", info.get(i));
	                 }
	                 //boolean isContinue=false;
	                 for (int i = 0;i < inees.size();  i++) {
//	                	 String examRoomId=inees.get(i).getExamRoomId();
//	                	 String empNo=inees.get(i).getEmpNo();
//	                	 for(HashMap<String,String> m:existsMap)
//	                	 {
//	                		 String tmpExamRoomId=m.get("examRoomId");
//	                		 String tmpEmpNo=m.get("empNo");
//	                		 if(tmpExamRoomId.equals(examRoomId)&& tmpEmpNo.equals(empNo)){
//	                			 isContinue=true;//continue;
//	                			 break;
//	                		 }else{
//	                			 isContinue=false;//executor.update("update_examinees", inees.get(i));
//	                		 }
//	                	 }
//	                	 if(!isContinue){
//	                		 System.out.println("excute:update_examinees"+inees.get(i).getModifier()+"  "+inees.get(i).getExamRoomId()+"  "+inees.get(i).getEmpNo()+" "+inees.get(i).getStatus());
//	                     	 executor.update("update_examinees", inees.get(i));
//	                	 }
	                	 System.out.println("result: *******inees here");
	                	 executor.update("update_examinees", inees.get(i));
	                 }
//	                 isContinue=false;
	                 for (int i = 0;i< results.size(); i++) {
//	                	 String examRoomId=results.get(i).getExamRoomId();
//	                	 String empNo=results.get(i).getEmpNo();
//	                	 for(HashMap<String,String> m:existsMap)
//	                	 {
//	                		 String tmpExamRoomId=m.get("examRoomId");
//	                		 String tmpEmpNo=m.get("empNo");
//	                		 if(tmpExamRoomId.equals(examRoomId)&& tmpEmpNo.equals(empNo)){
//	                			 isContinue=true;//continue;
//	                			 break;
//	                		 }else{
//	                			 isContinue=false;//executor.update("update_examinees", inees.get(i));
//	                		 }
//	                	 }
//	                	 if(!isContinue){
//	                		 System.out.println("result:"+results.get(i)+"  *******excuteResult here");
//	                		 executor.insert("fMyExam.insExamResult", results.get(i));
//	                	 }	
	                	 //System.out.println("result:"+results.get(i)+"  *******excuteResult here"); updateOffLineExamResult
	                	 System.out.println("result: *******results here");
	                	 //executor.insert("fMyExam.insExamResult", results.get(i));
	                	 executor.queryForObject("updateOffLineExamResults", results.get(i));
	                 }
//	                 isContinue=false;
//	                 List<HashMap<String,String>> tmpPerDetailMap=new LinkedList<HashMap<String,String>>();
//	                 HashMap<String,String> tmpPerPepaer=new HashMap<String,String>();
	                 
	                 for (int i = 0; i < paperDetail.size(); i++) {
//	                	 String examRoomId=paperDetail.get(i).getExamRoomId();
//	                	 String empNo=paperDetail.get(i).getEmpNo();
//	                	 System.out.println("tmpExamRoomId:"+examRoomId+"  ****empNo"+empNo);
//	                	 for(HashMap<String,String> m:existsMap)
//	                	 {
//	                		 String tmpExamRoomId=m.get("examRoomId");
//	                		 String tmpEmpNo=m.get("empNo");
//	                		 System.out.println("tmpExamRoomId:"+tmpExamRoomId+"  ****tmpEmpNo"+tmpEmpNo);
//	                		 if(tmpExamRoomId.equals(examRoomId)&& tmpEmpNo.equals(empNo)){	                    			 
//	                			 tmpPerPepaer.put("paperDetailId", paperDetail.get(i).getId());
//	                			 tmpPerDetailMap.add(tmpPerPepaer);
//	                			 isContinue=true;//continue;
//	                			 break;
//	                		 }else{
//	                			 isContinue=false;//executor.update("update_examinees", inees.get(i));
//	                		 }
//	                	 }
//	                	 if(!isContinue){
//	                		 System.out.println("result:"+paperDetail.get(i)+"  *******paperDetail here");
//	                		 executor.insert("fMyExam.insPaperDetail", paperDetail.get(i));	
//	                	 }
	                	 //System.out.println("result:"+paperDetail.get(i)+"  *******paperDetail here");
	                	 System.out.println("result: *******paperDetail here");
	                	 executor.insert("fMyExam.insPaperDetail", paperDetail.get(i));	
	                 }
//	                 isContinue=false;
	                 for (int i = 0;i < quesDetail.size();  i++) {
//	                	 String paperDetailId=quesDetail.get(i).getPaperDetailId();
//	                	 for(HashMap<String,String> m:tmpPerDetailMap)
//	                	 {
//	                		 String tmpPaperDetailId=m.get("paperDetailId");
//	                		 if(paperDetailId.equals(tmpPaperDetailId)){
//	                			 isContinue=true;//continue;
//	                			 break;
//	                		 }else{
//	                			 isContinue=false;//executor.update("update_examinees", inees.get(i));
//	                		 }
//	                	 }
//	                	 if(!isContinue){
//	                		 executor.insert("fMyExam.insQuestionDetail", quesDetail.get(i));
//	                	 }
	                	 System.out.println("result: *******quesDetail here");
	                	 executor.insert("fMyExam.insQuestionDetail", quesDetail.get(i));
	                 }
//	                 isContinue=false;
	                 for (int i = 0; i< optionDetail.size(); i++) {
//	                	 String paperDetailId=optionDetail.get(i).getPaperDetailId();
//	                	 for(HashMap<String,String> m:tmpPerDetailMap)
//	                	 {
//	                		 String tmpPaperDetailId=m.get("paperDetailId");
//	                		 if(paperDetailId.equals(tmpPaperDetailId)){
//	                			 isContinue=true;//continue;
//	                			 break;
//	                		 }else{
//	                			 isContinue=false;//executor.update("update_examinees", inees.get(i));
//	                		 }
//	                	 }
//	                	 if(!isContinue){
//	                		 executor.insert("fMyExam.insOptionDetail", optionDetail.get(i));
//	                	 }
	                	 System.out.println("result: *******optionDetail here");
	                     executor.insert("fMyExam.insOptionDetail", optionDetail.get(i));
	                 }
	                 executor.executeBatch();
	                 return true;
	            	  }catch(Exception e){
	            		  e.printStackTrace();
	            		 return false;
	            	  }
	              }
	          });
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		return true;
	}
}
