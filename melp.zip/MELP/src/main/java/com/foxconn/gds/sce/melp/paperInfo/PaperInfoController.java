package com.foxconn.gds.sce.melp.paperInfo;

import java.io.IOException;
import java.util.List;

import com.foxconn.gds.sce.melp.model.PaperInfo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.paperInfo.service.PaperInfoService;
import com.foxconn.gds.sce.melp.user.service.UserService;


@Controller
@RequestMapping(value="/paperInfo/**")//映射路径
public class PaperInfoController {
	
	private UserService user_Srv;
	private PaperInfoService paper_Srv;

	@Autowired//注入
	public void setUserService(UserService userSrv) {
		this.user_Srv = userSrv;
	}
	
	@Autowired//注入
	public void setImplpaperInfoService(PaperInfoService paperSrv) {
		this.paper_Srv=paperSrv;
	}
	
	@RequestMapping(method = RequestMethod.GET, value ="paperInfoquerypage.spr")//映射路径
	public ModelAndView updatePasswordPage(){
	
		return new ModelAndView("paperInfo/paperInfo");//指向文件
	}
	/*
	//查询考场信息(根据考卷名称、id  权限 )
	@RequestMapping(method = RequestMethod.GET, value ="paperInfoqueryproc.spr")
	@ResponseBody
	public  List<PaperInfo> paperInfoqueryproc(HttpServletRequest request) 
	{	
		System.out.println("进入方法paperInfoQuery,查询考场信息(根据考卷名称、id  权限)");	
		//String user_id = request.getParameter("userId");	//获取用户id
		String pape_Name = request.getParameter("paperName");	//获取考卷名称
		
		//String papeName="qq";	
		String userId="F3221433";
		
		//根据考卷名称-->查询考场资料	
		if(pape_Name.trim()!="")
		{		
		//如果考卷名不为空，则查询目标考场资料
		List<PaperInfo> listPaperInfo=paper_Srv.queryPaperInfo(pape_Name,userId);
		System.out.println("目标考场:"+ listPaperInfo.size());	
		return listPaperInfo;
		}
		else{
			//如果考卷名为空，则查询权限范围内的所有考场资料
			List<PaperInfo> listPaperInfo=paper_Srv.queryAllPaperInfo(userId);
			System.out.println( "范围考场:"+ listPaperInfo.size());	
			return listPaperInfo;
			
		}
	}
	
	
	//页面初始化 查询所有考场信息(根据id  权限)
	public List<PaperInfo> paperAllInfoQuery(HttpServletRequest request,HttpServletResponse response) 
	{	
		System.out.println("进入方法paperInfoQuery,查询考场信息(id  权限)");				
		String userId="F3221433";
		List<PaperInfo> listAllPaperInfo=paper_Srv.queryAllPaperInfo(userId);
		return listAllPaperInfo;
	}
*/
	
		//查询考场信息(根据考卷名称、id  权限 )  River  20111215
		@RequestMapping(value ="paperInfoqueryproc.spr")
		public String paperInfoqueryproc2(Model model,HttpServletRequest request) 
		{	
			String pape_Name=null;
			List<PaperInfo> listPaperInfo;			
			System.out.println("进入方法paperInfoQuery2,查询考场信息(根据考卷名称、id  权限)");	
			//String user_id = request.getParameter("userId");	//获取用户id
		//	String pape_Name = request.getParameter("paperName");	//获取考卷名称

			if(!(request.getParameter("paperName")==null))
			{
				pape_Name = request.getParameter("paperName");
			}			
			//String papeName="qq";	
			String userId="F3219814";			
			//根据考卷名称-->查询考场资料	
			if(pape_Name!=null)
			{		
				System.out.println("queryPaperInfo");
			//如果考卷名不为空，则查询目标考场资料					
			 listPaperInfo=paper_Srv.queryPaperInfo(pape_Name,userId);
			//System.out.println("目标考场00:"+ listPaperInfo.get(0).getPaperName());	
			}
			else{
				System.out.println("queryAllPaperInfo");
				//如果考卷名为空，则查询权限范围内的所有考场资料
				 listPaperInfo=paper_Srv.queryAllPaperInfo(userId);
				System.out.println( "范围考场:"+ listPaperInfo.size());	
			}	
			model.addAttribute("llistPaperInfo", listPaperInfo);			
			return "paperInfo/paperInfo" ;//指向文件			
		}	
}
