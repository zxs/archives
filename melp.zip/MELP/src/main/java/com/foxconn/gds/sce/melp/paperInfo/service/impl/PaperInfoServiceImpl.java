package com.foxconn.gds.sce.melp.paperInfo.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
//import java.util.Date;
import java.util.List;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.foxconn.gds.sce.melp.model.PaperInfo;
//import com.foxconn.gds.sce.melp.model.ExamRoom;
//import com.foxconn.gds.sce.melp.model.ExamInfo;
//import com.foxconn.gds.sce.melp.password.dao.PasswordDao;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
//import com.foxconn.gds.sce.melp.user.service.UserService;
//import com.foxconn.gds.sce.melp.support.service.CrudService;
//import com.foxconn.gds.sce.melp.user.dao.UserDao;
import com.foxconn.gds.sce.melp.paperInfo.dao.PaperInfoDao;
import com.foxconn.gds.sce.melp.paperInfo.service.PaperInfoService;

/**
 * @author River Date: 20121215
 */
@Service(value = "paperInfoService")
@Transactional
public class PaperInfoServiceImpl extends
		CrudServiceImpl<PaperInfo, PaperInfoDao> implements PaperInfoService {

	private PaperInfoDao _paperInfoDao;

	@Autowired
	public void setPaperInfoDao(PaperInfoDao PaperInfoDao) {
		this._paperInfoDao = PaperInfoDao;
	}

	// 查询考场信息(根据id 权限、考卷名称) River  20111215
	public List<PaperInfo> queryPaperInfo(String papeName, String userId) {

		// String Id = this._passwordDao.getqueryPaperInfo(papeName);			
		System.out.println("进入方法queryPaperInfo,工号:"+userId+"_考卷名："+papeName);	
		List<PaperInfo> listPaperInfo = this._paperInfoDao.getQueryPaperInfo(
				papeName, userId);
		return listPaperInfo;

	}

	// 页面初始化 查询所有考场信息(根据id 权限) River  20111215
	public List<PaperInfo> queryAllPaperInfo(String userId) {
		
		System.out.println("进入方法queryAllPaperInfo,工号:"+userId);	
		List<PaperInfo> listAllPaperInfo = this._paperInfoDao
				.getAllQueryPaperInfo(userId);
		return listAllPaperInfo;
	}
}
