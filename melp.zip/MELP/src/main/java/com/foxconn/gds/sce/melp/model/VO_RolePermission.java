package com.foxconn.gds.sce.melp.model;

public class VO_RolePermission extends RolePermission {
	private String roleId;

	public String getRoleId() {
		return roleId;
	}


	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
}
