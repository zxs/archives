package com.foxconn.gds.sce.melp.support.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import com.visural.common.web.client.Platform;
import com.visural.common.web.client.UserAgent;
import com.visural.common.web.client.WebClient;

/**
 * Servlet Filter implementation class MyClientFilter
 */
public class MyClientFilter implements Filter {

	public static final String ATTR_CLIENT = "_CLIENT_";
	public static final String FROM_PC = "PC";
	public static final String FROM_MID = "MID";

	/**
	 * Default constructor.
	 */
	public MyClientFilter() {
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		WebClient client = WebClient.detect(req);
		if (client.getPlatform().equals(Platform.IOS)
				|| client.getUserAgent().equals(UserAgent.SAFARI)
				|| client.getUserAgent().equals(UserAgent.CHROME)
				|| client.getPlatform().equals(Platform.ANDROID)
				) {
			req.setAttribute(ATTR_CLIENT, FROM_MID);
		} else {
			req.setAttribute(ATTR_CLIENT, FROM_PC);
		}

		// pass the request along the filter chain
		chain.doFilter(request, response);
	}

}
