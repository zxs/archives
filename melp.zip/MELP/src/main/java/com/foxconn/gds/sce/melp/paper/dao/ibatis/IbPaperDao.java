package com.foxconn.gds.sce.melp.paper.dao.ibatis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.paper.dao.PaperDao;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

import freemarker.core.ReturnInstruction.Return;

@Repository(value = "ibPaperDao")
public class IbPaperDao extends GenericDaoIbatisImpl<PaperInfo, String> implements PaperDao {
	private static Log log = LogFactory.getLog(ClientUtil.class);
	@Autowired
    public IbPaperDao(SqlMapClient sqlMapClient) {
		super(PaperInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	public void InsertPaper(PaperInfo paperinfo) {
		getSqlMapClientTemplate().insert("sql_insert",paperinfo);
	}
	
	@SuppressWarnings("unchecked")
	public PaginatedResult<PaperInfo> ListAllPaper(Map parameters, int skipResults, int maxResults)
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<PaperInfo> prPapers = new PaginatedResult<PaperInfo>(page, pageSize);
		List<PaperInfo> result=null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("sql_queryAll", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("sql_queryAll", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("list_count", parameters);
		prPapers.setResult(result);
		prPapers.setTotalResults(count);
		return prPapers;
	}

	@SuppressWarnings("unchecked")
	public void DeletePaper(final List<PaperInfo>  paperInfo) 
	{
		try {
			if (paperInfo != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = paperInfo.size(); i < n; i++) {
	                         executor.update("sql_delete", paperInfo.get(i));
	                     }
	                     executor.executeBatch();
	                     return null;
	                  }
	              });
	           }
		} catch (Exception e) {
			if (log.isDebugEnabled()) {
	              e.printStackTrace();
	              log.debug("batchDelete error: id [sql_delete], parameterObject ["+ paperInfo + "].  Cause: "+ e.getMessage());
	           }
		}
	}

	public Integer UpdatePaper(PaperInfo paperinfo) {
		Integer flag=1;
		try {
			flag=(Integer)getSqlMapClientTemplate().update("sql_update", paperinfo);
		} catch (Exception e) {
			flag=0;
		}
		return flag;
	}
	
	public PaperInfo QueryPaperByPara(PaperInfo paperinfo) {
		return (PaperInfo)getSqlMapClientTemplate().queryForObject("sql_queryByParam", paperinfo);
	}
	
	public PaperInfo QueryLibNumByID(PaperInfo paperinfo) {
		return (PaperInfo)getSqlMapClientTemplate().queryForObject("sql_queryLibNumByID", paperinfo);
	}
	
	public Integer IsPaperExist(PaperInfo paperinfo)
	{
		Integer flag=-1;
		try {
			flag=(Integer)getSqlMapClientTemplate().queryForObject("papername_count", paperinfo);
		} catch (Exception e) {
			flag=-1;
		}
		return flag;
	}
	
	public PaperInfo QueryPaperExist(PaperInfo paperinfo)
	{
	   return (PaperInfo)getSqlMapClientTemplate().queryForObject("query_papernameexist", paperinfo);
	}
	
	@SuppressWarnings("unchecked")
	public List<PaperInfo> QueryPaperNameID(PaperInfo paperinfo) {
		return (List<PaperInfo>)getSqlMapClientTemplate().queryForList("query_paperNameList",paperinfo);
	}
	
}
