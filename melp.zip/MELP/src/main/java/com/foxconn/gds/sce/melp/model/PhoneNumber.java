package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.HashCodeBuilder;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.util.regex.Pattern;

/**
 * User: Anai
 * Date: Feb 16, 2009
 * Time: 8:39:02 AM
 */

@Entity
@Table(name = "melp_phone_number")
public class PhoneNumber extends BasicEntity{

    private static final String phoneChars = "[0-9\\(\\) -]{1,}";

    /** regexp pattern for valid United States phone numbers */
    public static final Pattern US_VALID_PATTERN = Pattern.compile( phoneChars );

    @Column(name="text")
    private String text;

    @Column(name="extension")
    private String extension;

    @Column(name="label")
    private String label;

    public PhoneNumber() {
        super();
    }

    public PhoneNumber( String text ) {
        super();
        setText( text );
    }

    public PhoneNumber( String text, String extension ) {
        this( text );
        setExtension( extension );
    }

    public PhoneNumber( String text, String extension, String label ) {
        this( text, extension );
        setLabel( label );
    }

    public String getText() {
        return text;
    }

    public void setText( String text ) {
        this.text = text;
    }

    public String getExtension() {
        return extension;
    }

    public void setExtension( String extension ) {
        this.extension = extension;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel( String label ) {
        this.label = label;
    }


    public boolean onEquals( Object obj ) {
        if ( obj instanceof PhoneNumber ) {
            PhoneNumber phone = (PhoneNumber)obj;
            return ( text != null ? text.equals( phone.getText() ) : phone.getText() == null ) &&
                   ( label != null ? label.equals( phone.getLabel() ) : phone.getLabel() == null ) &&
                   ( extension != null ? extension.equals( phone.getExtension() ) : phone.getExtension() == null );
        }
        return false;
    }


    public int onHashCode() {
        return new HashCodeBuilder()
        .append(getText())
        .append(getExtension())
        .append(getLabel()).toHashCode();
    }

    public StringBuffer toStringBuffer() {
        StringBuffer buffer = new StringBuffer();
        buffer.append(",text=").append( getText() );
        if ( getExtension() != null ) { buffer.append( ",extension=" ).append( getExtension() ); }
        if ( getLabel() != null ) { buffer.append( ",label=" ).append( getLabel() ); }
        return buffer;
    }

    @Override
    @SuppressWarnings( { "CloneDoesntDeclareCloneNotSupportedException" } )
    public Object clone() {
        try{
            PhoneNumber clone = (PhoneNumber)super.clone();
            clone.setText( getText() );
            clone.setExtension( getExtension() );
            clone.setLabel( getLabel() );
            return clone;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }
}
