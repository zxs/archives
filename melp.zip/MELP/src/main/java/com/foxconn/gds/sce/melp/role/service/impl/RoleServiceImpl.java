package com.foxconn.gds.sce.melp.role.service.impl;

import com.foxconn.gds.sce.melp.model.*;
import com.foxconn.gds.sce.melp.role.dao.RoleDao;
import com.foxconn.gds.sce.melp.role.service.RolePermissionService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * @author ronvargas
 * Date: Feb 12, 2009
 */
@Transactional
@Service(value = "RoleService")
public class RoleServiceImpl extends CrudServiceImpl<Role, RoleDao>
        implements com.foxconn.gds.sce.melp.role.service.RoleService {

    private final static Logger logger = LoggerFactory.getLogger(RoleServiceImpl.class);

    @Autowired
    private RolePermissionService rolePermissionService;

    @Autowired
    private RolePermissionService permissionService;

    public void setRolePermissionService(RolePermissionService rolePermissionService) {
        this.rolePermissionService = rolePermissionService;
    }

    @Autowired
    public void setRoleDao(RoleDao roleDao) {
        this.daoSupport = roleDao;
    }

    public void init() {
        if (this.daoSupport == null) {
            String msg = "%s property must be set";
            throw new IllegalStateException(String.format(msg, "roleDao"));
        }
    }

    /**
     * Retrieves a Role identified by the specified role Id
     *
     * @param roleId roleId
     * @return A role
     */
    @Transactional(readOnly = true)
    public Role getRole(final String roleId) {
        return daoSupport.getRole(roleId);
    }

    /**
     * Retrieves a Role list identified by the specified name (many roles can have the same name across organizations)
     *
     * @param name role name
     * @return A role list
     */
    @Transactional(readOnly = true)
    public List<Role> getRolesByName(final String name) {
        return daoSupport.getRolesByName(name);
    }

    /**
     * get Roles associated to this Organization object
     *
     * @param organization Organization
     * @return A role list
     */
    @Transactional(readOnly = true)
    public List<Role> getRolesByOrganization(final Organization organization) {
        return daoSupport.getRolesByOrganization(organization);
    }

    /**
     * get Roles associated to this Organization id
     *
     * @param organizationId Organization id
     * @return A role list
     */
    @Transactional(readOnly = true)
    public List<Role> getRolesByOrganizationId(final String organizationId) {
        return daoSupport.getRolesByOrganizationId(organizationId);
    }

    /**
     * get Roles associated to this Organization name
     *
     * @param organizationName Organization name
     * @return A role list
     */
    @Transactional(readOnly = true)
    public List<Role> getRolesByOrganizationName(final String organizationName) {
        return daoSupport.getRolesByOrganizationName(organizationName);
    }

    @Override
    public void create(Role role) {
        super.create(role);
        createDefaultRolePermissions(role);
    }

    @Override
    public void delete(Role role) {        
        Set<RolePermission> permissions = role.getPermissions();
        if (permissions != null) {
            for (RolePermission permission : permissions) {
                permissionService.delete(permission);
            }
        }
        super.delete(role);
    }

    /**
     * Creates default permissions for a role
     *
     * @param role
     */
    private void createDefaultRolePermissions(Role role) {
        Set<RolePermission> permissions = new HashSet();
//        List<PermissionType> permissionTypes = new ArrayList<PermissionType>(5);
//        permissionTypes.add(PermissionType.Home);
//        permissionTypes.add(PermissionType.Classroom);
//        permissionTypes.add(PermissionType.Registrar);
//        permissionTypes.add(PermissionType.RegistrarEnrollment);
//        permissionTypes.add(PermissionType.RegistrarUser);

        //this creates by default access to all permissions to any new role,
        // this could change when more permissions exist
        for(PermissionType permissionType : PermissionType.values()) {
            RolePermission rolePermission = new RolePermission(role, permissionType, AccessLevel.Access);
            rolePermissionService.create(rolePermission);
            permissions.add(rolePermission);
        }
        role.setPermissions(permissions);
    }

    /**
     * Returns true if the role is deleted
     */
    @Transactional(readOnly = true)
    public boolean isRoleDeleted(String roleId) {
        Role role = daoSupport.read(roleId);
        return role.isDeleted();
    }

    /**
     * Add here implementation details
     * <p/>
     * This is to set the delete field to true or false.
     */
    public boolean changeDeletedFlag(String roleId, boolean delete) {
        Role role = daoSupport.read(roleId);
        role.setDeleted(delete);
        daoSupport.update(role);
        logger.debug("Deleted Flag Changed. Id: {}, name: {}", role.getId(), role.getName());
        return true;
    }

}
