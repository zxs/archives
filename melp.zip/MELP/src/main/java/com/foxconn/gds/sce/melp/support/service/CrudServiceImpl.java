package com.foxconn.gds.sce.melp.support.service;

import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.BasicEntity;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

/**
 * @author franco
 */

public abstract class CrudServiceImpl<T extends BasicEntity, DAO extends GenericDao<T, String>> implements CrudService<T>{

    protected DAO daoSupport;

    @Transactional
    public void create(T entity) {
        daoSupport.create(entity);
    }
    @Transactional
    public void update(T entity) {
        daoSupport.update(entity);
    }
    @Transactional
    public void delete(T entity) {
        daoSupport.delete(entity);
    }
    @Transactional(readOnly=true)
    public T read(String entityId) {
        return daoSupport.read(entityId);
    }
}
