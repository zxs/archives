package com.foxconn.gds.sce.melp.roomRecord.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.roomRecord.dao.RoomRecordDao;
import com.foxconn.gds.sce.melp.roomRecord.service.RoomRecordService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;


@Service(value="roomRecordService")
public class RoomRecordServiceImpl extends CrudServiceImpl<ExamRoom, RoomRecordDao> implements RoomRecordService {

	@Autowired
	public void setIbroomRecordDao(RoomRecordDao roomRecordDao){
		this.daoSupport=roomRecordDao;
	}	
	public List<ExamRoom> QueryAllBy(ExamRoom exRoom,int userType) {
		// TODO Auto-generated method stub
		return this.daoSupport.QueryAllBy(exRoom,userType);
	}

}
