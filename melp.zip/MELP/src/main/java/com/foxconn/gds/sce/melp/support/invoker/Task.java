package com.foxconn.gds.sce.melp.support.invoker;

/**
 * @author: jperez
 */
public interface Task {

    void execute();

}
