package com.foxconn.gds.sce.melp.learnCourse.service.impl;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.learnCourse.dao.LearnCourseDao;
import com.foxconn.gds.sce.melp.learnCourse.service.LearnCourseService;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "learnCourseServer")
public class LearnCourseServiceImpl extends
		CrudServiceImpl<MyClassInfo, LearnCourseDao> implements
		LearnCourseService {

	@Autowired
	public void setIbLearnCourseDao(LearnCourseDao ibLearnCourseDao) {
		this.daoSupport = ibLearnCourseDao;
	}

	public List<MyClassInfo> listCourse(String empNo) {
		return daoSupport.listCourse(empNo);
	}

	@Transactional(readOnly = false)
	public Boolean insertRecord(String empNo, String coursewareUrl,String uuid,String classNo) {
		return daoSupport.insertRecord(empNo, coursewareUrl,uuid,classNo);
	}

	@Transactional(readOnly = false)
	public Boolean updateRecord(String empNo, String coursewareUrl,String uuid,String classNo) {
		return daoSupport.updateRecord(empNo, coursewareUrl,uuid,classNo);
	}
}
