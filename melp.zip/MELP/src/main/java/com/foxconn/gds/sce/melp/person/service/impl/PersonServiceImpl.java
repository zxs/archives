package com.foxconn.gds.sce.melp.person.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.Person;
import com.foxconn.gds.sce.melp.person.dao.PersonDao;
import com.foxconn.gds.sce.melp.person.service.PersonService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

/**
 * @author Edward
 */
@Transactional
@Service(value = "personService")
public class PersonServiceImpl extends CrudServiceImpl<Person, PersonDao> implements PersonService {

    private final static Logger logger = LoggerFactory.getLogger(PersonServiceImpl.class);


    @Autowired
    public void setPersonDao(PersonDao personDao) {
        this.daoSupport = personDao;
    }

//    @Autowired
//    ContactService contactService;

    /**
     * Init method
     */
    public void init() {
        if (this.daoSupport == null) {
            String msg = "%s property must be set";
            throw new IllegalStateException(String.format(msg, "personDao"));
        }
    }

    /**
     * Add here implementation details
     *
     * This is to set the delete field to true or false.
     *
     */
    @Transactional
    public boolean changeDeletedFlag(String personId, boolean delete) {
        Person person = daoSupport.read(personId);
        person.setDeleted(delete);
        daoSupport.update(person);
        logger.debug("Deleted Flag Changed. Id: {}, Number: {}", person.getId(), person.getFirstName());
        return true;
    }

    /**
     * Returns true if the person is deleted
     *
     */
    @Transactional (readOnly = true)
    public boolean isPersonDeleted(String personId) {
        Person person = daoSupport.read(personId);
        return person.isDeleted();
    }

      /**
     * This method returns a list of persons
     *
     *
     */
    @Transactional(readOnly = true)
    public List<Person> getPersons() {
        return daoSupport.getPersons();
    }

    /**
     * This method returns a person by id
     *
     *
     */
    @Transactional (readOnly = true)
    public Person getPerson(String personId){
        return daoSupport.getPerson(personId);
    }

//    /**
//     *  This method adds a contact to the user (person)
//     */
//    @Transactional (readOnly = false)
//    public boolean addContactToPerson(Person person, Contact contact) {
//        List<Contact> contacts = person.getContacts();
//        boolean toReturn;
//        if (contacts == null){
//            contacts = new ArrayList<Contact>();
//        }
//        toReturn = contacts.add(contact);
//        person.setContacts(contacts);
//        daoSupport.update(person);
//        return toReturn;
//    }
//
//    /**
//     * This method removes a contact from a person
//     */
//    @Transactional (readOnly = false)
//    public boolean removeContactFromPerson(Person person, Contact contact) {
//    	List<Contact> contacts = person.getContacts();
//        boolean toReturn = false;
//        contact.setPerson(null);
//        contactService.delete(contact);
//        logger.debug("Person Id: {}, Contact Id: {}", person.getId(), contact.getId());
//        if (contacts != null){
//            toReturn = contacts.remove(contact);
//            person.setContacts(contacts);
//            daoSupport.update(person);
//        }
//        return toReturn;
//    }
//
//    /**
//     * This method returns a list of contacts by person
//     */
//    @Transactional (readOnly = true)
//    public List<Contact> getContactsByPerson(String personId){
//        Person person = daoSupport.getPerson(personId);
//        return person.getContacts();
//    }
//
//
//    /**
//     * This method returns a contact of a person with the specified ID
//     * @param personId The ID of the person
//     * @param contactId The ID of the contact
//     * @return the Contact
//     */
//    @Transactional (readOnly = true)
//    public Contact getContactById(String personId, String contactId){
//        Person person = daoSupport.getPerson(personId);
//        List<Contact> contacts = person.getContacts();
//        if (contacts != null){
//            for (Contact contact:contacts){
//                if (contact.getPerson().getId().equals(contactId)){
//                    return contact;
//                }
//            }
//        }
//        return null;
//    }
//
//    /**
//     * This method returns a contact of a person with the specified ID
//     * @param person The person that is owner of the contacts
//     * @param contactId The contact ID
//     * @return
//     */
//    @Transactional (readOnly = true)
//    public Contact getContactById(Person person, String contactId){
//        List<Contact> contacts = person.getContacts();
//        if (contacts != null){
//            for (Contact contact:contacts){
//            	if (!contact.equals(null)){
//	                if (contact.getPerson().getId().equals(contactId)){
//	                    return contact;
//	                }
//            	}
//            }
//        }
//        return null;
//    }

}
