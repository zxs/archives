package com.foxconn.gds.sce.melp.roomRecord_b.service;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface examineesRecord_bService extends CrudService<Examinees> {
	DataTableReturn listForDT(DataTable dataTable,String roomID);
}
