package com.foxconn.gds.sce.melp.fMyExam.service;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.PaperDetail;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.QuestionAndOption;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface MyExamService extends CrudService<VO_ExamRoom> {
	List<VO_ExamRoom> listMyExam(String empNo);
	boolean updateExamInfo(ExamInfo examInfo);
	PaperInfo getPaperInfo(String paperId);
	List<QuestionAndOption> getQuestionAndOptions(String paperId,int tfNum,int sNum,int mNum);
	Map checkAnswer(String empNo,String paperId,String examResultId,String examRoomId , String[] questionIds,String[] selectedOptions,List<QuestionAndOption> questionAndOptions);
	boolean insertExamPaper(PaperDetail paperDetail,List<QuestionAndOption> questionList,String[] userAnswer);
	boolean insertExamResult(ExamResults examResult);
}
