package com.foxconn.gds.sce.melp.support;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.security.core.context.SecurityContextHolder;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.security.UserSessionDetails;
import com.foxconn.gds.sce.melp.support.filter.MyClientFilter;

public abstract class ClientUtil {
    private static Log log = LogFactory.getLog(ClientUtil.class);
    
	public static String fromPC2View(HttpServletRequest req, String viewName) {
		Object attrClient = req.getAttribute(MyClientFilter.ATTR_CLIENT);
		if(! MyClientFilter.FROM_PC.equals(attrClient)) {
			log.warn("!!! Client Request is NOT from PC !!!");
		}
		return viewName;
	}
	
	public static String fromMID2View(HttpServletRequest req, String viewName) {
		Object attrClient = req.getAttribute(MyClientFilter.ATTR_CLIENT);
		if(! MyClientFilter.FROM_MID.equals(attrClient)) {
			log.warn("!!! Client Request is NOT from MID !!!");
		}
		return viewName;
	}
	
	public static String returnView(HttpServletRequest req, String viewName) {
		Object attrClient = req.getAttribute(MyClientFilter.ATTR_CLIENT);
		if( MyClientFilter.FROM_PC.equals(attrClient)) {
			return viewName + "_b";
		}
		return viewName;
	}
	/**
	 * @deprecated replace with {@link com.foxconn.gds.sce.melp.security.SecurityUtils#getCurrentUser()}
	 * @return
	 */
	public static User getCurrentUser() {

	    Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

	    if (principal instanceof UserSessionDetails) return ((UserSessionDetails) principal).getUser();
	    
		log.warn("!!! NOT Logined User !!!");
	    // principal object is either null or represents anonymous user -
	    // neither of which our domain User object can represent - so return null
	    return null;
	}
}
