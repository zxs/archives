/**
 * 
 */
package com.foxconn.gds.sce.melp.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

/**
 * @author f3220873
 * 
 */
public class AjaxAuthenticationFailureHandler extends
		SimpleUrlAuthenticationFailureHandler {

	@Override
	public void onAuthenticationFailure(HttpServletRequest req,
			HttpServletResponse resp, AuthenticationException exception)
			throws IOException, ServletException {
		if ("XMLHttpRequest".equals(req.getHeader("X-Requested-With"))){
			resp.setStatus(400);
			resp.getWriter().print(
					"{\"status\":\"false\",\"error\":\""
							+ exception.getMessage() + "\"}");
			resp.getWriter().flush();
		} else {
			super.onAuthenticationFailure(req, resp, exception);
		}
	}

}
