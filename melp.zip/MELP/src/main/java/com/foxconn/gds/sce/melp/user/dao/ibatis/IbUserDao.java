package com.foxconn.gds.sce.melp.user.dao.ibatis;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.user.dao.UserDao;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value="ibUserDao")
@Qualifier("ib")
public class IbUserDao extends GenericDaoIbatisImpl<User, String> implements
		UserDao {

	@Autowired
    public IbUserDao(SqlMapClient sqlMapClient) {
		super(User.class);
		setSqlMapClient(sqlMapClient);
	}

	/**
	 * NO this, Please use {@link  com.foxconn.gds.sce.melp.user.dao.UserDao#getUser(String userId)}
	 */
	public User getUser(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * NO this, Please use {@link  com.foxconn.gds.sce.melp.user.dao.UserDao#getUserByUsername(String username)}
	 */
	public User getUserByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * NO this, Please use {@link  com.foxconn.gds.sce.melp.user.dao.UserDao#getUserBySifRefId(String sifRefId)}
	 */
	public User getUserBySifRefId(String sifRefId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
	 * NO this, Please use {@link  com.foxconn.gds.sce.melp.user.dao.UserDao#getUserByUserId(final String userId)}
	 */
	 public User getUserByUserId(final String userId) {
		 // DONE in the HibernateUserDao;
		 return null;
	 }
	 
	@SuppressWarnings("unchecked")
	public PaginatedResult<User> listWithRole( Map parameters, int skipResults, int maxResults) {
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<User> prUsers = new PaginatedResult<User>(page, pageSize);
		List<User> result = null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("User.listWithRole", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("User.listWithRole", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("User.listWithRole_count", parameters);
		
		prUsers.setResult(result);
		prUsers.setTotalResults(count);
		
		return prUsers;
		
	}

	@SuppressWarnings("unchecked")
	public void importUserWithDept(final List<Map> udrList) {
		 if (udrList != null) {
             this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
                 public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
                    executor.startBatch();
                    for (int i = 0, n = udrList.size(); i < n; i++) {
                        executor.insert("User.insertWithDept", udrList.get(i));
                    }
                    executor.executeBatch();
                    return null;
                 }
             });
          }
	}
	
	@SuppressWarnings("unchecked")
	public void importUserWithRole(final List<Map> udrList) {
		 if (udrList != null) {
             this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
                 public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
                    executor.startBatch();
                    for (int i = 0, n = udrList.size(); i < n; i++) {
                        executor.insert("User.insertWithRole", udrList.get(i));
                    }
                    executor.executeBatch();
                    return null;
                 }
             });
          }
		
	}

	
	public boolean resetPwd(Map<String, String> params) {
		return getSqlMapClientTemplate().update("User.resetPwd", params) > 0;
	}

	//@Override
	public boolean batchDeleted(final List<String> lids) {
		if(lids!=null) {
			this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {

				public Object doInSqlMapClient(SqlMapExecutor executor)
						throws SQLException {
					executor.startBatch();
					for(String did : lids) {
						executor.update("User.markDeleted", did);
					}
					executor.executeBatch();
					return null;
				}
			});
			return true;
		}
		return false;
	}

	public void updateUserWithDept(Map<String, String> params) {
		getSqlMapClientTemplate().update("User.updateWithDept", params);
		
	}

	public void updateUserWithRole(Map<String, String> params) {
		getSqlMapClientTemplate().update("User.updateWithRole", params);
		
	}

	public boolean isUserExist(String p_id)
	{
		Integer rowCount= Integer.parseInt(getSqlMapClientTemplate().queryForObject("User.isUserExist", p_id).toString()) ;
		if(rowCount>0)
			{return true;}
		else {
			return false;
		}
	}
}
