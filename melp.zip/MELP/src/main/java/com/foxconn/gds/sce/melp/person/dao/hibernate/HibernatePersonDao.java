package com.foxconn.gds.sce.melp.person.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Person;
import com.foxconn.gds.sce.melp.person.dao.PersonDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;

/**
 * @author Edward
 */
@Repository(value = "personDao")
public class HibernatePersonDao extends GenericDaoHibernateImpl<Person, String> implements PersonDao {
	
	@Autowired
     public HibernatePersonDao(SessionFactory sessionFactory) {
		super(Person.class);
		setSessionFactory(sessionFactory);
	}

	/**
      * @see com.foxconn.gds.sce.melp.person.dao.PersonDao#getPersons()
      * @see com.foxconn.gds.sce.melp.model.Person
      */
     @SuppressWarnings(value = "unchecked")
     public List<Person> getPersons() {
         return getHibernateTemplate().find("from Person");
     }

     /**
      * Retrieves a person by person id
      * @see com.foxconn.gds.sce.melp.person.dao.PersonDao#getPerson(String personId)
      * @see com.foxconn.gds.sce.melp.model.Term
      */
     public Person getPerson(final String personId){
         final String query = "from Person p where p.id = :personId";
         List<Person> personList = (List<Person>) getHibernateTemplate().find("from Person p where p.id = ?", personId);
         return uniqueResult(personList);
     }


}

