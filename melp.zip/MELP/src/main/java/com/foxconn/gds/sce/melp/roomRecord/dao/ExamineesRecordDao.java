package com.foxconn.gds.sce.melp.roomRecord.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface ExamineesRecordDao extends GenericDao<Examinees, String> {
	List<Examinees> Query_ExamineesByRoomid(Examinees examinees);
	boolean updateExamInees(final List<Examinees> examinees);
}
