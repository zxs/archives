package com.foxconn.gds.sce.melp.model;

public class BaseCode extends BasicEntity{
	/**
	 * Column:ID
	 * 主鍵
	 */
	public String id ;
	/**
	 * Column:CODE_NAME
	 * 代碼名稱
	 */
	public String codeName;
	/**
	 * Column:CODE_TYPE
	 * 代碼類型
	 */
	public String codeType;
	/**
	 * Column:CREATE_DATE
	 * 創建時間
	 */
	public String createDate;
	/**
	 * Column:CREATE_USER
	 * 創建人
	 */
	public String createUser;
	/**
	 * Column:IS_ENABLE
	 * 是否可用
	 */
	public String isEnable;
	
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCodeName() {
		return codeName;
	}

	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}

	public String getCodeType() {
		return codeType;
	}

	public void setCodeType(String codeType) {
		this.codeType = codeType;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

}
