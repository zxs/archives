package com.foxconn.gds.sce.melp.QuestionnaireStatistics.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.QuestionnaireStatistics;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface QuestionnaireStatisticsService extends CrudService<QuestionnaireStatistics> {

public   List<QuestionnaireStatistics> showQuestionnaireStatistics_S(HashMap hashMap);
public   List<QuestionnaireStatistics> showQuestionnaireStatistics_P(HashMap hashMap);

}
