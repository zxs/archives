package com.foxconn.gds.sce.melp.support.dao.util;

import java.util.ArrayList;
import java.util.List;

public class PaginatedResult<T> {
    /**
     * Results for the current page
     */
    protected List<T> result = new ArrayList<T>();
    /**
     * Total resutls count, need for calculating last page and number of pages
     */
    protected int totalResults;
    /**
     * The current page
     */
    protected int page;
    /**
     * The page size
     */
    protected int pageSize;
    /**
     * The last page number
     */
    protected int lastPage;

    public PaginatedResult(int page, int pageSize) {
        this.page = page;
        this.pageSize = pageSize;
    }

    public List<T> getResult() {
        return result;
    }

    public void setResult(List<T> result) {
        this.result = result;
    }

    public int getTotalResults() {
        return totalResults;
    }

    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public void setPageSize(int pageSize) {
        this.pageSize = pageSize;
    }

    public int getLastPage() {
        return lastPage;
    }

    public void setLastPage(int lastPage) {
        this.lastPage = lastPage;
    }
}
