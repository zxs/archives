package com.foxconn.gds.sce.melp.room.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;

import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface RoomService extends CrudService<ExamRoom> {
	 public void InsertRoom(ExamRoom roomInfo);
	 public DataTableReturn ListAllRoom(DataTable dt,int roletype);
	 public Boolean UpdateRoom(ExamRoom examRoom);
	 public ExamRoom QueryRoomByPara(ExamRoom examRoom);
	 public void DeleteRoom(List<ExamRoom> listexamRoom);
	 public String GetMaxRoomID() throws Exception;
	 public void UpdateSync(List<ExamRoom> listexamRoom);
	 public void InsertExaminees(List<Examinees> examinees);
	 public DataTableReturn ListAllExaminees(DataTable dt,String roomid);
	 public void DelPerFromRoom(List<Examinees> listExaminees);
	 public List<Examinees> exportRoomPerson(String roomid);
}
