package com.foxconn.gds.sce.melp.paperInfo.dao;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import java.util.Date;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import java.util.List;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface PaperInfoDao extends GenericDao<PaperInfo, String>{

	 /**
     * Retrieves a user
     *
     * @param userId user id
     * @return A User Object
     */
	List<PaperInfo> getQueryPaperInfo(String paperName,String userId);
	
	List<PaperInfo> getAllQueryPaperInfo(String userId);

}