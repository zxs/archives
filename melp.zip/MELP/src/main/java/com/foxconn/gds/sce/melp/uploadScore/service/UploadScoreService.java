package com.foxconn.gds.sce.melp.uploadScore.service;

import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface UploadScoreService extends CrudService<Examinees>{
	boolean updateAllInfos(String infos,String loger);// 
}
