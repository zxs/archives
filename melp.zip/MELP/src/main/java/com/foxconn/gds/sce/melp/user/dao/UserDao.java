package com.foxconn.gds.sce.melp.user.dao;

import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

/**
 * User: ronvargas
 * Date: Feb 9, 2009
 */
public interface UserDao extends GenericDao<User, String> {

    /**
     * Retrieves a user
     *
     * @param userId user id
     * @return A User Object
     */
    User getUser(String userId);

    /**
     * Retrieves a user identified by the specified username
     *
     * @param username username
     * @return A user
     */
    User getUserByUsername(final String username);

    /**
     * Retrieves a user identified by the specified id from sif
     *
     * @param sifRefId username
     * @return A user
     */
    User getUserBySifRefId(final String sifRefId);
    
    /**
     * Retrieves a user
     *
     * @param userId user id
     * @return A User Object
     */    
    public User getUserByUserId(final String userId);
    
    PaginatedResult<User> listWithRole(Map parameters, int skipResults, int maxResults);

	void importUserWithDept(final List<Map> udrList);

	void importUserWithRole(final List<Map> udrList);

	boolean resetPwd(Map<String, String> params);

	boolean batchDeleted(final List<String> lids);

	void updateUserWithDept(Map<String, String> params);

	void updateUserWithRole(Map<String, String> params);
	
	/*判斷用戶工號是否已存在*/
	public boolean isUserExist(String p_id);
}
