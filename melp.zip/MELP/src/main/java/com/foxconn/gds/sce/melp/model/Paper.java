package com.foxconn.gds.sce.melp.model;

import java.math.BigDecimal;
import java.util.Date;

public class Paper extends BasicEntity{
	private String paperName;
	private String questionTitle;
	private String optionContent;
	private Date startTime;
	private Date endTime;
	private BigDecimal getScore;
	private String userId;
	private String userName;
	private BigDecimal passScore;
	private BigDecimal timeTotal;
	private BigDecimal optionOrder;
	private String isRightAnswer;
	private BigDecimal numberS;
	private String isUserAnswer;

	
	
	public BigDecimal getNumberS() {
		return numberS;
	}

	public String getIsUserAnswer() {
		return isUserAnswer;
	}

	public void setIsUserAnswer(String isUserAnswer) {
		this.isUserAnswer = isUserAnswer;
	}

	public void setNumberS(BigDecimal numberS) {
		this.numberS = numberS;
	}

	public BigDecimal getNumberM() {
		return numberM;
	}

	public void setNumberM(BigDecimal numberM) {
		this.numberM = numberM;
	}

	public BigDecimal getNumberTF() {
		return numberTF;
	}

	public void setNumberTF(BigDecimal numberTF) {
		this.numberTF = numberTF;
	}

	public BigDecimal getScoreS() {
		return scoreS;
	}

	public void setScoreS(BigDecimal scoreS) {
		this.scoreS = scoreS;
	}

	public BigDecimal getScoreM() {
		return scoreM;
	}

	public void setScoreM(BigDecimal scoreM) {
		this.scoreM = scoreM;
	}

	public BigDecimal getScoreTF() {
		return scoreTF;
	}

	public void setScoreTF(BigDecimal scoreTF) {
		this.scoreTF = scoreTF;
	}

	private BigDecimal numberM;
	private BigDecimal numberTF;
	private BigDecimal scoreS;
	private BigDecimal scoreM;
	private BigDecimal scoreTF;
	public BigDecimal getOptionOrder() {
		return optionOrder;
	}

	public void setOptionOrder(BigDecimal optionOrder) {
		this.optionOrder = optionOrder;
	}

	public String getIsRightAnswer() {
		return isRightAnswer;
	}

	public void setIsRightAnswer(String isRightAnswer) {
		this.isRightAnswer = isRightAnswer;
	}

	public String getQuestionOrder() {
		return questionOrder;
	}

	public void setQuestionOrder(String questionOrder) {
		this.questionOrder = questionOrder;
	}

	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	private String questionOrder;
	private String questionType;

	public String getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName = paperName;
	}

	public String getQuestionTitle() {
		return questionTitle;
	}

	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}

	public String getOptionContent() {
		return optionContent;
	}

	public void setOptionContent(String optionContent) {
		this.optionContent = optionContent;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public BigDecimal getGetScore() {
		return getScore;
	}

	public void setGetScore(BigDecimal getScore) {
		this.getScore = getScore;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public BigDecimal getPassScore() {
		return passScore;
	}

	public void setPassScore(BigDecimal passScore) {
		this.passScore = passScore;
	}

	public BigDecimal getTimeTotal() {
		return timeTotal;
	}

	public void setTimeTotal(BigDecimal timeTotal) {
		this.timeTotal = timeTotal;
	}

	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
