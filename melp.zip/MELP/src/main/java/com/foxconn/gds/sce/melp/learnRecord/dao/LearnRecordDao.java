package com.foxconn.gds.sce.melp.learnRecord.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
public interface LearnRecordDao extends GenericDao<MyClassInfo, String> {
	List<MyClassInfo> listLearnRecord(String empNo);
}
