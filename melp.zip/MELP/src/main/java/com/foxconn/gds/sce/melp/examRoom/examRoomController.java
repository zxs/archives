package com.foxconn.gds.sce.melp.examRoom;

import java.math.BigDecimal;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.foxconn.gds.sce.melp.examRoom.service.examRoomService;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.user.service.UserService;

@Controller
@RequestMapping(value="/examroom/**")//映射路径
public class examRoomController {

	
	 private UserService user_Srv;
	 private examRoomService examRoom_Srv;
	
		@Autowired//注入
		public void setUserService(UserService userSrv) {
			this.user_Srv = userSrv;
		}
		
		@Autowired//注入
		public void setImplexamRoomService(examRoomService examService) {
			this.examRoom_Srv=examService;
		}
		
		@RequestMapping(method = RequestMethod.GET, value ="QueryExamRoompage.spr")//映射路径
		public ModelAndView queryExamRoompage(){
		
			return new ModelAndView("examroom/QueryExamRoom");//指向文件
		}
		
		
		@RequestMapping(method=RequestMethod.GET, value="main.spr")
		public  String examroomMain() {
			return "/examroom/main";
		}

		// 查询補考名單設置(根据id 权限、考卷名称)
		@RequestMapping(value ="examRoomqueryproc.spr")
		public String examRoomqueryproc(Model model,HttpServletRequest request) 
		{
			List<ExamRoom> listExamRoom;	
			String paper_ID = request.getParameter("id");	//获取考卷PAPER_ID
			String exam_Room_ID = request.getParameter("examroomid");	//获取考場編號 EXAM_ROOM_ID
			
			System.out.println("getParameter pape_Name:"+ paper_ID+", exam_Room_ID:"+exam_Room_ID);
			
			listExamRoom=examRoom_Srv.queryExamRoom(paper_ID,exam_Room_ID);
			model.addAttribute("listExamRoom", listExamRoom);			
		
			
			int intyk, intkk, intbk;
			for(ExamRoom er : listExamRoom) {

				intyk = Integer.parseInt( er.getExamTimes().toString() );// 已考次数
				intkk = Integer.parseInt(  er.getExamTimesMax() ); // 可考次数
				intbk = Integer.parseInt( er.getExamAdd() );//已补考次数

				if( (intyk-intkk) > 0 ) {
					intbk = intyk - intkk;	//补考次数
					intyk = intkk;		// 已考次数
				} else {
					intbk = 0;	//补考次数
				}
				er.setExamTimes( new BigDecimal(Integer.toString(intyk)) );
				er.setExamAdd( Integer.toString(intbk) );
				
				//已考次数（显示时，小于后者）/可考次数
				//已补考次数/可补考次数
			}
			
			return "examroom/QueryExamRoom";//指向文件
		}
		
//		// 查询補考名單設置(根据id 权限、考卷名称)
//		@RequestMapping(value ="examRoomqueryproc.spr")
//		public String examRoomqueryproc(Model model,HttpServletRequest request) 
//		{
//			List<ExamRoom> listExamRoom;	
//			String paper_ID = request.getParameter("paper_ID");	//获取考卷PAPER_ID
//			String exam_Room_ID = request.getParameter("exam_Room_ID");	//获取考場編號 EXAM_ROOM_ID
//			
//			System.out.println("getParameter pape_Name:"+ paper_ID+", exam_Room_ID:"+exam_Room_ID);
//			
//			listExamRoom=examRoom_Srv.queryExamRoom(paper_ID,exam_Room_ID);
//			model.addAttribute("listExamRoom", listExamRoom);			
//		
//			
//			int intyk, intkk, intbk;
//			for(ExamRoom er : listExamRoom) {
//
//				intyk = Integer.parseInt( er.getExamTimes() );// 已考次数
//				intkk = Integer.parseInt(  er.getExamTimesMax() ); // 可考次数
//				intbk = Integer.parseInt( er.getExamAdd() );//已补考次数
//
//				if( (intyk-intkk) > 0 ) {
//					intbk = intyk - intkk;	//补考次数
//					intyk = intkk;		// 已考次数
//				} else {
//					intbk = 0;	//补考次数
//				}
//				er.setExamTimes( Integer.toString(intyk) );
//				er.setExamAdd( Integer.toString(intbk) );
//				
//				//已考次数（显示时，小于后者）/可考次数
//				//已补考次数/可补考次数
//			}
//			
//			return "examroom/QueryExamRoom";//指向文件
//		}
		
		
		//查詢補考設置的名單  <!-- by姓名、工号+考卷ID、场次编号  20111217  River -->
		@RequestMapping(value ="examRoomqueryproc2.spr")
		public String examRoomqueryproc2(Model model,HttpServletRequest request) 
		{
			List<ExamRoom> listExamRoom;	
			String paper_ID = request.getParameter("paper_ID");	//获取考卷PAPER_ID
			String exam_Room_ID = request.getParameter("exam_Room_ID");	//获取考場編號 EXAM_ROOM_ID
			String emp_Name = request.getParameter("emp_Name");	//获取姓名
			String emp_No = request.getParameter("emp_No");	//获取工号
			
			
			System.out.println("getParameter pape_Name:"+ paper_ID+", exam_Room_ID:"+exam_Room_ID+", emp_Name:"+emp_Name+", emp_No:"+emp_No);
			
			listExamRoom=examRoom_Srv.queryEmpnoandName(paper_ID,exam_Room_ID,emp_Name,emp_No);
			model.addAttribute("listExamRoom", listExamRoom);			
			return "examroom/QueryExamRoom";//指向文件

		}
		
		//補考增减設置  <!-- by工号+補考次數  20111220  River -->
		@RequestMapping(value ="examRoomqueryproc4.spr")
		public String examRoomqueryproc4(Model model,HttpServletRequest request) 
		{
			List<ExamRoom> listExamRoom;	
			String paper_ID = request.getParameter("paper_ID");	//获取考卷PAPER_ID
			String exam_Room_ID = request.getParameter("exam_Room_ID");	//获取考場編號 EXAM_ROOM_ID
			String strExamAdd = request.getParameter("emp_Name");	//获取可补考次数
			String emp_No = request.getParameter("emp_No");	//获取工号
			
			
			System.out.println("getParameter pape_Name:"+ paper_ID+", exam_Room_ID:"+exam_Room_ID+", emp_Name:"+strExamAdd+", emp_No:"+emp_No);
			
			listExamRoom=examRoom_Srv.updateandquery(paper_ID,exam_Room_ID,strExamAdd,emp_No);
			model.addAttribute("listExamRoom", listExamRoom);			
			return "examroom/QueryExamRoom";//指向文件

		}
		
		
		

}
