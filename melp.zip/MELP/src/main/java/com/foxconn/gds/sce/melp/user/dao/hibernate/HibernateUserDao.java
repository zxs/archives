package com.foxconn.gds.sce.melp.user.dao.hibernate;

import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.user.dao.UserDao;

/**
 * @author: ronvargas
 * Date: Feb 9, 2009
 */
@Repository(value = "userDAO")
@Qualifier("hi")
public class HibernateUserDao extends GenericDaoHibernateImpl<User,String> implements UserDao {


    @Autowired
    public HibernateUserDao(SessionFactory sessionFactory) {
		super(User.class);
		setSessionFactory(sessionFactory);
	}

	/**
     * Retrieves a user by user id
     * @see com.foxconn.gds.sce.melp.user.dao.UserDao#getUser(String userId)
     * @see com.foxconn.gds.sce.melp.model.User
     */
    public User getUser(final String userId){
        List<User> userList = (List<User>) getHibernateTemplate().find("from User u where u.id = ?", userId);
        return uniqueResult(userList);

    }

    /**
     * @see com.foxconn.gds.sce.melp.user.dao.UserDao#getUserByUsername(String)
     * @see com.foxconn.gds.sce.melp.model.User
     */
    public User getUserByUsername(final String username) {
        List<User> userList = (List<User>) getHibernateTemplate().find("from User u where u.username = ?", username);
        return uniqueResult(userList);

    }

    /**
     * @see com.foxconn.gds.sce.melp.user.dao.UserDao#getUserBySifRefId(String)
     * @see com.foxconn.gds.sce.melp.model.User
     */
    public User getUserBySifRefId(final String sifRefId) {
        List<User> userList = (List<User>) getHibernateTemplate().find("from User u where u.sifRefId = ?", sifRefId);
        return uniqueResult(userList);

    }

    public User getUserByUserId(final String userId) {
        List<User> userList = (List<User>) getHibernateTemplate().find("from User u where upper(u.userId) = ?", userId.toUpperCase());
        return uniqueResult(userList);

    }
    
    @SuppressWarnings("unchecked")
	public PaginatedResult<User> listWithRole( Map parameters, int skipResults, int maxResults) {
		// DONE this in the IbUserDao
		return null;
	}

	public void importUserWithDept(final List<Map> udrList) {
		// DONE this in the IbUserDao
		
	}

	public void importUserWithRole(final List<Map> udrList) {
		// DONE this in the IbUserDao
		
	}
    
	public boolean resetPwd(Map<String, String> params) {
		// DONE this in the IbUserDao
		return false;
	}

	public boolean batchDeleted(final List<String> lids) {
		// DONE this in the IbUserDao
		return false;
	}

	public void updateUserWithDept(Map<String, String> params) {
		// DONE this in the IbUserDao
		
	}

	public void updateUserWithRole(Map<String, String> params) {
		// DONE this in the IbUserDao
		
	}
	
	public boolean isUserExist(String p_id)
	{
		// DONE this in the IbUserDao
		return false;
	}
		
}
