package com.foxconn.gds.sce.melp.examRoom.dao.ibatis;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.examRoom.dao.examRoomDao;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibExamRoomDao")
public class IbexamRoomDao extends GenericDaoIbatisImpl<ExamRoom, String> implements examRoomDao{
	
	@Autowired
    public IbexamRoomDao(SqlMapClient sqlMapClient) {
		super(ExamRoom.class);
		setSqlMapClient(sqlMapClient); 
	}

	public IbexamRoomDao(Class<ExamRoom> type) {
		super(type);
		// TODO Auto-generated constructor stub
	}

	public String create(PaperInfo newInstance) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(PaperInfo transientObject) {
		// TODO Auto-generated method stub
		
	}

	public void delete(PaperInfo persistentObject) {
		// TODO Auto-generated method stub
		
	}

	//初始頁面查詢補考設置的名單  <!-- by考卷ID、场次编号  20111217  River -->
	public List<ExamRoom> getqueryExamRoom(String paper_ID, String exam_Room_ID) {
		// TODO Auto-generated method stub
		List<ExamRoom> listExamRoom;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("exam_room_id", exam_Room_ID);	
			hs.put("paper_id", paper_ID);
			System.out.println("考卷ID："+paper_ID+"_考場編號："+exam_Room_ID);
			listExamRoom = getSqlMapClientTemplate().queryForList("query_examroom_paperandexam", hs);
			System.out.println(listExamRoom.size());
		}catch(Exception e){
				System.out.println(e.toString());
				return null;
			}		
			return listExamRoom;
	}

	//初始頁面查詢補考設置的名單  <!-- by姓名、工号+考卷ID、场次编号  20111217  River -->
	public List<ExamRoom> getqueryEmpnoandName(String paper_ID, String exam_Room_ID,String emp_Name,String emp_No) {	
		// TODO Auto-generated method stub
		List<ExamRoom> listExamRoom;
		try{
			HashMap<String, String> hs = new HashMap<String,String>();
			hs.put("exam_room_id", exam_Room_ID);	
			hs.put("paper_id", paper_ID);
			hs.put("emp_Name", emp_Name);
			hs.put("emp_No", emp_No);
			listExamRoom = getSqlMapClientTemplate().queryForList("query_examroom_empidandexam", hs);
			System.out.println(listExamRoom.size());
		}catch(Exception e){
				System.out.println(e.toString());
				return null;
			}		
			return listExamRoom;
	}

		//補考增减設置  <!-- by工号+補考次數  20111220  River -->
		public List<ExamRoom> getUpdateAndQuery(String paper_ID, String exam_Room_ID,String strExamAdd,String emp_No) {	
			// TODO Auto-generated method stub
			List<ExamRoom> listExamRoom;
			try{
				HashMap<String, String> hs = new HashMap<String,String>();
				hs.put("exam_room_id", exam_Room_ID);	
				hs.put("paper_id", paper_ID);
				hs.put("examadd", strExamAdd);
				hs.put("emp_No", emp_No);
				listExamRoom = getSqlMapClientTemplate().queryForList("query_examroom_updateandquery", hs);
				System.out.println(listExamRoom.size());
			}catch(Exception e){
					System.out.println(e.toString());
					return null;
				}		
				return listExamRoom;
		}
	
	
	
}
