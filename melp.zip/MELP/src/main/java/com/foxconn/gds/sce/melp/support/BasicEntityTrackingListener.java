package com.foxconn.gds.sce.melp.support;

import java.util.Date;

import javax.persistence.PrePersist;

import com.foxconn.gds.sce.melp.model.BasicEntity;

/**
 * User: Anai
 * Date: Jan 30, 2009
 * Time: 1:59:54 PM
 * 
 */
public class BasicEntityTrackingListener {

    //private final transient Logger logger = LoggerFactory.getLogger(BasicEntityTrackingListener.class);

    /**
     * Sets the {@link com.foxconn.gds.sce.melp.model.BasicEntity#entityCreationTimestamp}
     * tracking fields for all persistent entities, i.e., subclasses of {@link com.foxconn.gds.sce.melp.model.BasicEntity}.
     *
     * @param entity <tt>BasicEntity</tt> instance for which to store tracking information
     */
    @PrePersist
    public void onPrePersist(BasicEntity entity) {
        Date timestamp = new Date();
        if (entity.getEntityCreationTimestamp() == null) {
            entity.setEntityCreationTimestamp(timestamp);
        }
    }
}
