package com.foxconn.gds.sce.melp.fdownloadpaper.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.model.VO_ExamineesInfo;
import com.foxconn.gds.sce.melp.model.VO_RolePermission;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface DownloadPaperService extends CrudService<ExamRoom> {
	//查詢考場列表
	List<ExamRoom> listByUser(User user);
	
	//查詢考場列表By ID
	List<ExamRoom> getExamRoomInfos(List<String> examRoomIds);
	
	//獲取角色菜單信息
	List<VO_RolePermission> getAllRolePermissions();
	
	//獲取考卷設置信息
	List<PaperInfo> getPaperInfos(List<String> paperIds);
	
	//獲取考卷對應題庫試題信息
	List<Question> getQuestions(List<String> paperIds);
	
	//獲取考卷試題選項信息
	List<QuestionOptions> getQuestionOptions(List<String> paperIds);
	
	//獲取學員信息
	List<Examinees> getExamineedList(List<String> examRoomIds);
	
	//獲取可登陸用戶信息
	List<VO_ExamineesInfo> getUserList(List<String> examRoomIds,String empNo);
	
	//獲取學員考試信息
	List<ExamInfo> getExamIfoList(List<String> examRoomIds);
	
	//獲取學員考試結果信息
	List<ExamResults> getExamResultsList(List<String> examRoomIds);
	
	Integer getCurrentUserRole();
}
