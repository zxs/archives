package com.foxconn.gds.sce.melp.fdownloadpaper.service.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

import org.aspectj.weaver.ast.Var;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao;
import com.foxconn.gds.sce.melp.fdownloadpaper.dao.ibatis.IbDownloadPaperDao;
import com.foxconn.gds.sce.melp.fdownloadpaper.service.DownloadPaperService;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.model.VO_ExamineesInfo;
import com.foxconn.gds.sce.melp.model.VO_RolePermission;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "downloadPaperService")
public class DownloadPaperServiceImpl extends
		CrudServiceImpl<ExamRoom, DownloadPaperDao> implements
		DownloadPaperService {

	@Autowired
	public void setDownloadPaperDao(DownloadPaperDao downloadPaperDao) {
		this.daoSupport = downloadPaperDao;
	}

	public List<ExamRoom> listByUser(User user){
		Set<Role> userRole=user.getRoles();
		String roleId=userRole.iterator().next().getId();
		
		//管理員
		if(roleId.equalsIgnoreCase("8a14c9cb3458c4ea013458c4f1480032")){
			return daoSupport.listByAdmin();
		}
		else{
			return daoSupport.listByUser(user.getUserId());
		}
	}
	
	public List<ExamRoom> getExamRoomInfos(List<String> examRoomIds){
		List<ExamRoom> roomList= new ArrayList<ExamRoom>();
		for (String examRoomId : examRoomIds) {
			ExamRoom temp=daoSupport.ListByRoomId(examRoomId);
			roomList.add(temp);
		}
		return roomList;
	}

	public List<Examinees> getExamineedList(List<String> examRoomIds) {
		List<Examinees> examineesList= new ArrayList<Examinees>();
		for (String examRoomId : examRoomIds) {
			List<Examinees> tempExamineesInfos=daoSupport.getExamineedList(examRoomId);
			examineesList.addAll(tempExamineesInfos);
		}
		return examineesList;
	}
	
	public List<VO_RolePermission> getAllRolePermissions(){
		return daoSupport.listAllRolePermissions();
	}

	public List<PaperInfo> getPaperInfos(List<String> paperIds) {
		List<PaperInfo> paperInfoList= new ArrayList<PaperInfo>();
		for(String paperId:paperIds){
			PaperInfo temppaperInfoList=daoSupport.listPaperInfo(paperId);
			paperInfoList.add(temppaperInfoList);
		}
		return paperInfoList;
	}

	public List<Question> getQuestions(List<String> paperIds) {
		List<Question> questionsList= new ArrayList<Question>();
		for(String paperId:paperIds){
			List<Question> tempQuestionsList=daoSupport.listQuestions(paperId);
			questionsList.addAll(tempQuestionsList);
		}
		return questionsList;
	}

	public List<QuestionOptions> getQuestionOptions(List<String> paperIds) {
		List<QuestionOptions> quesOptionsList= new ArrayList<QuestionOptions>();
		for(String paperId:paperIds){
			List<QuestionOptions> tempQuesOptionsList=daoSupport.listQuestionOptions(paperId);
			quesOptionsList.addAll(tempQuesOptionsList);
		}
		return quesOptionsList;
	}

	public List<VO_ExamineesInfo> getUserList(List<String> examRoomIds,String empNo) {
		List<VO_ExamineesInfo> userList= new ArrayList<VO_ExamineesInfo>();
		for (String examRoomId : examRoomIds) {
			List<VO_ExamineesInfo> tempuserList=daoSupport.getUserList(examRoomId);
			userList.addAll(tempuserList);
		}
		
		//當前登錄人員及管理員
		List<VO_ExamineesInfo> tempuserList=daoSupport.getCurrentUserAndAdmin(empNo);
		userList.addAll(tempuserList);
		
		return userList;
	}

	public List<ExamInfo> getExamIfoList(List<String> examRoomIds) {
		List<ExamInfo> examInfoList= new ArrayList<ExamInfo>();
		for (String examRoomId : examRoomIds) {
			List<ExamInfo> tempExamInfo=daoSupport.getExamIfoList(examRoomId);
			examInfoList.addAll(tempExamInfo);
		}
		return examInfoList;
	}
	
	//獲取學員考試結果信息
	public List<ExamResults> getExamResultsList(List<String> examRoomIds){
		List<ExamResults> examResultsList=new ArrayList<ExamResults>();
		for (String examRoomId : examRoomIds) {
			List<ExamResults> tempExamResults=daoSupport.listExamResults(examRoomId);
			examResultsList.addAll(tempExamResults);
		}
		return examResultsList;
	}
	
	public Integer getCurrentUserRole(){
		User user=SecurityUtils.getCurrentUser();
		Set<Role> roles=user.getRoles();
		String roleId=roles.iterator().next().getId();
		if(roleId.equals("8a14c9cb3458c4ea013458c4f1480032")){
			//管理員
			return 0;
		}
		else if(roleId.equals("8a14c9cb3458c4ea013458c4f1c50062")){
			//訓練專員
			return 1;
		}
		else if(roleId.equals("8a14c9cb3458c4ea013458c4f1a50052")){
			//學員
			return 2;
		}
		else{
			//其他
			return -1;
		}
	}

}
