package com.foxconn.gds.sce.melp.evaluateCourse.dao.ibatis;

import java.io.Console;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.evaluateCourse.dao.EvaluateCourseDao;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.questionnaires.dao.QuestionnairesDao;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value = "IbEvaluateCourseDao")
public class IbEvaluateCourseDao extends
		GenericDaoIbatisImpl<Questionnaires, String> implements
		EvaluateCourseDao {
	@Autowired
	public IbEvaluateCourseDao(SqlMapClient sqlMapClient) {
		super(Questionnaires.class);
		setSqlMapClient(sqlMapClient);
	}

	public List<Questionnaires> showQuestionnaires_P(String courseID,String courseCreator) {
		String userid=SecurityUtils.getCurrentUser().getUserId();
		Map map = new HashMap();
		map.put("courseID", courseID);
		map.put("courseCreator", courseCreator);
		
		return (List<Questionnaires>) getSqlMapClientTemplate().queryForList(
				"EvaluateQuetionnaires", map);
	}

	@SuppressWarnings("unchecked")
	public Boolean updateEvRecord(String questionId, String option,String classID,String courseID,String empNo) {
		final Map map = new HashMap();
	   int aCount=0;
	   int bCount=0;
	   int cCount=0;
	   int dCount=0;
	   int eCount=0;
	   if(option.equals("優秀"))
		   aCount=1;
	   else if(option.equals("很好"))
			   bCount=1;
	   else if(option.equals("好"))
		   cCount=1;
	   else if(option.equals("一般"))
		   dCount=1;
	   else eCount=1;
		map.put("questionId", questionId);
		map.put("option", option);
		map.put("classID", classID);
		map.put("courseID", courseID);
		map.put("empNo", empNo);
		map.put("aCount", aCount);
		map.put("bCount", bCount);
		map.put("cCount", cCount);
		map.put("dCount", dCount);
		map.put("eCount", eCount);
		
		
		/* try { getSqlMapClientTemplate().insert( "updateEvRecord",map); return
		  true; } catch (Exception e) { return false; }*/
		 
		 
		this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
			public Object doInSqlMapClient(SqlMapExecutor executor)
					throws SQLException {
				executor.startBatch();

				executor.insert("updateEvRecord", map);
				executor.executeBatch();
				return true;
			}
		});
		return false;
	}
	public int getEvType(String courseID) {
		return (Integer) getSqlMapClientTemplate().queryForObject(
				"getEvType", courseID);
	}
	public String getCourseCreator(String courseID) {
		return (String) getSqlMapClientTemplate().queryForObject(
				"getCourseCreator", courseID);
	}
	public Boolean insertEvRecord(String classID,String courseID,String empNo) {
		HashMap map=new HashMap();
		map.put("CLASS_ID", classID);
		map.put("COURSE_ID", courseID);
		map.put("EMP_NO", empNo);
		try {
			  getSqlMapClientTemplate().insert(
					"insertEvRecord",map);
	return true;
		} catch (Exception e) {
			return false;
		}
		}
				
	

}
