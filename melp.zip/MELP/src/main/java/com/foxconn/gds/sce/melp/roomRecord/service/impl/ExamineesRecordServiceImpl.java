package com.foxconn.gds.sce.melp.roomRecord.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.roomRecord.dao.ExamineesRecordDao;
import com.foxconn.gds.sce.melp.roomRecord.dao.RoomRecordDao;
import com.foxconn.gds.sce.melp.roomRecord.service.ExamineesRecordService;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value="examineesRecordService")
public class ExamineesRecordServiceImpl extends CrudServiceImpl<Examinees, ExamineesRecordDao> implements ExamineesRecordService {

	@Autowired
	public void setIbroomRecordDao(ExamineesRecordDao examineesRecordDao){
		this.daoSupport=examineesRecordDao;
	}
	public void create(Examinees entity) {
		// TODO Auto-generated method stub

	}

	public void update(Examinees entity) {

	}

	public void delete(Examinees entity) {
		// TODO Auto-generated method stub

	}

	public Examinees read(String entityId) {
		
		return null;
	}
	public List<Examinees> Query_ExamineesByRoomid(Examinees examinees) {
		return this.daoSupport.Query_ExamineesByRoomid(examinees);
	}
	
	@Transactional
	public int UpdateExaminees(List<Examinees> examinees) {
		// TODO Auto-generated method stub
		boolean flag= this.daoSupport.updateExamInees(examinees);
		if(flag)
			return 1;
		return 0;
	}

}
