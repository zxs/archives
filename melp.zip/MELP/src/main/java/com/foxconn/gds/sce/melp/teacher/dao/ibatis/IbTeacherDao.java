package com.foxconn.gds.sce.melp.teacher.dao.ibatis;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.Teacher;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.teacher.dao.TeacherDao;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibTeacherDao")
public class IbTeacherDao extends GenericDaoIbatisImpl<Teacher, String> implements TeacherDao {
	
	@Autowired
	public IbTeacherDao(SqlMapClient sqlMapClient) {
		
		super(Teacher.class);
		setSqlMapClient(sqlMapClient);
	}

	
	public PaginatedResult<Teacher> selTeacherList(Map parameters,int skipResults, int maxResults) 
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<Teacher> prTeacher = new PaginatedResult<Teacher>(page, pageSize);
		List<Teacher> result = null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("Teacher.findAllTeacher", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("Teacher.findAllTeacher", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("Teacher.findAllTeacher_count", parameters);
		
		prTeacher.setResult(result);
		prTeacher.setTotalResults(count);
		
		return prTeacher;
	}
	
	
	   //新增講師
		public Boolean addTeacher(Teacher p_teacher)
		{
			getSqlMapClientTemplate().insert("Teacher.addTeacher",p_teacher);
			return true;
			  
		}

		//判斷講師是否存在
		public  boolean isTeacherExist(Teacher p_teacher) 
		{
			Integer rowCount= Integer.parseInt(getSqlMapClientTemplate().queryForObject("Teacher.isTeacherExist", p_teacher).toString()) ;
			if(rowCount>0)
				{return true;}
			else {
				return false;
			}
		}
	
	
		
		public List<BaseCode> selTeacherType(){
			return getSqlMapClientTemplate().queryForList("Teacher.selTeacherType");
		}
		
		public List<BaseCode> selTeacherLevel()
		{
			return getSqlMapClientTemplate().queryForList("Teacher.selTeacherLevel");
		}
		
		/*根據ID查詢講師信息*/
		public Teacher selTeacherByID(Teacher p_teacher)
		{
			return (Teacher)getSqlMapClientTemplate().queryForObject("Teacher.selTeacherByID",p_teacher);
		}
		
		
		/*更新講師*/
		public boolean updTeacher(Teacher p_teacher)
		{
			int flag=getSqlMapClientTemplate().update("Teacher.updateTeacher", p_teacher);
			return flag>0 ?true:false;
		}
		
		/*刪除講師*/
		public boolean delTeacher(String p_id)
		{
			getSqlMapClientTemplate().update("Teacher.delTeacher", p_id);
			return true;
		}
}
