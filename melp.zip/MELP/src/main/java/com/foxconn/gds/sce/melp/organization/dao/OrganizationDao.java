package com.foxconn.gds.sce.melp.organization.dao;

import java.util.List;
import java.util.Set;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

/**
 * User: franco
 * Date: 27/01/2009
 * Time: 08:28:18 AM
 * 
 */
public interface OrganizationDao extends GenericDao<Organization, String> {

    List<Organization> getRootOrganizations();

    Organization getUserOrganization(String userId);

    //TODO: Review this method to see if it makes sense and is required. If not, remove it
    //boolean isCustomUserIdAvailable( String customUserId, String organizationId );

    //TODO: Review this method to see if it makes sense and is required. If not, remove it
    //boolean isOrganizationNameAvailable(String organizationName, String parentId);

    /**
     * Returns a list of organizations with the specified IDs
     * @param organizationIds a set of long IDs of the organizations to retrieve
     * @return a list of Organization objects
     */
    List<Organization> getOrganizations( Set<String> organizationIds );

    /**
     * Returns a list containing all of the organizations
     * @return a list of Organization objects
     */
    List<Organization> getOrganizations();

    //TODO: Review this method to see if it makes sense and is required.
    //List<Organization> getOrganizationsWithLogo();

}
