package com.foxconn.gds.sce.melp.teacher;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


import bsh.Console;

import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.teacher.service.TeacherService;
import com.foxconn.gds.sce.melp.user.UserController;
import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.Teacher;

@Controller
@RequestMapping("/teacher/**")
public class TeacherController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
    private TeacherService teacherSrv;
	
	@Autowired
	public void setteacherSrv(TeacherService teacherSrv) 
	{
		this.teacherSrv = teacherSrv;
	}
	
	//打開頁面
	@RequestMapping(method=RequestMethod.GET, value="showList.spr")
    public ModelAndView showList(@RequestParam("iframe") String iframe) 
    {
		return new ModelAndView("/teacher/teacherList", "iframe", "true".equals(iframe)?"true":"false");
	}
    
	/*彈出講師選擇器*/

	@RequestMapping(method=RequestMethod.GET, value="showTeacherSeletor.spr")
    public ModelAndView showTeacherSeletor(HttpServletRequest request) 
    {
		return new ModelAndView("/teacher/teacherTest");
	}
	
	
	
    //查詢講師列表
    @RequestMapping(method=RequestMethod.POST, value="findAllTeacherList.spr")
	public @ResponseBody Object findAllTeacherList(@RequestParam("_dt_json") String dtjson)
	{
		
		logger.info("String dtjson=" + dtjson);
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		
		String userid="";
		if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userid="";
		}
		else
		{
			userid=SecurityUtils.getCurrentUser().getUserId();
		}
		
		DataTableReturn tableReturn = this.teacherSrv.findAllTeacher(dataTable, userid);
		return tableReturn;
		
	}
	
    
    /*新增講師addTeacher*/
    @RequestMapping(method=RequestMethod.POST,value="addTeacher.spr")
	@ResponseBody
	public String addTeacher(HttpServletRequest request)
    {
    	String _teacherType=request.getParameter("teacher_type");
    	String _teacher_level=request.getParameter("teacher_level");
    	String _emp_no=request.getParameter("emp_no");
    	String _emp_name=request.getParameter("emp_name");
    	String _dept_name=request.getParameter("dept_name");
    	String _tel_no=request.getParameter("tel_no");
    	String _phone_no=request.getParameter("phone_no");
    	String _email=request.getParameter("email");
    	String _intro=request.getParameter("intro");
    	int int_type=0;
    	int int_level=0;
    	
    	if(!_teacherType.isEmpty())
    	{
    		int_type=Integer.parseInt(_teacherType);
    	}
    	if(!_teacher_level.isEmpty())
    	{
    		int_level=Integer.parseInt(_teacher_level);
    	}
    	
    	UUID uuid=UUID.randomUUID();
		String id = uuid.toString();
		id=id.replaceAll("-","");
    	
		String creator=SecurityUtils.getCurrentUser().getUserId();
		
		
    	Teacher _tTeacher=new Teacher();
    	_tTeacher.setTEACHER_TYPE(int_type);
    	_tTeacher.setTEACHER_LEVEL(int_level);
    	_tTeacher.setEMP_NO(_emp_no);
    	_tTeacher.setEMP_NAME(_emp_name);
    	_tTeacher.setDEPT_NAME(_dept_name);
    	_tTeacher.setTEL_NO(_tel_no);
    	_tTeacher.setPHONE_NO(_phone_no);
    	_tTeacher.setE_MAIL(_email);
    	_tTeacher.setINTRODUCTION(_intro);
    	_tTeacher.setId(id);
    	_tTeacher.setCREATE_USER(creator);
    	
    	String msg="";
    	String success="";
    	if(teacherSrv.addTeacher(_tTeacher))
		{
			msg="新增講師成功！";
			success="true";
		}
		else {
			msg="新增講師失敗！";
			success="false";
		}
		return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";
    }
    

    @RequestMapping(method=RequestMethod.POST,value="isTeacherExist.spr")
	@ResponseBody
	public String isTeacherExist(HttpServletRequest request)
    {
    	String _str_teacher_type=request.getParameter("teacherTypeID");
    	String _emp_no=request.getParameter("emp_no");
    	String _emp_name=request.getParameter("emp_name");
    	String _teacherID=request.getParameter("teacherID");
    	String userid="";
    	int _teacher_type=0;
    	if(SecurityUtils.administratorPlayedbyCurrentUser())
		{
			userid="";
		}
		else
		{
			userid=SecurityUtils.getCurrentUser().getUserId();
		}
    	
    	if(!_str_teacher_type.isEmpty())
    	{
    		_teacher_type=Integer.parseInt(_str_teacher_type);
    	}
    	
    	Teacher _tTeacher=new Teacher();
    	_tTeacher.setEMP_NO(_emp_no);
    	_tTeacher.setEMP_NAME(_emp_name);
    	_tTeacher.setCREATE_USER(userid);
    	_tTeacher.setId(_teacherID);
    	_tTeacher.setTEACHER_TYPE(_teacher_type);
    	String success="";
    	
    	
    	
    	if(teacherSrv.isTeacherExist(_tTeacher))
    	{
			success="false";
    	}
    	else
    	{
			success="ture";
		}
    	return	"{\"success\":\""+success+"\"}";
    }
    
    
   /*講師类型or级别*/  
    @RequestMapping(method=RequestMethod.GET,value="TeacherTypeOrLevel.spr")
	@ResponseBody
	public List<BaseCode> TeacherTypeOrLevel(HttpServletRequest request)
    {
    	String flag=request.getParameter("flag").toString().trim();
        List<BaseCode> lists=null;
    	if(flag.equals("level"))
    	{
    		lists=teacherSrv.selTeacherLevel();

    	}
    	else 
    	{
    		lists=teacherSrv.selTeacherType();
		}	
        return lists;
    }
    
    @RequestMapping(method=RequestMethod.GET,value="getTeacherInfo.spr")
	@ResponseBody
    public Teacher getTeacherInfo(HttpServletRequest request)
    {
    	String id=request.getParameter("id");
    	Teacher p_teacher=new Teacher();
    
    	p_teacher.setId(id);
    	Teacher iTeacher=teacherSrv.selTeacherByID(p_teacher);
    	return iTeacher;
    }
    
    /*編輯講師*/
    @RequestMapping(method=RequestMethod.POST,value="editTeacherInfo.spr")
	@ResponseBody
    public String editTeacherInfo(HttpServletRequest request)
    {
    	String id=request.getParameter("id");
    	String _teacherType=request.getParameter("teacher_type");
    	String _teacher_level=request.getParameter("teacher_level");
    	String _emp_no=request.getParameter("emp_no");
    	String _emp_name=request.getParameter("emp_name");
    	String _dept_name=request.getParameter("dept_name");
    	String _tel_no=request.getParameter("tel_no");
    	String _phone_no=request.getParameter("phone_no");
    	String _email=request.getParameter("email");
    	String _intro=request.getParameter("intro");
    	int int_type=0;
    	int int_level=0;
    	
    	if(!_teacherType.isEmpty())
    	{
    		int_type=Integer.parseInt(_teacherType);
    	}
    	if(!_teacher_level.isEmpty())
    	{
    		int_level=Integer.parseInt(_teacher_level);
    	}
    	String modify_user=SecurityUtils.getCurrentUser().getUserId();
    	Teacher _tTeacher=new Teacher();
    	_tTeacher.setTEACHER_TYPE(int_type);
    	_tTeacher.setTEACHER_LEVEL(int_level);
    	_tTeacher.setEMP_NO(_emp_no);
    	_tTeacher.setEMP_NAME(_emp_name);
    	_tTeacher.setDEPT_NAME(_dept_name);
    	_tTeacher.setTEL_NO(_tel_no);
    	_tTeacher.setPHONE_NO(_phone_no);
    	_tTeacher.setE_MAIL(_email);
    	_tTeacher.setINTRODUCTION(_intro);
    	_tTeacher.setId(id);
    	_tTeacher.setMODIFY_USER(modify_user);
    	
    	
    	String success="";
    	if(teacherSrv.updTeacher(_tTeacher))
		{
			success="true";
		}
		else {
			success="false";
		}
		/*return	"{\"success\":\""+success+"\",\"msg\":\""+msg+"\"}";*/
    	return	"{\"success\":\""+success+"\"}";
    }
    
    
    
    /*刪除講師*/
    @RequestMapping(method=RequestMethod.POST,value="DelTeacher.spr")
	@ResponseBody
    public String DelTeacher(HttpServletRequest request)
    {
    	String _id=request.getParameter("teacherID");
    	String success="";
    	if(teacherSrv.delTeacher(_id))
    	{
    		success="true";
    	}
    	else {
    		success="false";
		}
    	return "{\"success\":\""+success+"\"}";
    }
}
