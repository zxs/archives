package com.foxconn.gds.sce.melp.examRoom.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface examRoomDao extends GenericDao<ExamRoom, String>{

	 
	List<ExamRoom> getqueryExamRoom(String paper_ID, String exam_Room_ID);

	List<ExamRoom> getqueryEmpnoandName(String paper_ID, String exam_Room_ID,
			String emp_Name, String emp_No);

	List<ExamRoom> getUpdateAndQuery(String paper_ID, String exam_Room_ID,
			String strExamAdd, String emp_No);

}
