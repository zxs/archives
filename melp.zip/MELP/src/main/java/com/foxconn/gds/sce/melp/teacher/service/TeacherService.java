package com.foxconn.gds.sce.melp.teacher.service;


import java.util.List;

import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.Teacher;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface TeacherService extends CrudService<Teacher> {

	public DataTableReturn findAllTeacher(DataTable dt,String userid);
	
	/*新增講師*/
	public Boolean addTeacher(Teacher p_teacher);
			
	/*判斷講師是否存在*/
	public  boolean isTeacherExist(Teacher p_teacher);
	
	public List<BaseCode> selTeacherType();
	
	public List<BaseCode> selTeacherLevel();
	
	
	/*根據ID查詢講師信息*/
	public Teacher selTeacherByID(Teacher p_teacher);
	
	/*更新講師*/
	public boolean updTeacher(Teacher p_teacher);
	
	/*刪除講師*/
	public boolean delTeacher(String p_id);
}
