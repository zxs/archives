package com.foxconn.gds.sce.melp.login;

import java.io.IOException;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.support.ClientUtil;

/**
 * @author: andres vega
 */

@Controller
@RequestMapping("/login/**")
public class LoginController {
	
    private Log log = LogFactory.getLog(LoginController.class);
    
    @RequestMapping(method = RequestMethod.GET, value = "login.spr")
    public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	// Detect Client Request from PC or MID
    	ModelAndView modelAndView=new ModelAndView();
    	Date date=new Date();
    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy"); 
    	String year = formatter.format(date); //将日期时间格式化 
    	modelAndView.addObject("year",year);
    	modelAndView.setViewName(ClientUtil.returnView(request, "login/login"));
    	return modelAndView;
    }
    
//    @RequestMapping(method = RequestMethod.GET, value = "loginFront.spr")
//    public ModelAndView LoginFront(HttpServletRequest request, HttpServletResponse response)
//    throws ServletException, IOException {
//    	// Detect Client Request from PC or MID
//    	ModelAndView modelAndView=new ModelAndView();
//    	Date date=new Date();
//    	SimpleDateFormat formatter = new SimpleDateFormat("yyyy"); 
//    	String year = formatter.format(date); //将日期时间格式化 
//    	modelAndView.addObject("year",year);
//    	modelAndView.setViewName("login/login");
//    	return modelAndView;
//    }

    @RequestMapping(method = RequestMethod.GET, value = "logout.spr")
    public ModelAndView logout(HttpSession session, Principal principal) {
    	log.info(" User: " + principal.getName() + " logout");
    	session.invalidate();
    	return new ModelAndView();
    }

    @RequestMapping(method = RequestMethod.GET, value = "loginFailure.spr")
    public ModelAndView loginFailure(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	//SecurityContextHolder.getContext().setAuthentication()
    	return new ModelAndView();
    }

    @RequestMapping(method = RequestMethod.GET, value = "home.spr")
    public ModelAndView welcome(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	//SecurityContextHolder.getContext().setAuthentication()
    	return new ModelAndView();
    }
    
    @RequestMapping(method = RequestMethod.GET, value = "changePassword.spr")
    public ModelAndView changePassword(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	//SecurityContextHolder.getContext().setAuthentication()
    	return new ModelAndView();
    }

    //added by Cube @120915
    @RequestMapping(method = RequestMethod.GET, value = "mdfInitPwd.spr")
    public ModelAndView mdfInitPwd(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    	
    	//SecurityContextHolder.getContext().setAuthentication()
    	return new ModelAndView();
    }
    
    
}