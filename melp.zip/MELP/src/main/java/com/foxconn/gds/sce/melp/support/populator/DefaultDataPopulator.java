package com.foxconn.gds.sce.melp.support.populator;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.model.Person;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.organization.service.OrganizationService;
import com.foxconn.gds.sce.melp.person.service.PersonService;
import com.foxconn.gds.sce.melp.role.service.RoleService;
import com.foxconn.gds.sce.melp.support.invoker.Task;
import com.foxconn.gds.sce.melp.user.service.UserService;


/**
 * @author: jperez
 */
@Component(value = "defaultDataPopulator")
public class DefaultDataPopulator implements Task {

    @Autowired
    private OrganizationService organizationService;
    
    @Autowired
    private RoleService roleService;
    
    @Autowired
    private PersonService personService;

	@Autowired
    private UserService userService;

//    @Autowired
//    private ExtCurricActivityService extCurricActivityService;

//    public void setPersonService(PersonService personService) {
//		this.personService = personService;
//	}
//
//	public void setContactService(ContactService contactService) {
//	}

    public void setOrganizationService(OrganizationService organizationService) {
        this.organizationService = organizationService;
    }
    
    
    public void setRoleService(RoleService roleService) {
		this.roleService = roleService;
	}

    

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

/*
    public void setExtCurricActivityService(ExtCurricActivityService extCurricActivityService) {
        this.extCurricActivityService = extCurricActivityService;
    }
*/
	
    public void execute(){
        Organization organization = createRootOrganization();
        createUsers(organization);
//        createExtCurricActivity();
        createPerson("root", "person", "root-person@melp.org", "563-1233");
        createPerson("student", "person", "student-person@melp.org", "563-1233");
        createPerson("teacher", "person", "teacher-person@melp.org", "563-1233");
        createPerson("counselor", "person", "counselor-person@melp.org", "563-1233");
        createPerson("admin", "person", "admin-person@melp.org", "563-1233");
        
    }

    private Organization createRootOrganization() {
        Organization organization = new Organization();
        organization.setDisplayName("Root");
        organization.setName("Root Organization");
        organizationService.create(organization);        
        return organization;
    }

    private void createUsers(Organization organization){
        Role rootRole = createOrganizationRole(organization, "Root");
        Role studentRole = createOrganizationRole(organization, "Student");
        Role teacherRole = createOrganizationRole(organization, "Teacher");
        Role adminRole = createOrganizationRole(organization, "Administrator");
        Role counselorRole = createOrganizationRole(organization, "Counselor");
        Role examineeRole = createOrganizationRole(organization, "Examinee");
        Role examinerRole = createOrganizationRole(organization, "Examiner");        

        createUser(rootRole, "root", "root");
        createUser(studentRole, "student", "student");
        createUser(teacherRole, "teacher", "teacher");
        createUser(counselorRole, "counselor", "counselor");
        createUser(adminRole, "admin", "admin");
        for(int i=0; i<5000; i++) {
        	createUser(examineeRole, "examinee-"+i, "examinee-"+i);
        }
        createUser(examinerRole, "examiner", "examiner");              
    }

    private Role createOrganizationRole(Organization organization, String roleName){
        Role role = new Role();
    	role.setName(roleName);
    	role.setOrganization(organization);
        role.setEntityCreationTimestamp(new Date());
    	roleService.create(role);
    	return role;
    }

    private void createUser(Role role, String username, String password){
        User user = new User();
        user.setUserId(username);
    	user.setUsername(username);
    	user.setPassword(password);
    	user.addRole(role);
        user.setEntityCreationTimestamp(new Date());
    	userService.create(user);
    }
  
	private Person createPerson(String firstName, String lastName, String email, String phoneNumber){
    	Person person = new Person();
    	person.setDeleted(false);
    	person.setFirstName(firstName);
    	person.setLastName(lastName);
        person.setEntityCreationTimestamp(new Date());
    	personService.create(person); 
    	return person;
    }
/*  
    private void createExtCurricActivity() {
        ExtCurricActivity extCurricActivity = new ExtCurricActivity();
        extCurricActivity.setDeleted(false);
        extCurricActivity.setDescription("Initial Extra Curricular Activity");
        extCurricActivity.setmelpCalendar(new melpCalendar());
        extCurricActivityService.create(extCurricActivity);
    }
*/

//    private EmailAddress createEmailAddress (String emailAddress){
//    	EmailAddress address = new EmailAddress(emailAddress);
//    	return address;
//    }
//
//    private PhoneNumber createPhoneNumber (String phoneNumber){
//    	PhoneNumber number = new PhoneNumber(phoneNumber);
//    	return number;
//    }



/*
    private void createTerm() {
        Term term = new Term();
        term.setName("Initial Term");
        //term.setParent(new Term());
        term.setScheduledStartDate(new Date());
        term.setScheduledStopDate(new Date());
        term.setDeleted(false);
        term.setOrganization(new Organization());
        term.setStatus(TermStatus.Active);
        termService.create(term);
    }
   */
}