package com.foxconn.gds.sce.melp.paper.service.impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.paper.dao.PaperDao;
import com.foxconn.gds.sce.melp.paper.service.PaperService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;
@Service(value = "paperService")
public class ImplPaperService extends CrudServiceImpl<PaperInfo, PaperDao> implements
		PaperService {

	private PaperDao ibPaperDao;

	@Autowired
	public void setIbPaperDao(PaperDao paperDao) {
		this.ibPaperDao = paperDao;
	}
	@Transactional
	public void InsertPaper(PaperInfo paperinfo) {
		ibPaperDao.InsertPaper(paperinfo);
	} 
	
	@Transactional(readOnly = true)
	@SuppressWarnings("unchecked")	
    public DataTableReturn ListAllPaper(DataTable dt,int roletype)
    {
    	DataTableReturn dtr = new DataTableReturn();
    	int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
		String username = SecurityUtils.getCurrentUser().getUserId();
		if(roletype!=0)
		    params.put("DT_USER", username.toUpperCase());	
		else
			params.put("DT_USER", "");
		params.put(DataTable.SEARCH, dt.getSearch());
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
    	PaginatedResult<PaperInfo> _listpaper= ibPaperDao.ListAllPaper(params, skipResults, maxResults);
    	dtr.setAaData(_listpaper.getResult());
		dtr.setiTotalDisplayRecords(_listpaper.getTotalResults());
		dtr.setiTotalRecords(_listpaper.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
    }
	
	@Transactional
	public void DeletePaper(List<PaperInfo>  paperInfo) {
	    ibPaperDao.DeletePaper(paperInfo);
	} 
	
	@Transactional
	public Boolean UpdatePaper(PaperInfo paperinfo) {
		return ibPaperDao.UpdatePaper(paperinfo)==1?true:false;
	}
	
	@Transactional(readOnly = true)
	public PaperInfo QueryPaperByPara(PaperInfo paperinfo)
	{
		return ibPaperDao.QueryPaperByPara(paperinfo);
	}
	
	@Transactional(readOnly = true)
	public PaperInfo QueryLibNumByID(PaperInfo paperinfo)
	{
		return ibPaperDao.QueryLibNumByID(paperinfo);
	}
	
	@Transactional(readOnly = true)
	public Boolean IsPaperExist(PaperInfo paperinfo)
	{
		Boolean flagbool=false;
		if(paperinfo.getId()=="")
		{
			flagbool= ibPaperDao.IsPaperExist(paperinfo)>0?true:false;
		}
		else
		{
			PaperInfo df=ibPaperDao.QueryPaperExist(paperinfo);
			Boolean flag=false;
			if(df.getPaperName().trim().equals(paperinfo.getPaperName().trim()))
				flag=true;
			if(flag)
		    	flagbool= false;
		    else
		    {
		    	flagbool= ibPaperDao.IsPaperExist(paperinfo)>0?true:false;
		    }
		}
	    return flagbool;
	}
	
	@Transactional(readOnly = true)
	public List<PaperInfo> QueryPaperNameID(PaperInfo paperinfo) 
	{
		return ibPaperDao.QueryPaperNameID(paperinfo);
	}
}
