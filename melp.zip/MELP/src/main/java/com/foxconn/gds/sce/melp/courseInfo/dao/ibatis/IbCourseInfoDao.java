package com.foxconn.gds.sce.melp.courseInfo.dao.ibatis;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.courseInfo.dao.CourseInfoDao;
import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.CourseInfo;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value = "ibCourseInfoDao")
public class IbCourseInfoDao extends GenericDaoIbatisImpl<CourseInfo, String>
implements CourseInfoDao{
	@Autowired
	public IbCourseInfoDao(SqlMapClient sqlMapClient) {
		super(CourseInfo.class);
		setSqlMapClient(sqlMapClient);
	}

	@Override
	public PaginatedResult<CourseInfo> ListAllCourseInfo(
			Map<String, Object> parameters, int skipResults, int maxResults) {
		// TODO Auto-generated method stub
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<CourseInfo> prPapers = new PaginatedResult<CourseInfo>(page, pageSize);
		List<CourseInfo> result=null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("getCourseInfoList", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("getCourseInfoList", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("getCourseInfoListCount", parameters);
		prPapers.setResult(result);
		prPapers.setTotalResults(count);
		return prPapers;
	}

	@Override
	public void saveOrUpdateCourseInfo(CourseInfo courseInfo) {
		// TODO Auto-generated method stub
		if(courseInfo.getId() == null || "".equals(courseInfo.getId())){
			courseInfo.setId(UUID.randomUUID().toString().replaceAll("-",""));
			getSqlMapClientTemplate().insert("insertCourseInfo", courseInfo);
		}else{
			getSqlMapClientTemplate().update("updateCourseInfo", courseInfo);
		}
		
	}

	@Override
	public List<BaseCode> getCourseTypeSelect() {
		// TODO Auto-generated method stub
		return getSqlMapClientTemplate().queryForList("getCourseTypeSelect");
	}

	@Override
	public CourseInfo getCourseInfoById(String id) {
		// TODO Auto-generated method stub
		return (CourseInfo) getSqlMapClientTemplate().queryForObject("getCourseInfoById", id);
	}

	@Override
	public void deleteCourseInfoById(List<String> courseId) {
		// TODO Auto-generated method stub
		HashMap<String,Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("courseId", courseId);
		/*paramsMap.put("updateUser", SecurityUtils.getCurrentUser().getUsername()); modified by lyl 20120903*/
		paramsMap.put("updateUser", SecurityUtils.getCurrentUser().getUserId());
		getSqlMapClientTemplate().update("deleteCourseInfoById", paramsMap);
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public void insertEvaluationItemsBatch(final List<EvaluationItems> evaluationItems) {
		// TODO Auto-generated method stub
		 if (evaluationItems != null) {
            this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
                public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
                   executor.startBatch();
                   for (int i = 0, n = evaluationItems.size(); i < n; i++) {
                	   evaluationItems.get(i).setId(UUID.randomUUID().toString().replaceAll("-",""));
                       executor.insert("insertEvaluationItems", evaluationItems.get(i));
                   }
                   executor.executeBatch();
                   return null;
                }
            });
         }
	
	}

	@Override
	public List<EvaluationItems> getEvaluationItemsByCourseId(String courseId) {
		// TODO Auto-generated method stub
		Map<String,Object> paramsMap = new HashMap<String, Object>();
		String userid=SecurityUtils.getCurrentUser().getUserId();
		Integer count=new Integer("0");
		paramsMap.put("courseId", courseId);
	if(SecurityUtils.examinerPlayedbyCurrentUser()){
		paramsMap.put("userno", userid);
		 count = (Integer)getSqlMapClientTemplate().queryForObject("getEvaluationItemsCount", paramsMap);
	}
		if(SecurityUtils.administratorPlayedbyCurrentUser()||(count==0&&courseId=="0")){
			userid="Admin";
			
		}//added by lyl 2012.8.21
		paramsMap.put("userid", userid);
		return this.getSqlMapClientTemplate().queryForList("getEvaluationItemsByCourseId", paramsMap);
	}


	@Override
	public void deleteEvaluationItems(String evCourseId) {
		// TODO Auto-generated method stub
		Map<String,Object> paramsMap = new HashMap<String, Object>();
		paramsMap.put("courseId", evCourseId);
		this.getSqlMapClientTemplate().update("deleteEvaluationItems", paramsMap);
	}


}
