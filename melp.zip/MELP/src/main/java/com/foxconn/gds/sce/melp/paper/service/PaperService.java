package com.foxconn.gds.sce.melp.paper.service;

import java.util.HashMap;
import java.util.List;

import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.service.CrudService;

public interface PaperService extends CrudService<PaperInfo> {
       public void InsertPaper(PaperInfo paperinfo);
       public DataTableReturn ListAllPaper(DataTable dt,int roletype);
       public void DeletePaper(List<PaperInfo>  paperInfo);
       public Boolean UpdatePaper(PaperInfo paperinfo);
       public PaperInfo QueryPaperByPara(PaperInfo paperinfo);
   	   public PaperInfo QueryLibNumByID(PaperInfo paperinfo);
       public Boolean IsPaperExist(PaperInfo paperinfo);
       public List<PaperInfo> QueryPaperNameID(PaperInfo paperinfo); 
}
