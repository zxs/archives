package com.foxconn.gds.sce.melp.model;

public class VO_QuestonOption extends BasicEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String questionLibId;
	private String questionType;
	private String questionTitle;
	private String priority;
	private String questionId;
	private String optionId;
	private String isRightAnswer;
	private String optionContent;
	
	
	public String getQuestionLibId() {
		return questionLibId;
	}
	public void setQuestionLibId(String questionLibId) {
		this.questionLibId = questionLibId;
	}
	
	
	public String getQuestionType() {
		return questionType;
	}
	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}
	
	
	public String getQuestionTitle() {
		return questionTitle;
	}
	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}

	
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	
	
	public String getQuestionId() {
        return questionId;
    }
    public void setQuestionId(String questionId) {
        this.questionId = questionId;
    }
    
    
    public String getOptionId() {
        return optionId;
    }
    public void setOptionId(String optionId) {
        this.optionId = optionId;
    }
    
    public String getIsRightAnswer() {
        return isRightAnswer;
    }
    public void setIsRightAnswer(String isRightAnswer) {
        this.isRightAnswer = isRightAnswer;
    }

    
    public String getOptionContent() {
        return optionContent;
    }
    public void setOptionContent(String optionContent) {
        this.optionContent = optionContent;
    }
    
    
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}
}
