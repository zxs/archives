package com.foxconn.gds.sce.melp.classManager;

import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.classManager.service.ClassManagerService;
import com.foxconn.gds.sce.melp.model.ClassInfo;
import com.foxconn.gds.sce.melp.model.ClassMember;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;

@Controller
@RequestMapping(value="/classManager/**")
public class ClassManagerController {

	@Autowired
	@Resource(name = "classManagerServiceImpl")
	private ClassManagerService classManagerServiceImpl;
	
	/**
	 * 點擊“班級管理”菜單，跳轉到班級管理頁面
	 * @param iframe
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET, value="listAllClass.spr")
	public ModelAndView listAllPapers(@RequestParam("iframe") String iframe) {
		return new ModelAndView("classManager/ListAllClass", "iframe", "true".equals(iframe)?"true":"false");
	}
	
	@RequestMapping(method=RequestMethod.GET, value="AddPaper.spr")
	public ModelAndView addPaper() {
		return new ModelAndView();
	}	
	
	/**
	 * 獲取所有班級信息列表
	 * @param dtjso
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST, value="classInfoList.spr")
	public @ResponseBody Object listAll(@RequestParam("_dt_json") String dtjso) {
		DataTable dt= JackJson.fromJsonToObject(dtjso,DataTable.class);
		int userType=-1;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			userType=0;
		}else if(SecurityUtils.examinerPlayedbyCurrentUser()){
			userType=1;
		}
		DataTableReturn returndt = classManagerServiceImpl.showAllClassInfoList(dt,userType);
		return returndt;
	}
	
	/**
	 * 查看班級信息
	 * 可用于點擊“預覽”按鈕，查看班級信息，也可用于點擊“修改”按鈕，顯示班級信息以進行修改操作
	 * @param request
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST, value="checkClassInfo.spr")
	public @ResponseBody ClassInfo checkClassInfo(HttpServletRequest request) {
		String classId = request.getParameter("id");
		ClassInfo classInfo = classManagerServiceImpl.checkClassInfo(classId);
		return classInfo;
	}
	
	/**
	 * 獲取班級編號
	 * 班級編號分為以下幾個部分，大寫字母C開頭，后接六位當前系統年月日，再以'-'連接自動增長的流水號
	 * @param request
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST, value="getAutoClassNo.spr")
	public @ResponseBody ClassInfo getAutoClassNo(HttpServletRequest request) {
		ClassInfo classInfo = classManagerServiceImpl.getAutoClassNo();
		return classInfo;
	}
	
	/**
	 * 新增班級信息
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="saveClassInfo.spr")
	public Map<String, String> saveClassInfo(HttpServletRequest request) {
		ClassInfo classInfo=new ClassInfo();
		String id =String.valueOf(UUID.randomUUID()).replace("-", "");
		classInfo.setClassId(id);
    	classInfo.setClassNo(request.getParameter("classNo"));
    	classInfo.setClassName(request.getParameter("className"));
    	classInfo.setStartTime(request.getParameter("startTime"));
    	classInfo.setEndTime(request.getParameter("endTime"));
    	
    	classInfo.setCourseId(request.getParameter("courseId1"));
        String currentUser=SecurityUtils.getCurrentUser().getUserId();
        
    	classInfo.setCreateUser(currentUser.toUpperCase());
    	Map<String, String> toJson = new HashMap<String, String>();
    	try {
    		classManagerServiceImpl.saveClassInfo(classInfo);
    		toJson.put("status", "true");
        	toJson.put("msg", "新增班級信息成功");
		} catch (Exception e) {
			e.printStackTrace();
			toJson.put("status", "false");
        	toJson.put("msg", "新增班級信息失敗");
		}
		return toJson;
	}
	
	/**
	 * 修改班級信息
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="submitUpdate.spr")
	public Map<String, String> updateClassInfo(HttpServletRequest request) {
		ClassInfo classInfo=new ClassInfo();
    	classInfo.setClassId(request.getParameter("classId1"));
		classInfo.setClassNo(request.getParameter("classNo"));
    	classInfo.setClassName(request.getParameter("className"));
    	classInfo.setStartTime(request.getParameter("startTime"));
    	classInfo.setEndTime(request.getParameter("endTime"));
    	
    	classInfo.setCourseId(request.getParameter("courseId1"));
    	
        String currentUser=SecurityUtils.getCurrentUser().getUserId();
        
    	classInfo.setModifyUser(currentUser.toUpperCase());
    	Map<String, String> toJson = new HashMap<String, String>();
    	try {
    		classManagerServiceImpl.updateClassInfo(classInfo);
    		toJson.put("status", "true");
        	toJson.put("msg", "修改班級信息成功");
		} catch (Exception e) {
			e.printStackTrace();
			toJson.put("status", "false");
        	toJson.put("msg", "修改班級信息失敗");
		}
		return toJson;
	}
	
	/**
	 * 刪除班級信息
	 * @param request
	 * @return
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="deleteClassInfo.spr")
	public Map<String, String> deleteClassInfo(
			HttpServletRequest request) {
		ClassInfo classInfo=new ClassInfo();
		 String currentUser = null;
		Map<String, String> toJson = new HashMap<String, String>();
		String idString = request.getParameter("classId");
		String idStr = idString.substring(0, idString.length()-1);
		classInfo.setClassId(idStr);
	        currentUser=SecurityUtils.getCurrentUser().getUserId();
	    	classInfo.setModifyUser(currentUser.toUpperCase());
	    	
	    	try {
	    		classManagerServiceImpl.deleteClassInfo(classInfo);
	    		toJson.put("status", "true");
	        	toJson.put("msg", "刪除班級信息成功");
			} catch (Exception e) {
				toJson.put("status", "false");
	        	toJson.put("msg", "刪除班級信息失敗");
			}
		return toJson;
	}
	
	/**
	 * 判斷班級編號是否已經存在
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="isClassNoExist.spr")
	public Map<String, String> isClassNoExist(HttpServletRequest request) throws UnsupportedEncodingException 
	{
		String classNo = request.getParameter("classNo");
		Map<String, String> reHashMap=new HashMap<String, String>();
		if(classManagerServiceImpl.isClassNoExist(classNo))
			reHashMap.put("status", "true");
		else 
			reHashMap.put("status", "false");
		return reHashMap;
	}
	
	/**
	 * 判斷修改之后的班級編號是否已經存在,用于修改班級信息
	 * 
	 * @param request
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="isClassNoExistForUpdate.spr")
	public Map<String, String> isClassNoExistForUpdate(HttpServletRequest request) throws UnsupportedEncodingException 
	{
		String classNo = request.getParameter("classNo");
		String classId = request.getParameter("classId");
		Map<String, String> reHashMap=new HashMap<String, String>();
		if(classManagerServiceImpl.isClassNoExistForUpdate(classNo,classId))
			reHashMap.put("status", "true");
		else 
			reHashMap.put("status", "false");
		return reHashMap;
	}
	
	/**
	 * 獲取指定班級的學員列表
	 * @param dtjso
	 * @param req
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST, value="studentList.spr")
	public @ResponseBody Object ListAllExaminees(@RequestParam("_dt_json") String dtjso,HttpServletRequest request) {
		DataTable dt= JackJson.fromJsonToObject(dtjso,DataTable.class);
		String classId = request.getParameter("classId");
		DataTableReturn returndt=classManagerServiceImpl.getStudentListByClassId(dt,classId);
		return returndt;
	}
	
	/**
	 * 添加學員名單到指定的班級中
	 * @param req
	 * @return
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="addPersonToClass.spr")
	public Map<String, String> addPersonToClass(HttpServletRequest request) {
		Map<String, String> reHashMap=new HashMap<String, String>();
		try {
			String personArr = request.getParameter("personArr");
			String classId = request.getParameter("classId");
			ObjectMapper mapper = new ObjectMapper();
			List<String> Str = mapper.readValue(personArr,List.class);
			List<ClassMember> list = new LinkedList<ClassMember>();
			ClassMember classMember=null;
			String createUser = SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<Str.size();i++){
				classMember = new ClassMember();
				String id =String.valueOf(UUID.randomUUID()).replace("-", "");
				classMember.setId(id);
				classMember.setEmpNo(Str.get(i).toString());
				classMember.setClassId(classId);
				classMember.setCreateUser(createUser);
				list.add(classMember);
			}
			classManagerServiceImpl.addPersonToClass(list);
			reHashMap.put("status", "true");
	        reHashMap.put("msg","添加學員成功");
		} catch (Exception e) {
			reHashMap.put("status", "false");
	        reHashMap.put("msg","添加學員失敗");
		}
		return reHashMap;
	}
	
	/**
	 * 從班級學員名單中刪除學員
	 * @param req
	 * @return
	 */
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST, value="delClassMemberFromClass.spr")
	public Map<String, String> delClassMemberFromClass(HttpServletRequest request) {
		Map<String, String> reHashMap=new HashMap<String, String>();
		try {
			String id =  request.getParameter("personArr");
			ObjectMapper mapper = new ObjectMapper();
			List<String> Str = mapper.readValue(id,List.class);
			List<ClassMember> classMemberList = new LinkedList<ClassMember>();
			ClassMember classMember = null;
			String modifyUser = SecurityUtils.getCurrentUser().getUserId().toUpperCase();
			for(int i=0;i<Str.size();i++){
				classMember = new ClassMember();
				classMember.setId(Str.get(i).toString());
				classMember.setModifyUser(modifyUser);
				classMemberList.add(classMember);
			}
			classManagerServiceImpl.delClassMemberFromClass(classMemberList);
		    reHashMap.put("status", "true");
		    reHashMap.put("msg", "刪除成功");
		} catch (Exception e) {
			reHashMap.put("status", "false");
	        reHashMap.put("msg", "刪除失敗");
		}
	    return reHashMap;
	}
	
	/**
	 * 導出班級學員名單
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(method=RequestMethod.GET, value="exportClassMember.spr")
	public ModelAndView exportClassMember(HttpServletRequest request,HttpServletResponse response) {
		String classId = request.getParameter("classId");
		Integer count = 0;
		try {
			List<ClassMember> classMemberList = classManagerServiceImpl.exportClassMember(classId);
			OutputStream fout =response.getOutputStream();
			response.reset();
            String filename="student.xls";
            response.setContentType("application/vnd.ms-excel");
            response.setHeader("Content-Disposition", "attachment;filename="+ new String(filename.getBytes(), "ISO8859-1"));
		
			HSSFWorkbook wb = new HSSFWorkbook();
		    HSSFSheet sheet = wb.createSheet("學員名單");
		    HSSFRow row = sheet.createRow((int)0);
		    HSSFCellStyle style = wb.createCellStyle();
	        style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			HSSFCell cell = row.createCell(0);
	        cell.setCellValue("工號"); cell.setCellStyle(style);
	        cell = row.createCell(1);
	        cell.setCellValue("姓名"); cell.setCellStyle(style);
	        cell = row.createCell(2);
	        cell.setCellValue("部門"); cell.setCellStyle(style);
	        cell = row.createCell(3);
	        cell.setCellValue("角色"); cell.setCellStyle(style);
	        cell = row.createCell(4);
	        cell.setCellValue("班級"); cell.setCellStyle(style);
	        for(int i=0;i<classMemberList.size();i++){
	            row = sheet.createRow((int)i+1);
	            ClassMember classMember = (ClassMember) classMemberList.get(i);
	            row.createCell(0).setCellValue(classMember.getEmpNo());
	            row.createCell(1).setCellValue(classMember.getUserName());
	            row.createCell(2).setCellValue(classMember.getDeptName());
	            row.createCell(3).setCellValue(classMember.getRoleName());
	            row.createCell(4).setCellValue(classMember.getClassName());
	        }
            wb.write(fout);
            fout.close();
		}
		catch(Exception e)
		{}
		return new ModelAndView();
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET, value="getCourseInfo.spr")
	public ClassInfo getCourseInfoById(HttpServletRequest request) {
		String courseId = request.getParameter("id");
		ClassInfo courseInfo = new ClassInfo();
		courseInfo.setCourseId(courseId);
		return classManagerServiceImpl.getCourseInfoById(courseInfo);
	}
}
