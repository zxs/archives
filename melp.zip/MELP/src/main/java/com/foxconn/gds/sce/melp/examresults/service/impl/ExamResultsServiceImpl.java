package com.foxconn.gds.sce.melp.examresults.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.foxconn.gds.sce.melp.examresults.dao.ExamResultsDao;
import com.foxconn.gds.sce.melp.examresults.service.ExamResultsService;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value="examResultsService")
public class ExamResultsServiceImpl extends CrudServiceImpl<ExamResults, ExamResultsDao> implements ExamResultsService {
	@Autowired
	public void setIbExamResultsDao(ExamResultsDao examResultsDao){
		this.daoSupport=examResultsDao;
	}
	
	
   
    public List<ExamResults> listExamResults(ExamResults examResult)
    {
    	return (List<ExamResults>) daoSupport.listExamResults(examResult);
    }
    public Paper showPaperTitle(HashMap hashMap)
    {
    	return (Paper) daoSupport.showPaperTitle(hashMap);
    }
    public List<Paper> showPaperContent_S(HashMap hashMap)
    {
    	return (List<Paper>) daoSupport.showPaperContent_S(hashMap);
		
	}
    public List<Paper> showPaperContent_M(HashMap hashMap)
    {
    	return (List<Paper>) daoSupport.showPaperContent_M(hashMap);
		
	}
    public List<Paper> showPaperContent_TF(HashMap hashMap)
    {
    	return (List<Paper>) daoSupport.showPaperContent_TF(hashMap);
		
	}


	public DataTableReturn listExamResults4DT(DataTable dt) {
		DataTableReturn dtr = new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		String userid=SecurityUtils.getCurrentUser().getUserId();
		boolean isManager=SecurityUtils.administratorPlayedbyCurrentUser();
		String manager="";
		if(isManager)
		{
			manager=null;
		}
		Map params = new HashMap();
		params.put("creator", userid);
		params.put("manager", manager);
		params.put(DataTable.SEARCH, dt.getSearch());
		for( SortInfo sInfo : dt.getSortInfo() ) {
			params.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		PaginatedResult<ExamResults> users = daoSupport.listExamResults( params, skipResults, maxResults);
		
		dtr.setAaData(users.getResult());
		dtr.setiTotalDisplayRecords(users.getTotalResults());
		dtr.setiTotalRecords(users.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

    
	
}
