package com.foxconn.gds.sce.melp.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.SpringSessionContext;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.SpringSecurityMessageSource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.user.service.UserService;

@Controller
@RequestMapping("/security/**")
public class SecurityController {
	
	
	
	@RequestMapping(method = RequestMethod.GET, value = "permissionCatalog.spr")
	public ModelAndView showPermissionCatalog(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();
		// Object principal = authentication.getPrincipal();
		// Object details = authentication.getDetails();

		ModelAndView mvc = new ModelAndView();
		return mvc;
	}

	@RequestMapping(method = RequestMethod.GET, value = "accessDenied.spr")
	public ModelAndView showAccessDenied(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		Authentication authentication = SecurityContextHolder.getContext()
				.getAuthentication();
		// Object principal = authentication.getPrincipal();
		// Object details = authentication.getDetails();

		ModelAndView mvc = new ModelAndView();
		return mvc;
	}

}
