package com.foxconn.gds.sce.melp.model;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;

/**
 * 课程model
 * @author F3226075
 *
 */
public class CourseInfo extends BasicEntity{
	/**
	 * Column:ID
	 * 主键ID
	 */
	public String id ;
	/**
	 * Column:COURSE_NAME
	 * 课程名称
	 */
	public String courseName;
	/**
	 * Column:COURSE_TYPE
	 * 课程类型
	 */
	public String courseType;
	/**
	 * Column:TEACHER_ID
	 * 讲师ID
	 */
	public String teacherId;
	/**
	 * Column: COURSEWARE_URL
	 * 课件URL
	 */
	public String coursewareUrl;
	/**
	 * Column:COURSE_HOUR
	 * 课时
	 */
	public String courseHour;
	/**
	 * Column:OWNER
	 * 制作人
	 */
	public String owner;
	/**
	 * Column:OWNER_DEPT
	 * 制作单位
	 */
	public String ownerDept;
	/**
	 * Column:EV_SETTINGS
	 * 评估问卷设置
	 */
	public String evSettings;
	/**
	 * Column:COURSE_SUMMERY
	 * 课程介绍
	 */
	public String courseSummary;
	/**
	 * Column:CREATE_DATE
	 * 创建时间
	 */
	public String createDate;
	/**
	 * Column:CREATE_USER
	 * 创建人
	 */
	public String createUser;
	/**
	 * Column:MODIFY_DATE
	 * 修改日期
	 */
	public String modifyDate;
	/**
	 * Column:MODIFY_USER
	 * 修改人
	 */
	public String modifyUser;
	/**
	 * Column:IS_ENABLE
	 * 是否有效
	 */
	public String isEnable;
	/**
	 * 讲师名称
	 */
	public String empName;
	/**
	 * 类型名称
	 */
	public String codeName;
	
	/**
	 * add by Hualing Wei
	 * @return
	 */
	public String resultId;
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseType() {
		return courseType;
	}

	public void setCourseType(String courseType) {
		this.courseType = courseType;
	}

	public String getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}

	public String getCoursewareUrl() {
		return coursewareUrl;
	}

	public void setCoursewareUrl(String coursewareUrl) {
		this.coursewareUrl = coursewareUrl;
	}

	public String getCourseHour() {
		return courseHour;
	}

	public void setCourseHour(String courseHour) {
		this.courseHour = courseHour;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getOwnerDept() {
		return ownerDept;
	}

	public void setOwnerDept(String ownerDept) {
		this.ownerDept = ownerDept;
	}

	public String getEvSettings() {
		return evSettings;
	}

	public void setEvSettings(String evSettings) {
		this.evSettings = evSettings;
	}

	public String getCourseSummary() {
		return courseSummary;
	}

	public void setCourseSummary(String courseSummary) {
		this.courseSummary = courseSummary;
	}

	public String getCreateDate() {
		return createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getModifyDate() {
		return modifyDate;
	}

	public void setModifyDate(String modifyDate) {
		this.modifyDate = modifyDate;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

	public String getIsEnable() {
		return isEnable;
	}

	public void setIsEnable(String isEnable) {
		this.isEnable = isEnable;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getCodeName() {
		return codeName;
	}

	public void setCodeName(String codeName) {
		this.codeName = codeName;
	}
	public String getResultId() {
		return resultId;
	}

	public void setResultId(String resultId) {
		this.resultId = resultId;
	}
	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

	public String toString(){
		return ReflectionToStringBuilder.toString(this);
	}
}
