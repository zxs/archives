package com.foxconn.gds.sce.melp.roomRecord.dao.ibatis;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.roomRecord.dao.ExamineesRecordDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value="ibexineesRecordDao")
public class IbExamineesRecordDao extends GenericDaoIbatisImpl<Examinees, String> implements ExamineesRecordDao {

	@Autowired
	public IbExamineesRecordDao(SqlMapClient sqlMapClient) {
		super(Examinees.class);
		setSqlMapClient(sqlMapClient);
	}
	

	public void update(Examinees transientObject) {
		// TODO Auto-generated method stub
		getSqlMapClientTemplate().update("update_examinees", transientObject);
	}

	public List<Examinees> Query_ExamineesByRoomid(Examinees examinees) {		
		List<Examinees> nees=getSqlMapClientTemplate().queryForList("select _by_roomId",examinees);
		return nees;
	}
	
	@SuppressWarnings("unchecked")
	public boolean updateExamInees(final List<Examinees> examinees) {
		 try {
	           if (examinees != null) {
	              this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
	                  public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
	                     executor.startBatch();
	                     for (int i = 0, n = examinees.size(); i < n; i++) {
	                         executor.update("update_examinees", examinees.get(i));
	                     }
	                     executor.executeBatch();
	                     return true;
	                  }
	              });
	           }
	       } catch (Exception e) {
	    	   	return false;
	       }
		return true;
	}

}
