package com.foxconn.gds.sce.melp.roomRecord_b.service.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.roomRecord_b.dao.roomRecord_bDao;
import com.foxconn.gds.sce.melp.roomRecord_b.service.roomRecord_bService;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service(value = "roomRecord_bService")
@Transactional
public class roomRecord_bServiceImpl extends
		CrudServiceImpl<ExamRoom, roomRecord_bDao> implements
		roomRecord_bService {

	@Autowired
	/* @Qualifier("hi1") */
	public void setroomRecord_bDao(roomRecord_bDao dao) {
		this.daoSupport = dao;
	}

	public void create(ExamRoom entity) {
		// TODO Auto-generated method stub

	}

	public void update(ExamRoom entity) {
		// TODO Auto-generated method stub

	}

	public void delete(ExamRoom entity) {
		// TODO Auto-generated method stub

	}

	public ExamRoom read(String entityId) {
		// TODO Auto-generated method stub
		return null;
	}

	public DataTableReturn listForDT(DataTable dt,int userType) {
		DataTableReturn dtr = new DataTableReturn();
		int skipResults = dt.getDisplayStart();
		int maxResults = dt.getDisplayLength();
		Map params = new HashMap();
	    String username = SecurityUtils.getCurrentUser().getUserId();
		params.put(DataTable.SEARCH, dt.getSearch());
		 if(userType!=0)
		        params.put("DT_USER",username);
		    else
		    	params.put("DT_USER","");
		for (SortInfo sInfo : dt.getSortInfo()) {
			params.put(DataTable.ORDER_COLUMN_SORT, sInfo.getColumnId() + " "
					+ sInfo.getSortOrder());
		}

		PaginatedResult<ExamRoom> ExamRooms = daoSupport.list(params,
				skipResults, maxResults);

		dtr.setAaData(ExamRooms.getResult());
		dtr.setiTotalDisplayRecords(ExamRooms.getTotalResults());
		dtr.setiTotalRecords(ExamRooms.getTotalResults());
		dtr.setsEcho(dt.getEcho());
		return dtr;
	}

}
