package com.foxconn.gds.sce.melp.makeup.dao;

import java.util.HashMap;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface MakeupDao extends GenericDao<ExamInfo, String> {

	public PaginatedResult<HashMap<String, String>> getListForDataTable(
			Map<String, String> parameterMap, int skipResults, int maxResults);

	public PaginatedResult<HashMap<String, String>> getMakeupInfoForDataTable(
			Map<String, String> parameterMap, int skipResults, int maxResults);

	public void addMakeupTimes(String id);

	public void reduceMakeupTimes(String id);

}
