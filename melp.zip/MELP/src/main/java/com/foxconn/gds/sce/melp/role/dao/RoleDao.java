package com.foxconn.gds.sce.melp.role.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

/**
 * User: ronvargas
 * Date: Feb 11, 2009
 */
public interface RoleDao extends GenericDao<Role, String> {

        /**
     * Retrieves a role
     *
     * @param roleId role id
     * @return A Role Object
     */
    Role getRole(String roleId);

    /**
     * Retrieves a Role list identified by the specified name (many roles can have the same name across organizations)
     *
     * @param name role name
     * @return A role list
     */
    List<Role> getRolesByName(final String name);

    /**
     * get Roles associated to this Organization object
     *
     * @param organization Organization
     * @return A role list
     */
    List<Role> getRolesByOrganization(final Organization organization);

    /**
     * get Roles associated to this Organization id
     *
     * @param organizationId Organization id
     * @return A role list
     */
    List<Role> getRolesByOrganizationId(final String organizationId);

    /**
     * get Roles associated to this Organization name
     *
     * @param organizationName Organization name
     * @return A role list
     */
    List<Role> getRolesByOrganizationName(final String organizationName);
}
