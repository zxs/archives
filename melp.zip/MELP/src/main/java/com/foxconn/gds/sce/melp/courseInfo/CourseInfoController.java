package com.foxconn.gds.sce.melp.courseInfo;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.courseInfo.service.CourseInfoService;
import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.CourseInfo;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.user.UserController;

@Controller
@RequestMapping(value = "/courseInfo/**")
public class CourseInfoController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
	
	@Resource(name = "courseInfoService")
	public CourseInfoService courseInfoService; 
//	@Autowired
//	public void setCourseInfoService(CourseInfoService courseInfoService){
//		this.courseInfoService = courseInfoService;
//	}
	
	@RequestMapping(method=RequestMethod.GET,value = "showCourseInfo.spr")
	public ModelAndView showCourseInfo(String iframe){
		return new ModelAndView("courseInfo/courseMain","iframe","true".equals(iframe)?"true":"false");
	}
	
	@RequestMapping(method=RequestMethod.POST, value="getCourseInfoList.spr")
	public @ResponseBody Object getCourseInfoList(@RequestParam("_dt_json") String dtjson){
		logger.info("String dtjson=" + dtjson);
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn = this.courseInfoService.ListAllCourseInfo(dataTable);
		return tableReturn;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST,value = "saveOrUpdateCourseInfo.spr")
	public Map<String,Object> saveOrUpdateCourseInfo(HttpServletRequest req) throws Exception{
		CourseInfo courseInfo = new CourseInfo();
		courseInfo.setId(req.getParameter("id"));
		courseInfo.setCourseName(req.getParameter("courseName"));
		courseInfo.setCourseType(req.getParameter("courseType"));
		courseInfo.setCourseHour(req.getParameter("courseHour"));
		courseInfo.setTeacherId(req.getParameter("teacherId"));
		courseInfo.setCourseSummary(req.getParameter("courseSummary"));
		courseInfo.setOwner(req.getParameter("owner"));
		courseInfo.setOwnerDept(req.getParameter("ownerDept"));
		courseInfo.setEvSettings(req.getParameter("evSettings"));
		courseInfo.setCoursewareUrl(req.getParameter("coursewareUrl"));
		courseInfo.setEvSettings(req.getParameter("evSettings"));
		System.out.println("i am here = " + courseInfo);
		Map<String,Object> paramMap = new HashMap<String, Object>();
		
//		System.out.println(request.getFile("evaluationItems").getName());
		
		/*MultipartFile file = request.getFile("evaluationItems");
		if(!file.isEmpty() && file != null && req.getParameter("evSettings").equals("2")){	//必須是自定義模板情況且已經上傳了附件的情況下
			Object object = this.courseInfoService.inputStudentInfoExcel(file.getInputStream(),req.getParameter("evSettings"),req.getParameter("id"));
			if(object instanceof String){
				paramMap.put("msg", (String)object);
				paramMap.put("flag", "false");
				return paramMap;
			}else if (object instanceof List){
				@SuppressWarnings("unchecked")
				List<EvaluationItems> list = (List<EvaluationItems>)object;
				this.courseInfoService.insertEvaluationItemsBatch(list);
			}
		}*/
		
		try {
			this.courseInfoService.saveOrUpdateCourseInfo(courseInfo);
			paramMap.put("flag", "true");
			paramMap.put("msg", "課程信息保存成功");
			paramMap.put("courseId", courseInfo.getId());
		} catch (Exception e) {
			// TODO: handle exception
			paramMap.put("flag", "false");
			paramMap.put("msg", "操作失敗");
		}
		return paramMap;
	}
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET,value = "getCourseTypeSelect.spr")
	public List<BaseCode> getCourseTypeSelect(){
		List<BaseCode> list = this.courseInfoService.getCourseTypeSelect();
		return list;
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.GET,value = "getCourseInfoById.spr")
	public CourseInfo getCourseInfoById(String id){
		return this.courseInfoService.getCourseInfoById(id);
	}
	
	@ResponseBody
	@RequestMapping(method=RequestMethod.POST,value = "deleteCourseInfoById.spr")
	public Map<String,Object> deleteCourseInfoById(String courseId){
		Map<String,Object> paramMap = new HashMap<String, Object>();
		try {
			this.courseInfoService.deleteCourseInfoById(courseId);
			paramMap.put("flag", "true");
			paramMap.put("msg", "操作成功");
		} catch (Exception e) {
			// TODO: handle exception
			paramMap.put("flag", "false");
			paramMap.put("msg", "操作失敗");
		}
		return  paramMap;
	}
	
	
	@RequestMapping(method=RequestMethod.POST,value = "insertEvaluationItemsBatch.spr")
	public String insertEvaluationItemsBatch(MultipartHttpServletRequest request,String evCourseId,Model model) throws Exception{
		Map<String,Object> paramsMap = new HashMap<String,Object>();
		MultipartFile file = request.getFile("evaluationItems");
		if(!file.isEmpty() && file != null){	//必須是自定義模板情況且已經上傳了附件的情況下
			Object object = this.courseInfoService.inputStudentInfoExcel(file.getInputStream(),evCourseId);
			if(object instanceof String){
//				paramsMap.put("msg", );
				model.addAttribute("msg", "課程保存成功,上傳評價項失敗! " +(String)object);
				paramsMap.put("flag", "false");
				 
			}else if (object instanceof List){
				@SuppressWarnings("unchecked")
				List<EvaluationItems> list = (List<EvaluationItems>)object;
				this.courseInfoService.deleteEvaluationItems(evCourseId);
				this.courseInfoService.insertEvaluationItemsBatch(list);
				model.addAttribute("msg", "課程保存成功,上傳評價項成功");
				model.addAttribute("flag", "true");
			}
		}
		model.addAttribute("courseId", evCourseId);
		return "/courseInfo/import-evaluation";
	}
	
	@RequestMapping(method=RequestMethod.GET,value = "getUploadPage.spr")
	public String getUploadPage(Model model,String courseId){
		model.addAttribute("courseId", courseId);
		return "courseInfo/import-evaluation";
	}
	
	@RequestMapping(method=RequestMethod.GET,value = "/getEvaluationModel.spr")
	public void getEvaluationModel(HttpServletResponse response) throws IOException{
		Workbook workbook = new HSSFWorkbook();
		Sheet sheet = workbook.createSheet("evaluationItems");
		String[] title = { "評估部份", "項目"};
		Row titleRow = sheet.createRow((short) 0);
		int i = 0;
		for (String label : title) {
			Cell cell = titleRow.createCell(i);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(label);
			i++;
		}

		String fileName = "Evaluation Template.xls";

		response.setContentType("application/vnd.ms-excel; charset=utf-8");
		response.addHeader("Content-Disposition", "attachment;filename="
				+ fileName);

		OutputStream os = response.getOutputStream();
		workbook.write(os);
		os.flush();
		os.close();
	}
	
	@RequestMapping(method = RequestMethod.GET,value = "getEvaluationsItemsPreview.spr")
	public void getEvaluationsItemsPreview(HttpServletResponse response,String courseId) throws IOException{
		Workbook workbook = new HSSFWorkbook();
		Sheet sheet = workbook.createSheet("evaluationItems");
		String[] title = { "評估部份", "項目"};
		Row titleRow = sheet.createRow((short) 0);
		int i = 0;
		for (String label : title) {
			Cell cell = titleRow.createCell(i);
			cell.setCellType(HSSFCell.CELL_TYPE_STRING);
			cell.setCellValue(label);
			i++;
		}
		List<EvaluationItems> list = this.courseInfoService.getEvaluationItemsByCourseId(courseId);
		int j = 1;
		for(EvaluationItems items : list){
			Row cellRow = sheet.createRow((short)j);
			Cell partNameCell = cellRow.createCell(0);
			partNameCell.setCellType(HSSFCell.CELL_TYPE_STRING);
			partNameCell.setCellValue(items.getPartName());
			Cell contentCell = cellRow.createCell(1);
			contentCell.setCellType(HSSFCell.CELL_TYPE_STRING);
			contentCell.setCellValue(items.getContent());
			j++;
		}

		String fileName = "Evaluation PreView.xls";

		response.setContentType("application/vnd.ms-excel; charset=utf-8");
		response.addHeader("Content-Disposition", "attachment;filename="
				+ fileName);

		OutputStream os = response.getOutputStream();
		workbook.write(os);
		os.flush();
		os.close();
	}
	
	@RequestMapping(method=RequestMethod.GET, value="showPlayer.spr")
    public ModelAndView showPlayer(HttpServletRequest request) 
    {
		//request.getParameter("URL")
		return new ModelAndView("courseInfo/player").addObject("URL",request.getParameter("URL"));
		}
}
