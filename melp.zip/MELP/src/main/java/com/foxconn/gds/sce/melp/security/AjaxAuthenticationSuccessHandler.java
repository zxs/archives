/**
 * 
 */
package com.foxconn.gds.sce.melp.security;

import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationSuccessHandler;

/**
 * @author f3220873
 * 
 */
public class AjaxAuthenticationSuccessHandler extends
		SimpleUrlAuthenticationSuccessHandler {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.security.web.authentication.AuthenticationSuccessHandler
	 * #onAuthenticationSuccess(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse,
	 * org.springframework.security.core.Authentication)
	 */
	public void onAuthenticationSuccess(HttpServletRequest req,
			HttpServletResponse resp, Authentication auth) throws IOException,
			ServletException {
		if ("XMLHttpRequest".equals(req.getHeader("X-Requested-With"))) {
			Writer writer = resp.getWriter();
			
			Map<String, Object> toJson = new HashMap<String, Object>();
			toJson.put("success", true);
			toJson.put("targetUrl", this.getDefaultTargetUrl());			
			toJson.put("principalName", auth.getName());
			toJson.put("permissions", auth.getAuthorities().toString());
			
			ObjectMapper oM = new ObjectMapper();
			oM.writeValue(writer, toJson);
			
			writer.flush();
		} else {
			super.onAuthenticationSuccess(req, resp, auth);
		}
	}

}
