package com.foxconn.gds.sce.melp.sample.dao;

import java.util.List;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;

public interface SampleDao extends GenericDao<User, String> {
	
	List<User> listByNull();
	// listBy , iterateBy, scorllBy
	
    User listBySifRefId(final String sifRefId);
}
