package com.foxconn.gds.sce.melp.fdownloadpaper.dao.ibatis;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.model.VO_ExamineesInfo;
import com.foxconn.gds.sce.melp.model.VO_RolePermission;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibDownloadPaperDao")
public class IbDownloadPaperDao extends GenericDaoIbatisImpl<ExamRoom, String> 
implements DownloadPaperDao {

	@Autowired
    public IbDownloadPaperDao(SqlMapClient sqlMapClient) {
		super(ExamRoom.class);
		setSqlMapClient(sqlMapClient);
	}

	/*
	 *列出所有可下載的考場考卷
	 */
	public List<ExamRoom> listByUser(String loginUserEmpNo) {
		Object resultObject=getSqlMapClientTemplate().queryForList("listExamRooms", loginUserEmpNo);
		return (List<ExamRoom>) resultObject;
	}
	
	/*
	 * 管理員列出所有考場考卷
	 */
	public List<ExamRoom> listByAdmin(){
		Object resultObject=getSqlMapClientTemplate().queryForList("fDownload.listExamRoomsByAdmin");
		return (List<ExamRoom>) resultObject;
	}
	
	/*
	 * 查詢考場信息By ID
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#ListByRoomId(java.lang.String)
	 */
	public ExamRoom ListByRoomId(String examRoomId){
		Object resultObject=getSqlMapClientTemplate().queryForObject("listExamRoomsById", examRoomId);
		return (ExamRoom) resultObject;
	}
	
	/*
	 *列出對應考場的考生信息
	 */
	public List<Examinees> getExamineedList(String examRoomId){
		Object examineesList=getSqlMapClientTemplate().queryForList("listExamineesInfoByRoomId", examRoomId);
		return (List<Examinees>)examineesList;
	}
	
	/*
	 * 列出所有菜單權限信息
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#listAllRolePermissions()
	 */
	public List<VO_RolePermission> listAllRolePermissions(){
		Object examineesList=getSqlMapClientTemplate().queryForList("listRolePermission", null);
		return (List<VO_RolePermission>) examineesList;
	}

	/*
	 * 查詢對應考卷信息
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#listPaperInfo(java.lang.String)
	 */
	public PaperInfo listPaperInfo(String paperId) {
		Object examineesList=getSqlMapClientTemplate().queryForObject("selectPaperInfoByPaperId", paperId);
		return (PaperInfo) examineesList;
	}

	/*
	 * 查詢考卷試題庫所有試題
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#listQuestions(java.lang.String)
	 */
	public List<Question> listQuestions(String paperId) {
		Object examineesList=getSqlMapClientTemplate().queryForList("listQuestionsByPaperId", paperId);
		return (List<Question>)examineesList;
	}

	/*
	 * 查詢試題庫試題所有試題選項
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#listQuestionOptions(java.lang.String)
	 */
	public List<QuestionOptions> listQuestionOptions(String paperId) {
		Object examineesList=getSqlMapClientTemplate().queryForList("listQuesOptionsByPaperId", paperId);
		return (List<QuestionOptions>)examineesList;
	}

	public List<VO_ExamineesInfo> getUserList(String examRoomId) {
	    Object userList=getSqlMapClientTemplate().queryForList("listUserInfoByRoomId", examRoomId);
		return  (List<VO_ExamineesInfo>)userList;
	}
	
	public List<VO_ExamineesInfo> getCurrentUserAndAdmin(String empNo){
		 Object userList=getSqlMapClientTemplate().queryForList("listCurrentUserAndAdmin", empNo);
			return  (List<VO_ExamineesInfo>)userList;
	}

	public List<ExamInfo> getExamIfoList(String examRoomId) {
		Object userList=getSqlMapClientTemplate().queryForList("listExamInfoByRoomId", examRoomId);
		return (List<ExamInfo>) userList;
	}
	
	/*
	 * 獲取考試結果信息
	 * @see com.foxconn.gds.sce.melp.fdownloadpaper.dao.DownloadPaperDao#litExamResults(java.lang.String)
	 */
	public List<ExamResults> listExamResults(String examRoomId){
		Object examResultsList=getSqlMapClientTemplate().queryForList("fDownload.listExamResultByRoomId", examRoomId);
		return(List<ExamResults>)examResultsList;
	}

}
