package com.foxconn.gds.sce.melp.roomRecord.dao.ibatis;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.roomRecord.dao.RoomRecordDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;

@Repository(value="ibroomRecordDao")
public class IbRoomRecordDao extends GenericDaoIbatisImpl<ExamRoom, String>  implements RoomRecordDao {

	@Autowired
	public IbRoomRecordDao(SqlMapClient sqlMapClient) {
		super(ExamRoom.class);
		setSqlMapClient(sqlMapClient);
	}	

	@SuppressWarnings("unchecked")
	public List<ExamRoom> QueryAllBy(ExamRoom exRoom,int userType) {
		// TODO Auto-generated method stub
		List<ExamRoom> li=null;
		if(userType==0){
			li=getSqlMapClientTemplate().queryForList("select_room_list_byAdmin",exRoom);
		}else if(userType==1){
			li=getSqlMapClientTemplate().queryForList("select_room_list_byExamner",exRoom);
		}else{
			li=new LinkedList<ExamRoom>();
		}
		return li;
	}

}
