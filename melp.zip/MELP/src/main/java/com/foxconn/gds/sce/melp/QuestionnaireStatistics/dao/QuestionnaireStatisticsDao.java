package com.foxconn.gds.sce.melp.QuestionnaireStatistics.dao;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.foxconn.gds.sce.melp.model.Paper;
import com.foxconn.gds.sce.melp.model.QuestionnaireStatistics;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface QuestionnaireStatisticsDao extends GenericDao<QuestionnaireStatistics, String>  {

	public List<QuestionnaireStatistics> showQuestionnaireStatistics_S(HashMap hashMap);
	public List<QuestionnaireStatistics> showQuestionnaireStatistics_P(HashMap hashMap);
}
