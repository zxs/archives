package com.foxconn.gds.sce.melp.model;

public class QuestionnaireStatistics extends BasicEntity {
	
	
	private String courseName;
	
	
	private String ev_Content;
	
	
	private String className;
	
	private String partName;
	
	private float a_Count;
	private float b_Count;
	private float c_Count;
	private float d_Count;
	private float e_Count;
	private int a_C;
	private int b_C;
	private int c_C;
	private int d_C;
	private int e_C;
	
	public String getCourseName() {
		return courseName;
	}

	
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	
	
	public String getEv_Content() {
		return ev_Content;
	}

	
	public void setEv_Content(String ev_Content) {
		this.ev_Content = ev_Content;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getPartName() {
		return partName;
	}

	public void setPartName(String partName) {
		this.partName = partName;
	}
	public float getA_Count() {
		return a_Count;
	}

	
	public void setA_Count(float a_Count) {
		this.a_Count = a_Count;
	}

	
	public float getB_Count() {
		return b_Count;
	}

	
	public void setB_Count(float b_Count) {
		this.b_Count = b_Count;
	}
	public float getC_Count() {
		return c_Count;
	}

	
	public void setC_Count(float c_Count) {
		this.c_Count = c_Count;
	}
	public float getD_Count() {
		return d_Count;
	}

	
	public void setD_Count(float d_Count) {
		this.d_Count = d_Count;
	}
	public float getE_Count() {
		return e_Count;
	}

	
	public void setE_Count(float e_Count) {
		this.e_Count = e_Count;
	}
	
	public int getA_C() {
		return a_C;
	}
	public void setA_C(int a_C) {
		this.a_C = a_C;
	}

	
	public int getB_C() {
		return b_C;
	}

	
	public void setB_C(int b_C) {
		this.b_C = b_C;
	}
	public int getC_C() {
		return c_C;
	}

	
	public void setC_C(int c_C) {
		this.c_C = c_C;
	}
	public int getD_C() {
		return d_C;
	}

	
	public void setD_C(int d_C) {
		this.d_C = d_C;
	}
	public int getE_C() {
		return e_C;
	}

	
	public void setE_C(int e_C) {
		this.e_C = e_C;
	}

	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
