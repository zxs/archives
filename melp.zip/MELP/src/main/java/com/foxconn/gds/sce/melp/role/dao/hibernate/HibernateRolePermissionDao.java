package com.foxconn.gds.sce.melp.role.dao.hibernate;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.PermissionType;
import com.foxconn.gds.sce.melp.model.RolePermission;
import com.foxconn.gds.sce.melp.role.dao.RolePermissionDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoHibernateImpl;

@Repository(value = "rolePermissionDao")
public class HibernateRolePermissionDao extends
		GenericDaoHibernateImpl<RolePermission, String> implements RolePermissionDao {
	@Autowired
	public HibernateRolePermissionDao(SessionFactory sessionFactory) {
		super(RolePermission.class);
		setSessionFactory(sessionFactory);
	}

	/**
	 * Returns a role permission for a specific role
	 * 
	 * @param roleId
	 * @param permissionType
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public RolePermission getRolePermission(String roleId,
			PermissionType permissionType) {
		List<RolePermission> rolePermissions = getHibernateTemplate().find(
				"from RolePermission where role.id = ? and permissionType = ?",
				new Object[] { roleId, permissionType });
		return uniqueResult(rolePermissions);
	}

}
