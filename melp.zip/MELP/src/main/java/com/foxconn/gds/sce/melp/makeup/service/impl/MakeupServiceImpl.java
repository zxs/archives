package com.foxconn.gds.sce.melp.makeup.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.foxconn.gds.sce.melp.makeup.dao.MakeupDao;
import com.foxconn.gds.sce.melp.makeup.service.MakeupService;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.support.ClientUtil;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.support.paginate.datatables.SortInfo;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

@Service("makeupService")

public class MakeupServiceImpl extends CrudServiceImpl<ExamInfo, MakeupDao> 
	implements MakeupService {
	
	@Resource(name="ibMakeupDao")
	private MakeupDao ibMakeupDao;
	
	@Resource
	public void setIbMakeupDao(MakeupDao makeupDao){
		this.daoSupport=makeupDao;
	}

	@Transactional(readOnly=true)
	public DataTableReturn getListForDataTable(DataTable dataTable) {
		DataTableReturn dataTableReturn = new DataTableReturn();
		int skipResults = dataTable.getDisplayStart();
		int maxResults = dataTable.getDisplayLength();
		Map<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put(DataTable.SEARCH, dataTable.getSearch());
		parameterMap.put("creator", ClientUtil.getCurrentUser().getUserId());
//		parameterMap.put("creator", "9057");
		for( SortInfo sInfo : dataTable.getSortInfo() ) {
			parameterMap.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		PaginatedResult<HashMap<String, String>> ExamInfo = ibMakeupDao.getListForDataTable(parameterMap, skipResults, maxResults);
		
		dataTableReturn.setAaData(ExamInfo.getResult());
		dataTableReturn.setiTotalDisplayRecords(ExamInfo.getTotalResults());
		dataTableReturn.setiTotalRecords(ExamInfo.getTotalResults());
		dataTableReturn.setsEcho(dataTable.getEcho());
		return dataTableReturn;
	}

	@Transactional(readOnly=true)
	public DataTableReturn getMakeupInfoForDataTable(DataTable dataTable, String showtimesNo) {
		DataTableReturn dataTableReturn = new DataTableReturn();
		int skipResults = dataTable.getDisplayStart();
		int maxResults = dataTable.getDisplayLength();
		Map<String, String> parameterMap = new HashMap<String, String>();
		parameterMap.put(DataTable.SEARCH, dataTable.getSearch());
		parameterMap.put("creator", ClientUtil.getCurrentUser().getUserId());
		parameterMap.put("id", showtimesNo);
		for( SortInfo sInfo : dataTable.getSortInfo() ) {
			parameterMap.put( DataTable.ORDER_COLUMN_SORT, 
					sInfo.getColumnId()+ " " + sInfo.getSortOrder());			
		}
		
		PaginatedResult<HashMap<String, String>> ExamInfo = ibMakeupDao.getMakeupInfoForDataTable(parameterMap, skipResults, maxResults);
		
		dataTableReturn.setAaData(ExamInfo.getResult());
		dataTableReturn.setiTotalDisplayRecords(ExamInfo.getTotalResults());
		dataTableReturn.setiTotalRecords(ExamInfo.getTotalResults());
		dataTableReturn.setsEcho(dataTable.getEcho());
		return dataTableReturn;
	}
	
	//@Transactional(readOnly = false)
	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public boolean addMakeupTimes(String id) {
//		return ibMakeupDao.addMakeupTimes(id);
		try {
			ibMakeupDao.addMakeupTimes(id);
			return true;
		} catch(Exception e) {
			return false;
		}
	}

	@Transactional(readOnly = false, propagation = Propagation.REQUIRES_NEW)
	public boolean reduceMakeupTimes(String id) {
		try {
			ibMakeupDao.reduceMakeupTimes(id);
			return true;
		} catch(Exception e) {
			return false;
		}
	}

}
