package com.foxconn.gds.sce.melp.support.service;

import java.io.Serializable;

/**
 * Base CRUD service. 
 * @author: jperez
 */
public interface CrudService<T> {


    /**
     * Creates a new entity
     * @param entity entity
     */
    void create(T entity);

    /**
     * Updates an entity
     * @param entity entity
     */
    void update(T entity);

    /**
     * Deletes an entity
     * @param entity entity
     */
    void delete(T entity);

    /**
     * Reads an entity
     * @param entityId entity id
     * @return Returns the entity found or null if not found
     */
    T read(String entityId);



}
