package com.foxconn.gds.sce.melp.model;

public enum PermissionType {

	Home("HOME"),
	ExamMngt("EXM-MNGT"),				//考试管理
	ExamMngtPaperLib("EXM-MNGT-PPLIB"),	//	題庫管理
	ExamMngtPaper("EXM-MNGT-PP"),		//	考卷设置
	ExamMngtRoom("EXM-MNGT-ROOM"),		//	考場设置
	ExamMngtPaperPlus("EXM-MNGT-PPP"),	//	補考设置
	ExamMngtRecord("EXM-MNGT-RECORD"),	//	考場記錄
	ExamMngtResult("EXM-MNGT-RESULT"),	//	成績查詢
	
	ExamMngtDownPaper("EXM-MNGT-DOWN-PP"),	//	下載考試
	ExamMngtUpResult("EXM-MNGT-UP-RESULT"),	//	我的考試(OFF/ONLINE)
	ExamMngtMyExam("EXM-MNGT-MY-EXAM"),		//	上傳成績
	ExamMngtMyResult("EXM-MNGT-MY-RESULT"),	//	成績查詢(OFF/ONLINE)
	
	SystemMngt("SYS-MNGT"),				// 系統管理
	SystemMngtUser("SYS-MNGT-USER"),	//	用戶管理
	SystemMngtPwd("SYS-MNGT-PWD");		//	修改密碼
	
	private String code;

	private PermissionType(String code) {
		this.code = code;
	}

	public String getCode() {
		return code;
	}
	
	
	
	
}
