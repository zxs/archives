package com.foxconn.gds.sce.melp.organization.service;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.support.service.CrudService;

import java.util.List;
import java.util.Set;

/**
 * User: franco
 * Date: 27/01/2009
 * Time: 08:32:41 AM
 * 
 */
public interface OrganizationService extends CrudService<Organization>{

    /**
     *
     * @return
     */
    List<Organization> getRootOrganizations();

    /**
     *
     * @param userId
     * @return
     */
    Organization getUserOrganization(String userId);

    /**
     *
     * @param organizatioId
     * @return
     */
    List<Organization> getChildren(String organizatioId);

    /**
     *
     * @param organizationIds
     * @return
     */
    List<Organization> getOrganizations( Set<String> organizationIds );

    /**
     * Return a list of all organizations
     * @return
     */
    List<Organization> getOrganizations();

    /**
     *
     * @param organization
     * @param parentOrganization
     */
    void addChildToParentOrganization(Organization organization, Organization parentOrganization);

    /**
     * Removes a child organization (organization) from its parent (parentOrganization)
     * @param organization
     * @param parentOrganization
     */
    boolean removeChildFromParentOrganization(Organization organization, Organization parentOrganization);

    //TODO: Review this method to see if it makes sense and is required.
//    boolean isCustomUserIdAvailable( String customUserId, String organizationId );

    //TODO: Review this method to see if it makes sense and is required.
//    boolean isOrganizationNameAvailable(String organizationName, String parentId);

    //TODO: Review this method to see if it makes sense and is required.
    //List<Organization> getOrganizationsWithLogo();

}
