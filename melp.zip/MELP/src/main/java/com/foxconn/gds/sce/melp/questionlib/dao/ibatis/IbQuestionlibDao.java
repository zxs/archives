package com.foxconn.gds.sce.melp.questionlib.dao.ibatis;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.aspectj.weaver.NewConstructorTypeMunger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.QuestionOptions;

import com.foxconn.gds.sce.melp.model.VO_QuestonOption;
import com.foxconn.gds.sce.melp.questionlib.QustionlibController;
import com.foxconn.gds.sce.melp.questionlib.dao.QuestionlibDao;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;

@Repository(value="ibQuestionlibDao")

public class IbQuestionlibDao  extends  GenericDaoIbatisImpl<QuestionLib, String> implements QuestionlibDao
{
 
	
	@Autowired
    public IbQuestionlibDao(SqlMapClient sqlMapClient) {
		super(QuestionLib.class);
		setSqlMapClient(sqlMapClient);
	}
	public List<QuestionLib> findAllByCondition(QuestionLib questionLib)
	{
		@SuppressWarnings("unchecked")
		List<QuestionLib>  listLib=  (List<QuestionLib>) getSqlMapClientTemplate().queryForList("findAllByNameSequence", questionLib);

		return listLib;
	}
	
	public PaginatedResult<QuestionLib> findAllQuestionLib(Map parameters, int skipResults, int maxResults)
	{
		int page = skipResults/maxResults; // the page number
		int pageSize = maxResults;
		PaginatedResult<QuestionLib> prQustion = new PaginatedResult<QuestionLib>(page, pageSize);
		List<QuestionLib> result = null;
		if(maxResults<0) { // Query All Records
			result = getSqlMapClientTemplate().queryForList("QuestionLib.findAllQuestionLib", parameters);			
		} else {
			result = getSqlMapClientTemplate().queryForList("QuestionLib.findAllQuestionLib", parameters, skipResults, maxResults);
		}
		Integer count = (Integer)getSqlMapClientTemplate().queryForObject("QuestionLib.findAllQuestionLib_count", parameters);
		
		prQustion.setResult(result);
		prQustion.setTotalResults(count);
		
		return prQustion;
	}
	
	//查詢所有試題
	   public PaginatedResult<Question> findAllQuestion( Map parameters,int skipResults, int maxResults )
	   {
		   int page = skipResults/maxResults; // the page number
		   int pageSize = maxResults;
		   PaginatedResult<Question> prQustion = new PaginatedResult<Question>(page, pageSize);
		   List<Question> result = null;
		   if(maxResults<0) { // Query All Records
			   result = getSqlMapClientTemplate().queryForList("Question.findAllQuestion", parameters);
		   }
		   else
		   {
			   result = getSqlMapClientTemplate().queryForList("Question.findAllQuestion", parameters, skipResults, maxResults);
		   }
		   Integer count = (Integer)getSqlMapClientTemplate().queryForObject("Question.findAllQuestion_count", parameters);
			
			prQustion.setResult(result);
			prQustion.setTotalResults(count);
			
			return prQustion;
	   }
	
	
	
	 public boolean insertLib(QuestionLib questionLib) 
	 {
		
			getSqlMapClientTemplate().insert("addQuestionLib", questionLib);
			return true;
	 }
	 
	 public  boolean updateLib(QuestionLib questionLib) {
		
			getSqlMapClientTemplate().update("updateQuestionLib", questionLib);
			return true;
		
	}
	 
	 //根據試題庫ID查詢所有試題
	 public List<Question> findAllQustionByLibID(Question question)
	 {
		 @SuppressWarnings("unchecked")
		 List<Question> listQuestions=(List<Question>) getSqlMapClientTemplate().queryForList("findAllQuestionByLibID", question);
		 return listQuestions;
	 }
	 
	
	 
	 
	 
	//新增試題
	   public boolean insertQuestion(Question question) 
	   {
		 
			   getSqlMapClientTemplate().insert("addQuestionTitle",question);
			   return true;
		 
	   }
	   

	   //新增選項
	   public boolean insertOption(QuestionOptions questionOptions)  
	   {
		
			   getSqlMapClientTemplate().insert("QuestionOptions.addOptions",questionOptions);
			   return true;
		  
	   }
	   
	   
	   public  List<VO_QuestonOption> findByQuestionID ( VO_QuestonOption vo_QuestonOption) 
	   {
		   @SuppressWarnings("unchecked")
		   List<VO_QuestonOption> list=(List<VO_QuestonOption>) getSqlMapClientTemplate().queryForList("findByQuestionID",vo_QuestonOption);
		   return list;
	   }
	   
	   public boolean delQuestionByID(Question question)
	   {
		  
			   getSqlMapClientTemplate().update("delQuestionByID", question);
			   return true;
		
	   }
	   
	   
	   public  boolean delOptionByID(Question question)
	   {
		  
			   getSqlMapClientTemplate().update("delOptionByID", question);
			   return true;
		
	}
	   
	 //根據選項ID刪除選項
	   public  boolean delOptionByID(String optionid)
	   {
		  
			   getSqlMapClientTemplate().update("delOptions", optionid);
			   return true;
		 
	   }
	   
	   
	   public boolean delQuestionLib(QuestionLib questionLib)
	   {
			   getSqlMapClientTemplate().update("deleteQuestionLib", questionLib);
			   return true;
	   }
	   
	 //導入時插入試題
	   public void importTitle(final List<Map> titleList)
	   {
		   if(titleList!=null)
		   {
			   this.getSqlMapClientTemplate().execute(new SqlMapClientCallback<Object>() {
				   public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException 
				   {
					   executor.startBatch();
	                    for (int i = 0, n = titleList.size(); i < n; i++) {
	                        executor.insert("question.addTitle", titleList.get(i));
	                    }
	                    executor.executeBatch();
	                    return null;
				   }
			});
		   }
	   }
	   
	   //導入時插入選項
	   @SuppressWarnings("unchecked")
	public void importOption(final List<Map> optionList){
		   if(optionList!=null)
		   {
			   this.getSqlMapClientTemplate().execute(new SqlMapClientCallback() {
				   public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException
				   {
					   executor.startBatch();
					   for(int i=0,n=optionList.size();i<n;i++)
					   {
						   executor.insert("questionOption.addOptionsForImport",optionList.get(i));
					   }
					   executor.executeBatch();
					   return null;
				   }
			});
		   }
	   }
	
	 //查詢試題庫是否有試卷
	   public Object findPaperByLibid(String libid){
		 return getSqlMapClientTemplate().queryForObject("paper.selPaperByLibid", libid);
		   
	   }  
	   
	   
	 //導出
	   public  List<Map> exports(Map paraMap){
		   List<Map> result=null;
		   result=(List<Map>)getSqlMapClientTemplate().queryForList("question.selQuestionForExport", paraMap) ;
		   return result;
	   }
}
