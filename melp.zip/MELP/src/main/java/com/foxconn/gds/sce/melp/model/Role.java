package com.foxconn.gds.sce.melp.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.hibernate.annotations.ForeignKey;

/**
 * A role defines a profile that can be applied to users in the application
 * 
 * User: ronvargas
 * Date: Jan 27, 2009
 */
@Entity
@Table(name = "melp_role")
public class Role extends BasicEntity {

	//Name of the role
    @Column
    private String name;

    //Organization the role belongs to
    @ManyToOne
    @ForeignKey(name = "fk_role_organization_id")
    @JoinColumn(name = "organization_id")
    private Organization organization;

    //Set of permissions associated with this role
    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL)
    private Set<RolePermission> permissions;

    //Whether or not the role has been marked as deleted
    @Column(nullable = false)
    private boolean deleted;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Organization getOrganization() {
        return organization;
    }

    public void setOrganization(Organization organization) {
        this.organization = organization;
    }

    public Set<RolePermission> getPermissions() {
        return permissions;
    }

    public void setPermissions(Set<RolePermission> permissions) {
        this.permissions = permissions;
    }


    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

    public boolean onEquals(Object obj) {
        return new EqualsBuilder()
                .append(getName(), ((Role) obj).getName())
                .append(isDeleted(), ((Role) obj).isDeleted())
                .append(getOrganization(), ((Role) obj).getOrganization()).isEquals();

    }

    public int onHashCode() {
        return new HashCodeBuilder()
                .append(getId())
                .append(getName())
                .append(getOrganization())
                .append(isDeleted())
                .toHashCode();
    }

    @Override
    @SuppressWarnings({"CloneDoesntDeclareCloneNotSupportedException"})
    public Object clone() {
        try {
            Role cloneEntity = (Role) super.clone();
            cloneEntity.setName(this.getName());
            cloneEntity.setDeleted(this.isDeleted());
            cloneEntity.setOrganization(this.getOrganization());
            cloneEntity.setPermissions(this.getPermissions());
            return cloneEntity;
        } catch (CloneNotSupportedException e) {
            // shouldn't ever happen
            throw new InternalError("Unable to clone object of type [" + getClass().getName() + "]");
        }
    }
    
    public enum Name {
    	Administraor	("Administrator", "1"),	//系統管理員
    	Examiner		("Examiner", "2"),		//訓練專員
    	Examinee		("Examinee", "3");		//考生
    	
    	private String value;
    	private String code;
    	private Name(String value, String code) {
    		this.value = value;
    		this.code = code;
    	}
    	
    	public static String getByCode(String code) {
    		if("1".equals(code)) {
    			return Administraor.value;
    		} else if("2".equals(code)) {
    			return Examiner.value;
    		} else if("3".equals(code)) {
    			return Examinee.value;
    		} else {
    			return "UNDEFINED ROLE";
    		}
    	}
    	
    	public String getValue() {
    		return value;
    	}
    }
}
