package com.foxconn.gds.sce.melp.support.invoker;


import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.GnuParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 * @author: jperez
 */
public class SpringTaskInvoker {

    private String contextLocations[];

    public void setContextLocations(String[] contextLocations) {
        this.contextLocations = contextLocations;
    }

    private void invoke(String beanName) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(contextLocations);
        Object bean = context.getBean(beanName);
        if (bean == null){
            System.out.println(String.format("Bean not found: %s", beanName));
        }
        else if (!(bean instanceof Task)){
            System.out.println(String.format("Invalid bean class: %s", bean.getClass().getName()));
        }
        else{
            Task task = (Task) bean;
            task.execute();
        }

    }


    public static void main(String args[]) {
        boolean parametersFound = false;
        String beanName = null;
        String locations = null;

        Options options = getOptions();

        HelpFormatter formatter = new HelpFormatter();
        try {
            CommandLineParser parser = new GnuParser();
            CommandLine line = parser.parse(options, args);

            if (line.hasOption("b")) {
                beanName = line.getOptionValue("b");
            }

            if (line.hasOption("l")) {
                locations = line.getOptionValue("l");
            }

            parametersFound = beanName != null && locations != null;
            if (!parametersFound) {
                formatter.printHelp("invoker", options);
            }

        } catch (ParseException e) {
            e.printStackTrace();
            formatter.printHelp("invoker", options);
        }

        if (parametersFound){
            SpringTaskInvoker invoker = new SpringTaskInvoker();
            String[] contextLocations = locations.split(",");
            invoker.setContextLocations(contextLocations);
            invoker.invoke(beanName);
        }
        else{
            formatter.printHelp("invoker", options);
        }

    }

    private static Options getOptions() {
        Options options = new Options();


        Option locations = new Option("l", true, "Context locations. Comma separated");
        locations.setArgName("locations");
        options.addOption(locations);

        Option beanName = new Option("b", true, "Spring context bean name");
        beanName.setArgName("beanName");
        options.addOption(beanName);

        return options;
    }

}