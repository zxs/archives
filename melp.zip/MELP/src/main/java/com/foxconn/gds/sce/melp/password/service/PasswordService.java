package com.foxconn.gds.sce.melp.password.service;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.password.dao.PasswordDao;
import com.foxconn.gds.sce.melp.user.service.impl.UserServiceImpl;


/**
 * User: River
* Date: 20111222
*/

//public class PasswordService {
public interface PasswordService {

	
	Map updatePassword(String userId,String oldPassword,String newPassword);

}

