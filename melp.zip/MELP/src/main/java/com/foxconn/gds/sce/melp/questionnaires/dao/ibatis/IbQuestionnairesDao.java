package com.foxconn.gds.sce.melp.questionnaires.dao.ibatis;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.stereotype.Repository;

import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.support.dao.impl.GenericDaoIbatisImpl;
import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;
import java.util.HashMap;
import java.util.UUID;
import com.foxconn.gds.sce.melp.questionnaires.dao.QuestionnairesDao;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.model.Questionnaires;


@Repository(value = "IbQuestionnairesDao")
public class IbQuestionnairesDao extends GenericDaoIbatisImpl<Questionnaires,String>implements QuestionnairesDao{
	@Autowired
	public IbQuestionnairesDao(SqlMapClient sqlMapClient) {
		super(Questionnaires.class);
		setSqlMapClient(sqlMapClient);
	}

public List<Questionnaires> showQuestionnaires_P()
{
	String userid=SecurityUtils.getCurrentUser().getUserId();
	if(SecurityUtils.administratorPlayedbyCurrentUser()){//modified by lyl
	userid="Admin";
	}
	else{
	Integer count = (Integer)getSqlMapClientTemplate().queryForObject("getQuestionnairesCount", userid);
	if(count==0){
		userid="Admin";
	}
	}

	 return (List<Questionnaires>) getSqlMapClientTemplate().queryForList("Questionnaires_P",userid);
	
	/*else{
		 return (List<Questionnaires>) getSqlMapClientTemplate().queryForList("Questionnaires_P_User",userid);
	}*/  //added by lyl
}

public void insertQuestionnaires(final List<Map> successList)  
{
	if(successList!=null)
	   {
		   this.getSqlMapClientTemplate().execute(
				new SqlMapClientCallback<Object>() {
					   public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException 
					   {
						   executor.startBatch();
						   executor.update("deleteEvalution_result", successList.get(0));
						   executor.update("deleteQuestionnairesItems", successList.get(0));
		                 for (int i = 0, n = successList.size(); i < n; i++) {
		                     executor.insert("insertQuestionnairesItems", successList.get(i));
		                 }
		                 executor.executeBatch();
		                 return null;
					   }
					   }
				   	);
	   }
	  
}

}
