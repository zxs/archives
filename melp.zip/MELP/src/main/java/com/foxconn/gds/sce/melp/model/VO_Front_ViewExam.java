package com.foxconn.gds.sce.melp.model;

import java.math.BigDecimal;
import java.util.Date;

public class VO_Front_ViewExam extends BasicEntity{

	//front page
	//title
	private String examRoomId;
	private String paperId;
	private String empNo;
	private String paperName;
	private String empName;
	private BigDecimal passScore;
	private BigDecimal getScore;
	private BigDecimal timeTotal;
	private BigDecimal totalScore;
	private Date startTime;
	private Date endTime;
	private BigDecimal numberS;
	private BigDecimal numberM;
	private BigDecimal numberTf;
	private BigDecimal scoreS;
	private BigDecimal scoreM;	
	private BigDecimal scoreTf;
	private BigDecimal sTotal;
	private BigDecimal mTotal;
	private BigDecimal tfTotal;
	private String paperDetailId;
	private String strStartTime;
	private String strEndTime;
	public String getStrStartTime() {
		return strStartTime;
	}

	public void setStrStartTime(String strStartTime) {
		this.strStartTime = strStartTime;
	}

	public String getStrEndTime() {
		return strEndTime;
	}

	public void setStrEndTime(String strEndTime) {
		this.strEndTime = strEndTime;
	}

	public String getPaperDetailId() {
		return paperDetailId;
	}

	public void setPaperDetailId(String paperDetailId) {
		this.paperDetailId = paperDetailId;
	}
	
	private String loger;
	public String getLoger() {
		return loger;
	}

	public void setLoger(String loger) {
		this.loger = loger;
	}

	//list
	private String questionType;
	private String id;
	private String questionTitle;
	private String isRightAnswer;
	private String isUserAnswer;
	private String optionContent;
	private BigDecimal optionOrder;
	
	public BigDecimal getOptionOrder() {
		return optionOrder;
	}

	public void setOptionOrder(BigDecimal optionOrder) {
		this.optionOrder = optionOrder;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public BigDecimal getScoreS() {
		return scoreS;
	}

	public void setScoreS(BigDecimal scoreS) {
		this.scoreS = scoreS;
	}

	public BigDecimal getScoreM() {
		return scoreM;
	}

	public void setScoreM(BigDecimal scoreM) {
		this.scoreM = scoreM;
	}

	public BigDecimal getScoreTf() {
		return scoreTf;
	}

	public void setScoreTf(BigDecimal scoreTf) {
		this.scoreTf = scoreTf;
	}
	public String getQuestionType() {
		return questionType;
	}

	public void setQuestionType(String questionType) {
		this.questionType = questionType;
	}

	public String getQuestionTitle() {
		return questionTitle;
	}

	public void setQuestionTitle(String questionTitle) {
		this.questionTitle = questionTitle;
	}

	public String getIsRightAnswer() {
		return isRightAnswer;
	}

	public void setIsRightAnswer(String isRightAnswer) {
		this.isRightAnswer = isRightAnswer;
	}

	public String getIsUserAnswer() {
		return isUserAnswer;
	}

	public void setIsUserAnswer(String isUserAnswer) {
		this.isUserAnswer = isUserAnswer;
	}

	public String getOptionContent() {
		return optionContent;
	}

	public void setOptionContent(String optionContent) {
		this.optionContent = optionContent;
	}

	public BigDecimal getNumberS() {
		return numberS;
	}

	public void setNumberS(BigDecimal numberS) {
		this.numberS = numberS;
	}

	public BigDecimal getNumberM() {
		return numberM;
	}

	public void setNumberM(BigDecimal numberM) {
		this.numberM = numberM;
	}

	public BigDecimal getNumberTf() {
		return numberTf;
	}

	public void setNumberTf(BigDecimal numberTf) {
		this.numberTf = numberTf;
	}

	public BigDecimal getsTotal() {
		return sTotal;
	}

	public void setsTotal(BigDecimal sTotal) {
		this.sTotal = sTotal;
	}

	public BigDecimal getmTotal() {
		return mTotal;
	}

	public void setmTotal(BigDecimal mTotal) {
		this.mTotal = mTotal;
	}

	public BigDecimal getTfTotal() {
		return tfTotal;
	}

	public void setTfTotal(BigDecimal tfTotal) {
		this.tfTotal = tfTotal;
	}

	public String getExamRoomId() {
		return examRoomId;
	}

	public void setExamRoomId(String examRoomId) {
		this.examRoomId = examRoomId;
	}

	public String getPaperId() {
		return paperId;
	}

	public void setPaperId(String paperId) {
		this.paperId = paperId;
	}

	public String getEmpNo() {
		return empNo;
	}

	public void setEmpNo(String empNo) {
		this.empNo = empNo;
	}

	public String getPaperName() {
		return paperName;
	}

	public void setPaperName(String paperName) {
		this.paperName = paperName;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public BigDecimal getPassScore() {
		return passScore;
	}

	public void setPassScore(BigDecimal passScore) {
		this.passScore = passScore;
	}

	public BigDecimal getGetScore() {
		return getScore;
	}

	public void setGetScore(BigDecimal getScore) {
		this.getScore = getScore;
	}

	public BigDecimal getTimeTotal() {
		return timeTotal;
	}

	public void setTimeTotal(BigDecimal timeTotal) {
		this.timeTotal = timeTotal;
	}

	public BigDecimal getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(BigDecimal totalScore) {
		this.totalScore = totalScore;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	@Override
	public boolean onEquals(Object o) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public int onHashCode() {
		// TODO Auto-generated method stub
		return 0;
	}

}
