package com.foxconn.gds.sce.melp.questionnaires.service.impl;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import org.apache.commons.lang.time.DateUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDataFormatter;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.service.CrudServiceImpl;

import com.foxconn.gds.sce.melp.questionnaires.dao.QuestionnairesDao;
import com.foxconn.gds.sce.melp.questionnaires.service.QuestionnairesService;
import com.foxconn.gds.sce.melp.model.EvaluationItems;
import com.foxconn.gds.sce.melp.model.Questionnaires;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.questionnaires.dao.QuestionnairesDao;
import com.visural.common.DateUtil;
@Service(value = "questionnairesService")
public class QuestionnairesServiceImpl extends CrudServiceImpl<Questionnaires, QuestionnairesDao> implements QuestionnairesService{
	@Autowired
	public void setIbQuestionnairesDao(QuestionnairesDao questionnairesDao){
		this.daoSupport=questionnairesDao;
	}
	public List<Questionnaires> showQuestionnaires_P()
	    {
	    	return (List<Questionnaires>) daoSupport.showQuestionnaires_P();	
		}

	@Transactional(readOnly=false)
	public boolean importQuestionnaires(MultipartFile file,String user_id,String name) throws IOException {
		String modifier=user_id;
		if(SecurityUtils.administratorPlayedbyCurrentUser()){
			user_id="Admin";
		}
		
		List<Map> successList = new ArrayList<Map>();
	    
		POIFSFileSystem fsFileSystem = new POIFSFileSystem(
				file.getInputStream());
//		try {
			HSSFWorkbook workBook = new HSSFWorkbook(fsFileSystem);// 實例化WorkBook
			HSSFSheet hssfSheet = workBook.getSheetAt(0); // 取得第一個sheet
			Iterator rowIterator = hssfSheet.rowIterator(); // 取得sheet中的行
			//設置表頭 to do
			int rowIndex = 1;//導出的數據從第二行開始
			
			int tempfirstcell=hssfSheet.getRow(0).getFirstCellNum();
			int templastcell=hssfSheet.getRow(0).getLastCellNum();
			//questionType = hssfRow.getCell(0).getStringCellValue().trim();
			
			for(int i=tempfirstcell;i<templastcell;i++){
				
				String str=hssfSheet.getRow(0).getCell(i).toString();
				
			}
			while (rowIterator.hasNext()) {
                
				HSSFRow hssfRow = (HSSFRow) rowIterator.next(); // 略過第一行
			
				Map udr = new HashMap();
				if (hssfRow.getRowNum() == 0)
					continue;
				
				//udr = validates(hssfRow);   //驗證數據
					UUID uuid = UUID.randomUUID();
					String id = uuid.toString();
					
					String questionPart = hssfRow.getCell(0).getStringCellValue().trim();					
					//modified by julie0831 判斷單元格的數據類型
					HSSFCell cells=hssfRow.getCell(1);
					String questionTitle="";
					switch (cells.getCellType()) {
					case Cell.CELL_TYPE_STRING:
						questionTitle=cells.getStringCellValue().trim();
						break;
					case Cell.CELL_TYPE_NUMERIC:
						questionTitle= String.valueOf(cells.getNumericCellValue()).split("\\.")[0];
						break;
					default:
						questionTitle="";
						break;
					}
					
					
					//String questionTitle = hssfRow.getCell(1).getStringCellValue().trim();
					id = id.replaceAll("-", "");
					udr.put("questionID", id);
					udr.put("questionPart", questionPart);
					udr.put("questionTitle", questionTitle);
					udr.put("creator", user_id);
					udr.put("modifier", modifier);
					successList.add(udr);
				
			}

			// 向數據庫插入試題
			if (successList.size() != 0) {
				/*daoSupport.deleteQuestionnaires();*/
				daoSupport.insertQuestionnaires(successList);
			}
		return true;

	}
	
	// 驗證數據
	@SuppressWarnings("unused")
	public Map validates(HSSFRow hssfRow) {
		Map dataMap = new HashMap();
		String questionPart = "";
		String questionTitle = "";
		String isRightAnswer = "";
		String priority = "";
		String err_msg = "";

		//List<String> rightChar = new ArrayList<String>();
		String rightString = "";
		// 取行中的每列 0:題目類型 1:考題內容 

		// 第0行
		questionPart = hssfRow.getCell(0).getStringCellValue().trim();
		if (!questionPart.equals("")) {
			questionPart = hssfRow.getCell(0).getStringCellValue().trim();
		} else {
			err_msg += "評估項不能為空";
		}

		// 第1行
		questionTitle = hssfRow.getCell(1).getStringCellValue().trim();
		if (questionTitle.equals("")) {
			err_msg += "評估項內容不能為空;";
		}
		dataMap.put("questionType", questionPart);
		dataMap.put("questionTitle", questionTitle);

		return dataMap;
	}

}


