package com.foxconn.gds.sce.melp.learnCourse.service;

import java.util.List;
import java.util.UUID;


import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.support.service.CrudService;

	public interface LearnCourseService extends CrudService<MyClassInfo> {
		List<MyClassInfo> listCourse(String empNo);
		public Boolean insertRecord(String empNo,String coursewareUrl,String uuid,String classNo);
		public Boolean updateRecord(String empNo,String coursewareUrl,String uuid,String classNo);
		
}
