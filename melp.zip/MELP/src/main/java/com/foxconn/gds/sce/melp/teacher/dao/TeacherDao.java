package com.foxconn.gds.sce.melp.teacher.dao;

import java.util.List;
import java.util.Map;


import com.foxconn.gds.sce.melp.model.BaseCode;
import com.foxconn.gds.sce.melp.model.QuestionLib;
import com.foxconn.gds.sce.melp.model.Teacher;
import com.foxconn.gds.sce.melp.support.dao.GenericDao;
import com.foxconn.gds.sce.melp.support.dao.util.PaginatedResult;

public interface TeacherDao extends GenericDao<Teacher, String> {

	public PaginatedResult<Teacher> selTeacherList(Map parameters,int skipResults, int maxResults) ;
	
	//新增講師
	public Boolean addTeacher(Teacher p_teacher);
	
	//判斷講師是否豐在
	public  boolean isTeacherExist(Teacher p_teacher) ;
	
	public List<BaseCode>  selTeacherType();
	
	public List<BaseCode> selTeacherLevel();
	
	/*根據ID查詢講師信息*/
	public Teacher selTeacherByID(Teacher p_teacher);
	
	/*更新講師*/
	public boolean updTeacher(Teacher p_teacher);
	
	/*刪除講師*/
	public boolean delTeacher(String p_id);
	
}
