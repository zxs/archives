package com.foxconn.gds.sce.melp.security;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;

import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.model.User;

public final class SecurityUtils {

	private static Logger log = LoggerFactory.getLogger(SecurityUtils.class);

	public static User getCurrentUser() {

		Object principal = SecurityContextHolder.getContext()
				.getAuthentication().getPrincipal();

		if (principal instanceof UserSessionDetails)
			return ((UserSessionDetails) principal).getUser();

		log.warn("!!! NOT Logined User !!!");
		// principal object is either null or represents anonymous user -
		// neither of which our domain User object can represent - so return
		// null
		return null;
	}

	public static Set<Role> getCurrentUserWithRoles() {
		Set<Role> roles = null;
		User user = getCurrentUser();
		if (user != null) {
			roles = user.getRoles();
		}

		return roles;
	}

	/**
	 * 当前用户是否扮演考生
	 * 
	 * @return
	 */
	public static boolean examineePlayedbyCurrentUser() {
		Set<Role> roles = getCurrentUserWithRoles();
		if (roles != null) {
			for (Role role : roles) {
				if (Role.Name.Examinee.getValue().equals(role.getName())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 当前用户是否扮演训练专员
	 * 
	 * @return
	 */
	public static boolean examinerPlayedbyCurrentUser() {
		Set<Role> roles = getCurrentUserWithRoles();
		if (roles != null) {
			for (Role role : roles) {
				if (Role.Name.Examiner.getValue().equals(role.getName())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * 当前用户是否扮演系统管理员
	 * 
	 * @return
	 */
	public static boolean administratorPlayedbyCurrentUser() {
		Set<Role> roles = getCurrentUserWithRoles();
		if (roles != null) {
			for (Role role : roles) {
				if (Role.Name.Administraor.getValue().equals(role.getName())) {
					return true;
				}
			}
		}
		return false;
	}

	public static String EncryptMD5(String strInput) {
		String strOutput = null;
		if (null == strInput || strInput.length() < 1)
			strOutput = "";
		else {
			try {
				MessageDigest md = MessageDigest.getInstance("MD5");
				md.update(strInput.getBytes());
				byte[] b = md.digest();
				StringBuffer  sb=new StringBuffer(""); 
				int i;
				for (int offset = 0; offset < b.length; offset++) { 
					i = b[offset]; 
					if(i<0) i+= 256; 
					if(i<16) 
						sb.append("0"); 
					sb.append(Integer.toHexString(i)); 
					}
				strOutput = sb.toString();
			} catch (NoSuchAlgorithmException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return strOutput;
	}
}
