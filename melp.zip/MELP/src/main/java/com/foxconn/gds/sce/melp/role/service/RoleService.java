package com.foxconn.gds.sce.melp.role.service;

import com.foxconn.gds.sce.melp.model.Organization;
import com.foxconn.gds.sce.melp.model.Role;
import com.foxconn.gds.sce.melp.support.service.CrudService;

import java.util.List;

/**
 * User: ronvargas
 * Date: Feb 11, 2009
 */
public interface RoleService extends CrudService<Role> {

    /**
     * get role object by role ID, equivalent to Read function
     *
     * @param roleId
     * @return
     */
    Role getRole(final String roleId);

    /**
     * creates Role entity
     *
     * @param role
     */
    void create(final Role role);

    /**
     * updates Role entity
     *
     * @param role
     */
    void update(final Role role);

    /**
     * Retrieves a Role list identified by the specified name (many roles can have the same name across organizations)
     *
     * @param name role name
     * @return A role list
     */
    List<Role> getRolesByName(final String name);

    /**
     * get Roles associated to this Organization object
     *
     * @param organization Organization
     * @return A role list
     */
    List<Role> getRolesByOrganization(final Organization organization);

    /**
     * get Roles associated to this Organization id
     *
     * @param organizationId Organization id
     * @return A role list
     */
    List<Role> getRolesByOrganizationId(final String organizationId);

    /**
     * get Roles associated to this Organization name
     *
     * @param organizationName Organization name
     * @return A role list
     */
    List<Role> getRolesByOrganizationName(final String organizationName);

    /**
     * * Returns true if the role is deleted
     *
     * @param roleId id from the role
     * @return deleted status
     */
    boolean isRoleDeleted(String roleId);

    /**
     * This is to set the delete field to true or false.
     *
     * @param roleId id from the role to modify
     * @param delete deleted status
     * @return true if successful
     */
    boolean changeDeletedFlag(String roleId, boolean delete);
}
