package com.foxconn.gds.sce.melp.user;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.FileUtils;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;
import com.foxconn.gds.sce.melp.user.service.UserService;

@Controller
@RequestMapping(value="/user/**")
public class UserController {
	private static final Logger logger = LoggerFactory.getLogger(UserController.class);	
	private UserService userSrv;
	
	@Autowired
	public void setUserService(UserService userSrv) {
		this.userSrv = userSrv;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="main.spr")
	public  ModelAndView userMain(@RequestParam("iframe") String iframe ) {
//		boolean b = SecurityUtils.examinerPlayedbyCurrentUser();
		return new ModelAndView("/user/main", "iframe", "true".equals(iframe)?"true":"false");
	}
	
	@RequestMapping(method=RequestMethod.POST, value="list.spr")
	public @ResponseBody Object list(@RequestParam("_dt_json") String dtjson,HttpServletRequest req) {
		logger.info("String dtjson=" + dtjson );
		String roomid=req.getParameter("roomid")!=null?req.getParameter("roomid"):"";
		//added by Cube @120829 classId
		String classId=req.getParameter("classId")!=null?req.getParameter("classId"):"";
		
		//可套用，返回
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
//modified by Cube @120829
		//added the parameter "classId"
		DataTableReturn tableReturn = this.userSrv.listForDT(dataTable,roomid,classId);

		return tableReturn;
	}	
	
	@RequestMapping(method=RequestMethod.POST, value="saveOrUpdate.spr")
	public  @ResponseBody Map<String, Object> saveOrUpdate(HttpServletRequest req) {
		logger.info("saveOrUpdate");
		logger.debug("##　Params:");
		Enumeration paramNames = req.getParameterNames();
		String key = null;
		Map<String, String> params = new HashMap<String, String>();
		while( paramNames.hasMoreElements() ) {
			key = (String)paramNames.nextElement();
			logger.debug( key + "\t:\t" + req.getParameter(key) );
			params.put(key, req.getParameter(key));
		}
		String strPWD=params.get("PASSWORD");
		params.remove("PASSWORD");
		strPWD=SecurityUtils.EncryptMD5(strPWD);
		params.put("PASSWORD", strPWD);
		boolean toUpdate = params.get("ID")!=null && params.get("ID").length()>0;
		boolean result = userSrv.saveOrUpdate(params);
		
		Map<String, Object> toJson = new HashMap<String, Object>();
		toJson.put("status", result);
		if(result) {
			toJson.put("msg", toUpdate?"成功更新用戶信息":"成功創建新的用戶");
		} else {
			toJson.put("msg", toUpdate?"用戶信息未更新":"新的用戶未能創建");
		}
	
		return toJson;
	}	
	
	@RequestMapping(method=RequestMethod.POST, value="delete.spr")
	public  @ResponseBody Map<String, Object> delete(@RequestParam("OPIDS_") String opids) {
		logger.info("delete# OPIDS_" + opids);		
		String[] ids = opids.split(",");
		boolean result = userSrv.markDeleted(ids);
		Map<String, Object> toJson = new HashMap<String, Object>();
		toJson.put("status", result);
		if(result) {
			toJson.put("msg", "成功刪除所選用戶");
		} else {
			toJson.put("msg", "刪除用戶失敗");
		}
		return toJson;
	}
	
    @RequestMapping( method = RequestMethod.POST, value = "import.spr")
    public /*@ResponseBody Map */ ModelAndView handleUserImport(@RequestParam("name") String name,
        @RequestParam("file") MultipartFile file) throws IOException {
    	Map<String, Object> result = new HashMap<String,Object>();
    	result.put("status", false);
    	try {
	        if (!file.isEmpty()) {
	        	boolean imported = userSrv.importUsers(file);
	        	result.put("status", imported);
	        	result.put("msg", "導入用戶名單成功！");
	        }
        } catch(Exception ex) {
        	result.put("status", false);
        	result.put("msg", "導入用戶異常，請聯繫系統管理員！ EX:"+ex.getMessage());
        	
        }
        return new ModelAndView("/user/import-result", "result", result);
    }
    
	
	@RequestMapping(method=RequestMethod.POST, value="/reset_pwd.spr")
	public  @ResponseBody Map<String, Object> resetPwd(@RequestParam("OPID_") String opid_,@RequestParam("userID") String userID) {
		logger.info("changePwd# OPID_="	+	opid_);//用戶ID_角色ID
		String uid = opid_.split("_")[0];
		Map<String, String> params = new HashMap<String, String>();
		params.put("ID", uid);
		String strPWD=SecurityUtils.EncryptMD5(userID);
		params.put("PASSWORD", strPWD);
		boolean result = userSrv.resetPwd( params );
		Map<String, Object> toJson = new HashMap<String, Object>();
		toJson.put("status", result);
		if(result) {
			toJson.put("msg", "成功重設了密碼為工號");
		} else {
			toJson.put("msg", "未能重設密碼為工號");
		}
		return toJson;
	}    
	@RequestMapping(method=RequestMethod.GET, value="/hasUserExist.spr")
	public @ResponseBody Map<String, Object> hasUserExist(@RequestParam("userId") String userId) {
		logger.info("hasUserExist# userId="	+	userId);//用戶ID_角色ID
		//去掉默認值，取第一個
		String uid = userId.split(",")[0];
		//boolean result = userSrv.hasUserExist(uid);
		boolean result = userSrv.isUserExist(uid);
		Map<String, Object> toJson = new HashMap<String, Object>();
		toJson.put("status", result);
		if(result) {
			toJson.put("msg", "你輸入的工號已被註冊");
		} else {
			toJson.put("msg", "你輸入的工號可用");
		}
		return toJson;
	}
	
	@RequestMapping(method=RequestMethod.GET, value="/dl-userfile.spr")
	public  ModelAndView dlUserFile(HttpServletRequest req, HttpServletResponse resp)
	throws FileNotFoundException, IOException {

		File file = FileUtils.getUsersFile();
        resp.setContentType("application/vnd.ms-excel");
        resp.setContentLength( (int) file.length() );
        resp.setHeader("Content-Disposition","attachment; filename=\"" 
//        					+ URLEncoder.encode(file.getName(), "UTF-8") + "\"");
        					+ URLEncoder.encode("用戶導入模板.xls", "UTF-8") + "\"");
        
        FileCopyUtils.copy(new FileInputStream(file), resp.getOutputStream());
        
        return null;
	}	
	
}
