package com.foxconn.gds.sce.melp.person.service;

import java.util.List;

import com.foxconn.gds.sce.melp.model.Person;
import com.foxconn.gds.sce.melp.support.service.CrudService;

/**
 * @author Edward
 */
public interface PersonService extends CrudService<Person> {

    /**
     * Retrives All Persons
     * @return A list of person Objects
     */
    List<Person> getPersons();

    /**
     * Sets delete field to true or false based on the
     * boolean field "delete"
     *
     * @param personId person number
     * @param delete isDeleted
     * @return boolean
     */
    boolean changeDeletedFlag(String personId, boolean delete);

    /**
     * Gets the deleted field from person
     *
     * @param personId, term number
     * @return boolean
     */
    boolean isPersonDeleted(String personId);

    /**
     * Retrives a Person
     * @param personId  Person Id
     * @return A Person Object
     */
    Person getPerson(String personId);

//    /**
//     *  This method adds a contact to the user (person)
//     * @param person a person object
//     * @param contact a contact object
//     * @return true if the contact is added
//     */
//    boolean addContactToPerson(Person person, Contact contact);
//
//    /**
//     * Removes a contact from a person
//     * @param person a person object
//     * @param contact a contact object
//     * @return true if the contact is removed
//     */
//    boolean removeContactFromPerson(Person person, Contact contact);
//
//    /**
//     * Retrives a List of Contacts
//     * @param personId  Person Id
//     * @return A List of Contacts
//     */
//    List<Contact> getContactsByPerson(String personId);
//
//
//        /**
//     * This method returns a contact of a person with the specified ID
//     * @param personId The ID of the person
//     * @param contactId The ID of the contact
//     * @return the Contact
//     */
//    Contact getContactById(String personId, String contactId);
//
//
//        /**
//     * This method returns a contact of a person with the specified ID
//     * @param person The person that is owner of the contacts
//     * @param contactId The contact ID
//     * @return
//     */
//    Contact getContactById(Person person, String contactId);
}
