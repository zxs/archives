package com.foxconn.gds.sce.melp.learnCourse;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.hibernate.id.GUIDGenerator;
import org.omg.CORBA.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.fMyExam.service.MyExamService;
import com.foxconn.gds.sce.melp.learnCourse.service.LearnCourseService;
import com.foxconn.gds.sce.melp.model.MyClassInfo;
import com.foxconn.gds.sce.melp.model.VO_ExamRoom;
import com.foxconn.gds.sce.melp.security.SecurityUtils;

@Controller
@RequestMapping(value = "/learnCourse/**")
public class LearnCourseController {
	private LearnCourseService learnCourseService;
	@Autowired
	public void setLearnCourseService(LearnCourseService learnCourseService){
		this.learnCourseService=learnCourseService;
	}
	
	@RequestMapping(method=RequestMethod.GET,value="courseList.spr")
	public ModelAndView courseList(){
		return new ModelAndView();
	}
	@RequestMapping(method=RequestMethod.POST,value="getCourseList.spr")
	@ResponseBody
	public List<MyClassInfo> listCourse(){
		String empNo="";
		empNo=SecurityUtils.getCurrentUser().getUserId();
		List<MyClassInfo> courseList=learnCourseService.listCourse(empNo);
		return courseList;
	}
	@RequestMapping(method=RequestMethod.GET,value="courseVideo.spr")
	public ModelAndView courseVideo(HttpServletRequest request){
		String coursewareUrl=request.getParameter("coursewareUrl");
		String classNo=request.getParameter("classNo");
		String uuid = UUID.randomUUID().toString().replace("-", "");
		String empNo=SecurityUtils.getCurrentUser().getUserId();
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("courseUrl", coursewareUrl);
		modelAndView.addObject("uuid", uuid);
		modelAndView.addObject("classNo", classNo);
		modelAndView.addObject("empNo",empNo);
	
		Boolean object=learnCourseService.insertRecord(empNo,coursewareUrl,uuid,classNo);//modified by lyl
		return modelAndView;
	}
	@RequestMapping(method=RequestMethod.POST,value="updateRecord.spr")
	@ResponseBody
	public Boolean updateRecord(HttpServletRequest request){
		String empNo="";
		String coursewareUrl=request.getParameter("coursewareUrl");
		String classNo=request.getParameter("classNo");
		String uuid=request.getParameter("uuid");
	/*	empNo=SecurityUtils.getCurrentUser().getUserId();*/
		empNo=request.getParameter("empNo");
		
		return learnCourseService.updateRecord(empNo, coursewareUrl,uuid,classNo);//modified by lyl
	}
}
