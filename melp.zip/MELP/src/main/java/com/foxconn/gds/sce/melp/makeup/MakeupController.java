package com.foxconn.gds.sce.melp.makeup;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.makeup.service.MakeupService;
import com.foxconn.gds.sce.melp.support.JackJson;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTable;
import com.foxconn.gds.sce.melp.support.paginate.datatables.DataTableReturn;

@Controller
@RequestMapping(value="/makeup/**")
public class MakeupController {

	private static final Logger logger = LoggerFactory.getLogger(MakeupController.class);
	
	@Resource(name="makeupService")
	private MakeupService makeupService;

	@RequestMapping(method=RequestMethod.GET, value="makeupMainPage.spr")
	public ModelAndView makeupMainPage(@RequestParam("iframe") String iframe ) {
		return new ModelAndView("/makeup/makeupMain", "iframe", "true".equals(iframe)?"true":"false");
	}
	
	/**
	 * 获取补考设置信息:场次编号、考卷名称、考试日期、考试地点、同步设置
	 * @param dtjson
	 * @return
	 */
	@RequestMapping(method=RequestMethod.POST, value="getExamInfoForDataTable.spr")
	public @ResponseBody Object getExamInfoForDataTable(@RequestParam("_dt_json") String dtjson) {
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn = makeupService.getListForDataTable(dataTable);
		return tableReturn;
	}
	
	/**
	 * 根据场次编号获取考生名单信息:工号、姓名、部门、考试次数、补考次数
	 * @param dtjson
	 * @return 
	 */
	@RequestMapping(method=RequestMethod.POST, value="getMakeupInfoForDataTable.spr")
	public @ResponseBody Object getMakeupInfoForDataTable(@RequestParam("_dt_json") String dtjson, 
			@RequestParam("ShowtimesNo") String ShowtimesNo) {
		DataTable dataTable = JackJson.fromJsonToObject(dtjson, DataTable.class);
		DataTableReturn tableReturn = makeupService.getMakeupInfoForDataTable(dataTable, ShowtimesNo);
		return tableReturn;
	}
	
	/**
	 * 增加一次補考次數
	 * @param dtjson
	 * @param ShowtimesNo
	 * @return
	 */
	@RequestMapping(value="addMakeupTimes.spr")
	public @ResponseBody String addMakeupTimes(@RequestParam("id") String id) {
		logger.info("String dtjson=" + id );
		String message = "";
		if(makeupService.addMakeupTimes(id)) {
			message = "success";
		} else {
			message = "error";
		}
		return "{\"message\":\""+message+"\"}";
	}
	
	/**
	 * 減少一次補考次數
	 * @param dtjson
	 * @param ShowtimesNo
	 * @return
	 */
	@RequestMapping(value="reduceMakeupTimes.spr")
	public @ResponseBody String reduceMakeupTimes(@RequestParam("id") String id) {
		logger.info("String id=" + id );
		String message = "";
		if(makeupService.reduceMakeupTimes(id)) {
			message = "success";
		} else {
			message = "error";
		}
		return "{\"message\":\""+message+"\"}";
	}
	
}
