package com.foxconn.gds.sce.melp.fdownloadpaper;

import java.security.Principal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.foxconn.gds.sce.melp.fdownloadpaper.service.DownloadPaperService;
import com.foxconn.gds.sce.melp.model.ExamInfo;
import com.foxconn.gds.sce.melp.model.ExamResults;
import com.foxconn.gds.sce.melp.model.ExamRoom;
import com.foxconn.gds.sce.melp.model.Examinees;
import com.foxconn.gds.sce.melp.model.PaperInfo;
import com.foxconn.gds.sce.melp.model.Question;
import com.foxconn.gds.sce.melp.model.QuestionOptions;
import com.foxconn.gds.sce.melp.model.User;
import com.foxconn.gds.sce.melp.model.VO_ExamineesInfo;
import com.foxconn.gds.sce.melp.model.VO_RolePermission;
import com.foxconn.gds.sce.melp.security.SecurityUtils;
import com.foxconn.gds.sce.melp.support.ClientUtil;

@Controller
@RequestMapping(value = "/fDownloadPaper/**")
public class DownloadPaperController {

	private DownloadPaperService downloadPaperService;

	@Autowired
	public void setSampleService(DownloadPaperService downloadPaperService) {
		this.downloadPaperService = downloadPaperService;
	}

	@RequestMapping(method = RequestMethod.GET, value = "paperList.spr")
	public ModelAndView paperList() {
		return new ModelAndView();
	}

	@RequestMapping(method = RequestMethod.GET, value = "examineesList.spr")
	public ModelAndView examineesList(HttpServletRequest request) {
		return new ModelAndView();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "examineesList_Offline.spr")
	public ModelAndView examineesListOffLine(HttpServletRequest request) {
		return new ModelAndView();
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "localPaperList.spr")
	public ModelAndView getLocalPaperList(HttpServletRequest request) {
		Integer roleCode=downloadPaperService.getCurrentUserRole();
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.addObject("role", roleCode);
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "getExamineesList.spr")
	@ResponseBody
	public List<Examinees> getExamineesList(@RequestParam("roomId") String roomId) {
		// @RequestParam("") 聲明接受的參數
		List<String> roomIdStrings = new ArrayList<String>();
		roomIdStrings.add(roomId);
		List<Examinees> examinees = downloadPaperService
				.getExamineedList(roomIdStrings);
		return examinees;
	}

	@RequestMapping(method = RequestMethod.GET, value = "getAllPaper.spr")
	@ResponseBody
	public List<ExamRoom> ListAllPaper() {
		// @RequestParam[""] 聲明接受的參數
//		String loginUserEmpNo = "";
//		if(principal!=null){
//			loginUserEmpNo=principal.getName();
//		}
		User user=ClientUtil.getCurrentUser();
		List<ExamRoom> examRoomList = downloadPaperService
				.listByUser(user);
		return examRoomList;
	}

	@RequestMapping(method = RequestMethod.GET, value = "GetAttachInfo.spr")
	@ResponseBody
	public Map GetAttachInfo(HttpServletRequest request) {
		String examRoomIdsString = request.getParameter("examRoomIds");
		String paperIdsString = request.getParameter("paperIds");
		String empNo=SecurityUtils.getCurrentUser().getUserId();
		examRoomIdsString=examRoomIdsString.substring(0,examRoomIdsString.lastIndexOf(','));
		paperIdsString=paperIdsString.substring(0,paperIdsString.lastIndexOf(','));
		// 需要下載的考場Id
		List<String> examRoomIdList =Arrays.asList(examRoomIdsString.split(","));
		
		// 需要下載的考卷ID
		List<String> paperIdList = Arrays.asList(paperIdsString.split(","));

		// 獲取選擇的考場記錄
		List<ExamRoom> roomList=downloadPaperService.getExamRoomInfos(examRoomIdList);
		
		//獲取學員信息
		List<Examinees> examineeList= downloadPaperService.getExamineedList( examRoomIdList);
		
		//獲取可登陸用戶信息
		List<VO_ExamineesInfo> userList= downloadPaperService.getUserList(examRoomIdList,empNo);
		
		//獲取學員考試信息
		List<ExamInfo> examInfoList= downloadPaperService.getExamIfoList( examRoomIdList);
		
		// 獲取考卷設置信息
		List<PaperInfo> paperInfos = downloadPaperService
				.getPaperInfos(paperIdList);

		// 獲取考卷對應題庫試題信息
		List<Question> questions = downloadPaperService.getQuestions(paperIdList);

		// 獲取考卷試題選項信息
		List<QuestionOptions> questionOptions = downloadPaperService
				.getQuestionOptions(paperIdList);
		
		List<ExamResults> examResults=downloadPaperService.getExamResultsList(examRoomIdList);
		
		//獲取角色菜單權限 
		List<VO_RolePermission> rolePermissions=downloadPaperService.getAllRolePermissions();

		Map resultMap = new HashMap();
		resultMap.put("examineeList", examineeList);
		resultMap.put("userList", userList);
		resultMap.put("examInfoList", examInfoList);
		resultMap.put("paperInfos", paperInfos);
		resultMap.put("questions", questions);
		resultMap.put("questionOptions", questionOptions);
		resultMap.put("rolePermissions", rolePermissions);
		resultMap.put("examResults", examResults);
		resultMap.put("roomList", roomList);
		return resultMap;
	}
}
