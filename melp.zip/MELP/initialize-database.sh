# set/export MAVEN_HOME/bin to system environment
mvn hibernate3:hbm2ddl
cd ..